# sa-doc-agent 規格文件（STE 版）

> 本文件是 sa-doc-agent 規格 v0.2.0 的改寫版。
> 本文件依 ASD-STE100 原則寫成。
> 本文件的內容與 v0.2.0 相同。
> 標示「（暫定）」的數字尚未定案。
> 團隊取得基線資料或開放問題有結論後，再定案。

## 用詞表

本文件只使用「用詞」欄的詞。本文件不使用「不使用的詞」欄的詞。

| 用詞 | 意思 | 不使用的詞 |
|---|---|---|
| Agent | 本規格描述的 sa-doc-agent | 本 Agent、系統 |
| SA | 各系統的系統分析師，操作 Agent 的人 | 使用者、分析師 |
| 共識書 | 解決方案設計 Agent 建立的方案共識書 | 方案共識書、需求共識書 |
| 高階需求說明 | 需求層級的說明文件，格式為 md | 需求說明、HLD |
| 來源文件 | 共識書與高階需求說明的合稱 | 來源、上游文件 |
| SA 文件 | 系統分析文件 | 規格、設計文件 |
| SA 服務編號 | SA 文件的編號，例：`TS0108-SA-010122-00008` | 文件編號、服務 ID |
| 資訊資產代碼 | 系統的資產代碼，例：`TS0108` | 系統代碼 |
| 目標 | 需求編號、MVP 編號與系統英文簡稱的組合 | 目標三元組、作業範圍 |
| 文件範圍 | SA 確認要處理的 SA 文件清單 | 影響範圍、處理範圍 |
| 候選清單 | Agent 列出、待 SA 確認的 SA 文件 | 候選文件、建議清單 |
| 候選項目 | 候選清單中的一份 SA 文件 | 新候選、候選 |
| 工作項目 | Agent 對一份 SA 文件做的一次作業 | 任務、作業項目 |
| 產製 | Agent 第一次寫出 SA 文件 | 產出、撰寫、生成 |
| 修訂 | Agent 依回饋修改 SA 文件 | 修改、調整 |
| 覆核 | SA 檢查 SA 文件 | 審核、審閱 |
| 回饋 | SA 對 SA 文件的修改意見 | 意見、建議 |
| 草稿 | Agent 寫入 SharePoint 的次要版本 | 草稿版本、新版本 |
| 上傳檔 | SA 上傳給 Agent 的 SA 文件 | 上傳文件 |
| 上傳登記 | 狀態紀錄中記錄上傳檔的欄位 | 上傳紀錄 |
| 上傳階段 | 上傳登記的值：`received`、`diff_ready`、`confirmed`、`stale` | 上傳階段 |
| 改版 | 來源文件出現新版本 | 來源改版、版本更新 |
| 改版決定 | SA 對改版處理方式的決定 | 決定改版 |
| 重做要求 | 改版後 SA 決定重做的登記 | 改版回饋、重做指示 |
| 卡片 | Teams 上的互動卡片 | 通知卡片、表單 |
| 狀態 | SA 文件在狀態機中的位置 | 階段、進度 |
| 狀態紀錄 | Store 中一份 SA 文件的紀錄 | 文件紀錄、記錄 |
| 旗標 | 狀態以外的標記 | 標記、註記 |
| 暫停 | 旗標：Agent 不再處理這份 SA 文件 | 阻擋、卡住 |
| 移出 | 旗標：SA 把 SA 文件移出文件範圍 | 移除、撤除 |
| 閘門 | 改版待決時，Agent 停止產製與修訂的開關 | 來源閘門、鎖 |
| Ingress | Teams Bot 的後端服務 | 後端、Bot |
| Store | LangGraph 的長期記憶 | 記憶、資料庫 |

**卡片名稱**

| 卡片 | 用途 |
|---|---|
| 目標卡片 | SA 確認目標 |
| 來源卡片 | SA 指定來源文件 |
| 範圍卡片 | SA 確認文件範圍 |
| 追加卡片 | SA 追加 SA 文件 |
| 覆核卡片 | SA 覆核一份 SA 文件 |
| 差異卡片 | SA 確認上傳檔的差異 |
| 改版卡片 | SA 做出改版決定 |
| 進度卡片 | SA 查看所有 SA 文件的狀態 |

目標卡片、來源卡片與範圍卡片合稱「確認卡片」。

**狀態名稱**：待產製、產製中、SA覆核中、修訂中、完成。

## 0. 文件控制 ★

| 項目 | 內容 |
|---|---|
| Spec ID | AGT-SA-001（暫定） |
| Agent 名稱 | `sa-doc-agent` |
| Spec 版本 | 0.2.0（STE 版） |
| 狀態 | Draft |
| Owner | <待填> |
| 審查者 | Tech：<待填>；Security：<待填>；Domain：<待填> |
| 風險等級 | 中 |
| 建立日期 | 2026-10-03 |
| 更新日期 | 2026-10-04 |
| 對應程式碼 | <尚未建立> |
| 技術版本 | Python <待定>；LangGraph <待定> |
| 相關文件 | SA Agent 循序圖；共識書範例 `CONF_B01_20260408_02`；ADR 0001–0012 |

風險等級為「中」的理由：

1. Agent 會寫入 SharePoint。
2. Agent 不處理金流。
3. Agent 不處理客戶個資。
4. Agent 寫入的都是草稿。
5. SA 覆核後，草稿才會定版。

## 1. 目的與範圍 ★

### 1.1 問題與目標

**現況問題**

1. SA 要自己從共識書找出系統的職責。
2. 職責分散在共識書的多個章節。
3. 共識書沒有一張完整的職責表。
4. SA 服務編號散落在敘述中。
5. 共識書常把「異動」與「不異動」寫在同一句。
6. SA 人工盤點時，容易漏改或誤改。
7. SA 花很多時間寫重複格式的 SA 文件。
8. 多份 SA 文件同時進行時，SA 查不到一致的狀態。

**目標**

1. Agent 依目標摘要系統的職責。
2. Agent 為每一條摘要附上出處。
3. Agent 列出候選清單。
4. SA 在範圍卡片上確認文件範圍。
5. Agent 逐份產製 SA 文件。
6. Agent 每完成一份，就通知 SA 覆核。
7. Agent 為每份 SA 文件記錄狀態。
8. SA 可以上傳自己修改的 SA 文件。
9. Agent 比對上傳檔的差異。SA 確認後，SA 文件完成。
10. Agent 依改版的差異，判斷是否重做。

**角色**

1. SA：與 Agent 互動的主要角色。
2. Orchestration：上游呼叫方，可以帶入目標。
3. PO 與 BA：查詢狀態。

**上下游關係**

```mermaid
flowchart LR
  SOL[解決方案設計 Agent] -->|共識書| CS[(ContextStore)]
  ORC[Orchestration] -->|目標（可選）| SA[Agent]
  CS -->|來源文件| SA
  SA <-->|卡片| U[SA]
  SA <-->|讀取與寫入| REPO[(SharePoint)]
  SA -->|完成摘要| CS
  CS -.->|發布與交付| NEXT[下一段流程]
```

### 1.2 成功指標

| 指標 | 目標 | 量測方式 |
|---|---|---|
| 職責摘要正確率 | ≥ 90%（暫定） | SA 逐條標註 golden set |
| 候選召回率 | ≥ 95%（暫定） | 比對 SA 實際修改的 SA 文件 |
| 候選精確率 | ≥ 80%（暫定） | 比對預設勾選與 SA 決定 |
| 引用可追溯率 | = 100% | validator 檢查出處 |
| 改版召回率 | ≥ 95%（暫定） | 比對改版案例集 |
| 首版通過率 | 上線一季後訂定 | 讀取狀態歷程 |
| 平均修訂輪數 | ≤ 2（暫定） | 讀取狀態歷程 |
| SA 工時節省 | ≥ 50%（暫定） | 試行期問卷與工時紀錄 |

指標定義：

1. 首版通過率：SA 文件沒有經過修訂就完成的比例。
2. 平均修訂輪數：每份 SA 文件進入「修訂中」的平均次數。

### 1.3 Non-goals

1. Agent 不發布需求。
2. Agent 不交付 User Story、Requirements 與提案編號給 AISDLC。
3. Agent 不產製 BA 文件。
4. Agent 不產製 User Story 或 Requirements。
5. Agent 不修改來源文件。
6. Agent 發現共識書有矛盾時，只回報 SA。
7. Agent 一次只處理一個系統。
8. Agent 不修改其他系統的 SA 文件。
9. Agent 不替 SA 決定覆核結果。
10. Agent 不發布 SharePoint 的主要版本。
11. Agent 不改寫上傳檔的內容。
12. Agent 不自行補完共識書的缺漏。

### 1.4 假設與前提

1. 解決方案設計 Agent 以 MVP 為單位建立共識書。
2. Agent 以需求編號與 MVP 編號取得共識書。
3. 範例共識書還沒有 MVP 欄位。
4. 上線前，上游要補上 MVP 欄位（15.3 #1）。
5. 高階需求說明與共識書放在同一位置。
6. 高階需求說明的格式為 md。
7. System Registry 提供簡稱與資訊資產代碼的對照。
8. SA 文件放在 SharePoint。
9. SharePoint 啟用主要版本與次要版本。
10. Agent 寫入次要版本作為草稿。
11. 解決方案設計 Agent 不標示 SA 文件是否異動。
12. Agent 把共識書的異動描述當作線索。
13. SA 透過 Teams 與 Agent 互動。
14. Ingress 驗證 SA 的身分。
15. Ingress 把卡片操作轉成事件。

## 2. 使用情境與 I/O 契約 ★

### 2.1 主要情境

以下情境使用範例共識書 `CONF_B01_20260408_02`。範例系統為 EDLS（`TS0108`）。`MVP-01` 只是示意。

**UC-1：Orchestration 帶入目標**

1. Orchestration 帶入目標，啟動 Agent。
2. Agent 發出目標卡片，預填帶入的目標。
3. SA 確認目標。
4. Agent 開始分析。

**UC-2：SA 沒有提供目標**

1. SA 在 Teams 呼叫 Agent。
2. Agent 發出空白的目標卡片。
3. SA 填寫需求編號、MVP 編號與系統英文簡稱。
4. Agent 從 System Registry 提供系統選單。

**UC-3：Agent 分析來源文件**

1. Agent 摘要 EDLS 的職責。
2. Agent 為每一條摘要附上章節與行號。
3. Agent 預設勾選 `010122-00008` 與 `010301-00179`。
4. Agent 列出 `010122-00006` 與 `010301-00116`。
5. Agent 不勾選這兩份。
6. Agent 註明「共識書寫明不異動」。

**UC-4：SA 確認文件範圍**

1. SA 勾選 2 份候選清單中的 SA 文件。
2. SA 手動加入 1 份 SA 文件。
3. SA 寫下手動加入的原因。
4. SA 新增 1 份新的 SA 文件。
5. SA 寫下新文件的名稱與原因。
6. Agent 為這 4 份建立狀態紀錄，狀態為「待產製」。
7. Agent 依卡片上的順序開始產製。

**UC-5：第 1 份產製完成**

1. Agent 把第 1 份寫入 SharePoint，成為草稿。
2. Agent 把狀態改為「SA覆核中」。
3. Agent 發出覆核卡片。
4. Agent 開始產製第 2 份。

**UC-6：SA 在產製期間提出回饋**

1. Agent 正在產製第 2 份。
2. SA 對第 1 份提出回饋。
3. Ingress 把回饋放進第 1 份的佇列。
4. 第 1 份的狀態維持「SA覆核中」。
5. Agent 完成第 2 份。
6. Agent 修訂第 1 份，狀態改為「修訂中」。
7. Agent 完成修訂，狀態改回「SA覆核中」。
8. Agent 開始產製第 3 份。

**UC-7：SA 完成覆核**

1. SA 在覆核卡片上按「覆核完成」。
2. Ingress 把狀態改為「完成」。
3. 未移出的 SA 文件全部完成後，Agent 寫入完成摘要。
4. Agent 回報 Orchestration。
5. Agent 結束作業。

**UC-8：SA 追加 SA 文件**

1. SA 按「追加文件」。
2. Ingress 發出追加卡片。
3. SA 填寫要追加的 SA 文件。
4. Ingress 驗證內容，規則同 5.2.3。
5. Ingress 建立狀態紀錄，狀態為「待產製」。
6. Agent 繼續目前的工作，不中斷。

**UC-9：Agent 暫停 SA 文件**

1. Agent 產製某份 SA 文件失敗。
2. Agent 為這份 SA 文件設定暫停。
3. 進度卡片顯示原因與選項。
4. SA 選擇「重試」或「移出」。
5. eTag 不符時，SA 也可以選擇「以最新版重做」。
6. SA 選擇「移出」時，必須寫下原因。
7. 完成判斷不計入移出的 SA 文件。

**UC-10：SA 上傳修改後的 SA 文件**

1. SA 在覆核卡片上傳上傳檔。
2. Agent 比對上傳檔與最新草稿。
3. Agent 發出差異卡片。
4. SA 按「確認並完成」。
5. Agent 把上傳檔寫入 SharePoint。
6. Agent 把狀態改為「完成」。
7. 如果 SA 按「取消」，狀態維持「SA覆核中」。

**UC-11：共識書改版**

1. 共識書從 V1.3 改為 V1.4。
2. Agent 比對兩個版本的差異。
3. Agent 判斷改版對本系統的影響。
4. 如果沒有影響，Agent 改用新版。
5. Agent 通知 SA。
6. 如果有影響，Agent 關閉閘門。
7. Agent 發出改版卡片。
8. SA 決定每份 SA 文件是否重做。
9. Agent 依 SA 的決定繼續工作。

### 2.2 邊界情境

| ID | 情境 | Agent 的處理 |
|---|---|---|
| E-1 | 帶入的目標與 SA 確認的不同 | Agent 採用 SA 確認的目標。Agent 記錄差異。 |
| E-2 | Agent 找不到共識書，或找到多份 | Agent 不猜測。Agent 發出來源卡片。SA 指定或修正。 |
| E-3 | 共識書沒有提到本系統 | Agent 告知 SA。SA 決定結束或手動指定。 |
| E-4 | 共識書沒有本系統的 SA 服務編號 | Agent 列出相關電文作為提示。SA 手動輸入。 |
| E-5 | 手動輸入的 SA 文件不在 SharePoint | 卡片顯示錯誤。卡片提供「改為新文件」選項。格式不符時，Ingress 直接退回。 |
| E-6 | SA 沒有勾選任何 SA 文件 | Agent 再確認一次。SA 確認後，Agent 寫入 ContextStore。Agent 結束作業。 |
| E-7 | SA 對「產製中」的 SA 文件提出回饋 | Ingress 拒絕。Ingress 說明完成後會通知。 |
| E-8 | SA 要求修改其他系統的 SA 文件 | Agent 拒絕。Agent 說明範圍限制。 |
| E-9 | 別人修改了 SharePoint 上的 SA 文件 | Agent 不覆蓋。Agent 設定暫停。 |
| E-10 | 回饋含有指令文字 | Agent 把回饋當作資料。流程不變。 |
| E-11 | SA 對有未處理回饋的 SA 文件按完成 | Ingress 拒絕。Ingress 提示未處理的數量。 |
| E-12 | SA 對非「SA覆核中」的 SA 文件上傳 | Ingress 拒絕。Ingress 說明目前狀態。Ingress 說明何時可以上傳。 |
| E-13 | 上傳檔無法解析，或不是同一份 | Agent 退回上傳檔。SA 重新上傳。 |
| E-14 | 上傳檔不是以最新草稿為基礎 | 差異卡片顯示警示。SA 決定是否確認。 |
| E-15 | 確認前，有人修改了 SharePoint 上的 SA 文件 | Agent 不覆蓋。上傳檔標為失效。 |
| E-16 | 所有 SA 文件完成後，共識書改版 | Agent 仍然分析影響。有影響時，SA 確認後，Ingress 重新開啟受影響的 SA 文件。 |

補充說明：

1. E-11：SA 可以撤回排隊中的回饋，再按完成。
2. E-11：重做要求不能撤回。SA 要等 Agent 修訂完成。
3. E-14：差異卡片列出上傳檔會覆蓋的變更。
4. E-15：SA 可以直接重新上傳，或取消。

### 2.3 輸入契約（`input_schema`）

Graph 的輸入只有事件。Ingress 處理 SA 的卡片操作。Ingress 把結果寫入 Store。Ingress 接著送出 `wake` 事件（ADR 0002、0007）。

| 欄位 | 型別 | 必填 | 說明 |
|---|---|:-:|---|
| `event.type` | `"start" \| "wake"` | 是 | `start` 啟動作業。`wake` 喚醒 graph。 |
| `event.id` | `str` | 是 | Ingress 產生的唯一 ID，用於去重 |
| `user` | `UserRef` | 是 | Ingress 驗證後填入，SA 不能自填 |
| `proposed_target` | `Target \| None` | 否 | Orchestration 帶入的目標，只作預填 |
| `source` | `"orchestration" \| "teams"` | 是 | 呼叫來源 |

Agent 有三個阻斷式確認點：`confirm_target`、`ask_source`、`confirm_doc_scope`。SA 以 `Command(resume=...)` 恢復（10.1）。

### 2.4 輸出契約（`output_schema`）

| 欄位 | 型別 | 說明 |
|---|---|---|
| `run_outcome` | `str` | 這次 run 的結果，值見下方清單 |
| `target` | `Target \| None` | SA 確認的目標 |
| `docs` | `list[DocSummary]` | 每份 SA 文件的摘要 |
| `sources` | `SourceRefs` | 目前採用的來源文件版本 |
| `message` | `str` | 給 Orchestration 的文字摘要 |
| `errors` | `list[ErrorInfo]` | 錯誤清單 |
| `continue_pending` | `bool` | 還有工作待做 |

`run_outcome` 的值：

1. `awaiting_target_confirm`：等待 SA 確認目標。
2. `awaiting_source_confirm`：等待 SA 指定來源文件。
3. `awaiting_scope_confirm`：等待 SA 確認文件範圍。
4. `awaiting_review`：等待 SA 的操作。
5. `awaiting_source_decision`：等待 SA 的改版決定。
6. `completed`：所有 SA 文件完成。
7. `no_change`：本系統不需要修改 SA 文件。
8. `aborted`：SA 取消作業。
9. `failed`：作業失敗。

`DocSummary` 的欄位：`doc_id`、`doc_name`、`origin`、`status`、`blocked`、`withdrawn`、`upload_pending`、`current_version`、`repo_url`。

有待決的改版時，`sources` 附上 `pending_source_change` 摘要。

`ErrorInfo` 的欄位：`code`、`node`、`doc_id`、`detail`、`retryable`。

失敗規則：

1. 失敗時，`run_outcome` 為 `failed`。
2. 失敗時，`errors` 至少有一筆。
3. Agent 不回滾已寫入的草稿。

### 2.5 呼叫方式

1. Agent 以背景 run 執行。
2. 一個作業會有多次 run。
3. Orchestration 只在三種結果時視為結束：`completed`、`no_change`、`aborted`。
4. Agent 在 `start` 時產生 `thread_id = sa:{uuid}`。
5. `thread_id` 不包含目標。
6. SA 確認目標後，Agent 在登錄表登記目標。
7. Agent 以「不存在才寫入」登記。
8. 如果目標已經登記，Agent 不重複作業。
9. Agent 改為發出現有作業的進度卡片。
10. Ingress 以登錄表查出 `thread_id`，再送 `wake`。
11. 改版時，Orchestration 對相關的 thread 送 `wake`。
12. 同一 thread 的 run 使用 `multitask_strategy="enqueue"`。
13. run 執行中收到的 `wake` 會排隊。

補充規則：

1. `awaiting_*` 只代表這次 run 告一段落。
2. 目標已經登記時，這次 run 以 `aborted` 結束。
3. ContextStore 的事件通知也可以觸發改版的 `wake`。
4. 已完成的 thread 也要偵測改版。

## 3. 架構總覽 ★

### 3.1 選型與理由

Agent 的主圖是受控 workflow。

1. `doc_worker` 子圖負責產製與修訂。
2. `upload_worker` 子圖負責上傳檔。
3. Agent 一次只處理一份 SA 文件（ADR 0008）。

不採用 ReAct 的理由：

1. 業務已經定義流程的步驟。
2. 狀態有嚴格的轉換規則。
3. SharePoint 寫入必須可預測。
4. ReAct 讓 LLM 決定下一步，Agent 無法保證狀態轉換。

使用子圖的理由：

1. 產製與修訂共用相同的步驟。
2. 子圖可以單獨測試。

覆核不使用 `interrupt` 的理由：

1. `interrupt` 會讓整個 thread 停住。
2. thread 停住後，Agent 無法產製下一份。
3. Ingress 把回饋立即寫入 Store。
4. `scheduler` 每一輪從 Store 挑選工作項目（ADR 0002）。

`interrupt` 的使用範圍：

1. SA 確認目標。
2. SA 指定來源文件。
3. SA 確認文件範圍。

作業開始後的 SA 操作：

1. Ingress 處理所有 SA 操作。
2. Ingress 把結果寫入 Store。
3. graph 只從 Store 挑選工作項目。
4. SA 操作不會讓 thread 停住（ADR 0007）。

改版的檢查方式：

1. `check_sources` 在每一輪 `scheduler` 之前執行。
2. `check_sources` 只查詢版本號。
3. 改版有影響時，Agent 關閉閘門。
4. 閘門關閉時，Agent 停止產製與修訂（ADR 0009）。

### 3.2 拓樸圖

```mermaid
flowchart TD
  S([START]) --> ingest_event
  ingest_event -->|重複事件| E0([END])
  ingest_event -->|目標未確認| resolve_target
  ingest_event -->|範圍已確認| check_sources
  ingest_event -->|範圍未確認| load_sources
  resolve_target --> confirm_target
  confirm_target -->|驗證失敗| confirm_target
  confirm_target -->|SA 確認| load_sources
  confirm_target -->|取消或已登記| E1([END：aborted])
  load_sources -->|找到唯一來源| extract_system_scope
  load_sources -->|找不到或不唯一| ask_source
  ask_source -->|SA 指定| load_sources
  ask_source -->|SA 放棄| E1
  extract_system_scope --> list_candidates
  list_candidates --> confirm_doc_scope
  confirm_doc_scope -->|驗證失敗| confirm_doc_scope
  confirm_doc_scope -->|有 SA 文件| init_doc_records
  confirm_doc_scope -->|沒有 SA 文件| finalize
  init_doc_records --> check_sources
  check_sources -->|有未分析的新版| analyze_source_change
  check_sources -->|其他| scheduler
  analyze_source_change --> scheduler
  scheduler -->|產製或修訂| doc_worker
  scheduler -->|上傳檔| upload_worker
  doc_worker --> post_work
  upload_worker --> post_work
  post_work --> check_sources
  scheduler -->|未移出的全部完成| finalize
  scheduler -->|等待 SA 或達上限| E2([END：awaiting_review])
  scheduler -->|閘門關閉| E4([END：awaiting_source_decision])
  finalize --> E3([END：completed 或 no_change])

  subgraph doc_worker [doc_worker 子圖]
    direction TB
    load_baseline -->|回饋已撤回| WA([結束：放棄])
    load_baseline --> plan_changes --> draft_content --> generate_diagrams --> assemble_document --> validate_document
    validate_document -->|通過| save_draft
    validate_document -->|未通過，可重試| draft_content
    validate_document -->|已重試 2 次| WF([結束：回報錯誤])
    save_draft -->|版本衝突| WF
    save_draft -->|成功| notify_review
  end

  subgraph upload_worker [upload_worker 子圖]
    direction TB
    route_upload -->|比對| load_upload --> diff_documents --> check_upload --> send_diff_card
    route_upload -->|寫入| commit_upload --> complete_review
    load_upload -->|格式不符| UF([結束：退回])
    commit_upload -->|eTag 不符| UF
  end
```

### 3.3 Node 一覽

| Node | 類型 | 職責 |
|---|---|---|
| `ingest_event` | 純函式 | 去重事件。決定進入點。 |
| `resolve_target` | Tool | 驗證目標。補上資訊資產代碼。 |
| `confirm_target` | interrupt | 請 SA 確認目標。登記目標。 |
| `load_sources` | Tool | 取得來源文件。記錄版本。 |
| `ask_source` | interrupt | 請 SA 指定來源文件。 |
| `extract_system_scope` | 純函式＋LLM | 摘要職責。附上出處。 |
| `list_candidates` | 純函式＋LLM | 列出候選清單。 |
| `confirm_doc_scope` | interrupt | 請 SA 確認文件範圍。 |
| `init_doc_records` | Tool | 建立狀態紀錄。 |
| `check_sources` | Tool | 檢查改版。設定閘門。 |
| `analyze_source_change` | 純函式＋LLM | 分析改版的影響。 |
| `scheduler` | 純函式 | 挑選下一個工作項目。 |
| `doc_worker` | 子圖 | 產製或修訂一份 SA 文件。 |
| `upload_worker` | 子圖 | 比對或寫入上傳檔。 |
| `post_work` | 純函式 | 記錄結果。處理失敗。 |
| `finalize` | Tool | 寫入完成摘要。 |

## 4. State 規格 ★

### 4.1 Schema

權威定義：`agents/sa-doc-agent/src/state.py`（尚未建立）。

```python
class Target(TypedDict):
    req_id: str               # 需求編號
    mvp_id: str               # MVP 編號
    system_abbr: str          # 系統英文簡稱，例：EDLS
    info_asset_code: str      # 資訊資產代碼，例：TS0108

class Citation(TypedDict):
    source: Literal["consensus", "hld"]
    doc_version: str          # 例：V1.3
    section: str              # 章節名稱
    line_start: int
    line_end: int
    quote: str                # 原文，最多 120 字

class CandidateDoc(TypedDict):
    doc_id: str | None        # SA 服務編號；只有電文提示時為 None
    doc_name: str
    verdict: Literal["change", "no_change", "unclear"]  # Agent 的判斷
    rationale: str
    citations: list[Citation]
    exists_in_repo: bool

class ScopedDoc(TypedDict):   # 範圍卡片的快照
    doc_id: str
    doc_name: str
    origin: Literal["candidate", "manual", "new"]
    reason: str | None        # manual 與 new 必填
    order: int

class WorkItem(TypedDict):
    work_item_id: str         # 冪等鍵的來源，格式見 4.3
    doc_id: str
    mode: Literal["produce", "revise", "upload_diff", "upload_commit"]
    base_version: str | None  # 產製：SharePoint 目前版本；其他：最新草稿
    upload_id: str | None     # 只有上傳檔的工作項目使用
    feedback_ids: list[str]   # 只供 trace；實際內容以 load_baseline 為準
    resumed: bool             # 是否為中斷恢復

class SAAgentState(TypedDict):
    messages: Annotated[list[AnyMessage], add_messages]
    event: Event
    user: UserRef
    proposed_target: Target | None
    target: Target | None
    target_confirmed_by: UserRef | None
    source_override: SourceRefs | None
    sources: SourceRefs | None
    source_gate: Literal["open", "closed"]  # 改版待決時為 closed
    system_scope: SystemScope | None
    candidates: list[CandidateDoc]
    doc_scope: list[ScopedDoc]
    sa_notes: str | None
    current_item: WorkItem | None
    items_this_run: int
    work_log: Annotated[list[WorkResult], operator.add]
    errors: Annotated[list[ErrorInfo], operator.add]
    run_outcome: str | None
```

> **State 不存放狀態。** 狀態只存在 Store（9.3）。State 只存放這次 run 需要的資料（ADR 0003）。

### 4.2 欄位表

| 欄位 | Reducer | 寫入者 | 讀取者 | PII |
|---|---|---|---|:-:|
| `messages` | 累加 | interrupt node、worker、`analyze_source_change` | LLM node | 否 |
| `event` | 覆寫 | 輸入 | `ingest_event` | 否 |
| `user` | 覆寫 | Ingress | interrupt node、稽核 | 是 |
| `proposed_target` | 覆寫 | 輸入 | `resolve_target` | 否 |
| `target` | 覆寫 | `confirm_target` | 全部 | 否 |
| `target_confirmed_by` | 覆寫 | `confirm_target` | 稽核 | 是 |
| `source_override` | 覆寫 | `ask_source` | `load_sources` | 否 |
| `sources` | 覆寫 | 見下方說明 | 分析 node、worker、`finalize` | 否 |
| `source_gate` | 覆寫 | `check_sources`、`analyze_source_change` | `scheduler` | 否 |
| `system_scope` | 覆寫 | 見下方說明 | 分析 node、`doc_worker` | 否 |
| `candidates` | 覆寫 | `list_candidates` | `confirm_doc_scope` | 否 |
| `doc_scope` | 覆寫 | `confirm_doc_scope` | `init_doc_records` | 否 |
| `sa_notes` | 覆寫 | `confirm_doc_scope` | `doc_worker` | 可能 |
| `current_item` | 覆寫 | `scheduler` | worker、`post_work` | 否 |
| `items_this_run` | 覆寫 | `ingest_event`、`scheduler` | `scheduler` | 否 |
| `work_log` | 累加 | `post_work` | `finalize` | 否 |
| `errors` | 累加 | 任何 node | `post_work`、輸出 | 否 |
| `run_outcome` | 覆寫 | `scheduler`、`finalize`、interrupt node | 輸出 | 否 |

欄位說明：

1. `sources` 的寫入者有三個。
   1. `load_sources` 第一次寫入。
   2. `analyze_source_change` 在改版沒有影響時寫入。
   3. `check_sources` 套用 SA 的改版決定時寫入。
2. `system_scope` 的寫入者有三個。
   1. `extract_system_scope` 第一次寫入。
   2. `analyze_source_change` 在改版沒有影響時寫入。
   3. `check_sources` 套用 SA 的改版決定時寫入。
3. `user` 含員編與姓名。trace 遮罩姓名。
4. `target` 確認後不能修改。
5. `doc_scope` 只是快照。追加的 SA 文件直接寫入 Store。
6. `sa_notes` 是資料，不是指令。
7. `ingest_event` 在每次 run 開始時把 `items_this_run` 歸零。
8. SA 要修改目標時，必須開新的 thread。
9. `source_override` 有值時，`load_sources` 不再查詢。

### 4.3 規則與相容策略

1. 每個欄位原則上只有一個寫入者。
2. `messages`、`errors`、`work_log` 使用累加 reducer。
3. 多個寫入者的欄位，其寫入者依序執行，不會並行。
4. 新增欄位必須有預設值。新增欄位是 Minor 變更。
5. 刪除欄位或改型別是 Major 變更。
6. Major 變更必須提供 checkpoint 遷移腳本。
7. 在途 thread 必須能讀取舊的 schema。
8. `resolve_target` 與 `confirm_target` 以外的 node 寫入 `target` 時，程式碼報錯。
9. 產製與修訂的 `work_item_id` 為 `{doc_id}:{mode}:{review_round}`。
10. 上傳檔的 `work_item_id` 為 `{doc_id}:{mode}:{upload_id}`。

## 5. Node 規格 ★

### 5.1 契約總表

| Node | 副作用 | 冪等 | Retry | 逾時 |
|---|---|:-:|---|---|
| `ingest_event` | 寫入去重紀錄 | 是 | 無 | 1s |
| `resolve_target` | 無 | 是 | 3 次 | 10s |
| `confirm_target` | 發卡片；登記目標 | 是 | 無 | 等待 SA |
| `load_sources` | 無 | 是 | 3 次 | 30s |
| `ask_source` | 發卡片；放棄時釋放登記 | 是 | 無 | 等待 SA |
| `extract_system_scope` | 無 | 是 | 2 次 | 120s |
| `list_candidates` | 無 | 是 | 2 次 | 120s |
| `confirm_doc_scope` | 發卡片；寫入 Store | 是 | 無 | 等待 SA |
| `init_doc_records` | 寫入 Store | 是 | 3 次 | 10s |
| `check_sources` | 寫入 Store | 是 | 3 次 | 10s |
| `analyze_source_change` | 寫入 Store；發卡片 | 是 | 2 次 | 300s |
| `scheduler` | 無 | 是 | 無 | 5s |
| `doc_worker` | 寫入 SharePoint 與 Store；發卡片 | 是 | 子圖自訂 | 20 分鐘 |
| `upload_worker` | 寫入 SharePoint 與 Store；發卡片 | 是 | 子圖自訂 | 10 分鐘 |
| `post_work` | 寫入 Store；補發卡片 | 是 | 無 | 5s |
| `finalize` | 寫入 ContextStore | 是 | 3 次 | 30s |

各 Node 的讀寫與失敗行為：

1. `ingest_event`
   1. 讀取：`event`、`target`、Store 的去重紀錄與 `meta.scope`。
   2. 寫入：`items_this_run`。
   3. 失敗：重複事件直接結束 run。
2. `resolve_target`
   1. 讀取：`proposed_target`。
   2. 寫入：`errors`。
   3. 失敗：Agent 標註查無系統。SA 在目標卡片上修正。
3. `confirm_target`
   1. 讀取：`proposed_target`。
   2. 寫入：`target`、`target_confirmed_by`、`run_outcome`、`messages`。
   3. 冪等：卡片以 `card_key` 去重。
   4. 失敗：SA 取消或目標已登記時，run 以 `aborted` 結束。
4. `load_sources`
   1. 讀取：`target`、`source_override`。
   2. 寫入：`sources`、`errors`。
   3. 失敗：Agent 進入 `ask_source`。
5. `ask_source`
   1. 讀取：`target`、`errors`。
   2. 寫入：`source_override`、`run_outcome`、`messages`。
   3. 失敗：SA 放棄時，Agent 釋放登記，run 以 `aborted` 結束。
6. `extract_system_scope`
   1. 讀取：`sources`、`target`。
   2. 寫入：`system_scope`。
   3. 失敗：run 以 `failed` 結束。Agent 通知 SA。
7. `list_candidates`
   1. 讀取：`sources`、`target`、`system_scope`。
   2. 寫入：`candidates`。
   3. 失敗：SharePoint 查詢失敗時，`exists_in_repo` 標為未知。
8. `confirm_doc_scope`
   1. 讀取：`candidates`、`system_scope`。
   2. 寫入：`doc_scope`、`sa_notes`、`messages`。
   3. 副作用：Agent 把 `candidates` 存入 Store 的 `meta`。
   4. 失敗：驗證失敗時，卡片顯示錯誤，Agent 再次 interrupt。
9. `init_doc_records`
   1. 讀取：`doc_scope`、`target`。
   2. 冪等：狀態紀錄已存在時，Agent 跳過。
   3. 失敗：run 以 `failed` 結束。
10. `check_sources`
    1. 讀取：`target`、`sources`、Store 的 `meta.source_change`。
    2. 寫入：`sources`、`system_scope`、`source_gate`。
    3. 失敗：ContextStore 無法使用時，Agent 沿用目前版本。
11. `analyze_source_change`
    1. 讀取：`target`、`sources`、`system_scope`、Store 的狀態紀錄。
    2. 寫入：`source_gate`、`messages`。
    3. 寫入（沒有影響時）：`sources`、`system_scope`。
    4. 冪等鍵：`{from_version}->{to_version}`。
    5. 失敗：Agent 關閉閘門，通知 SA，發出 P2 告警。
12. `scheduler`
    1. 讀取：Store、`items_this_run`、`source_gate`。
    2. 寫入：`current_item`、`items_this_run`、`run_outcome`。
13. `doc_worker` 與 `upload_worker`
    1. 讀取：`current_item`、`sources`、`system_scope`、`sa_notes`。
    2. 寫入：`messages`、`errors`。
    3. 失敗：Agent 把錯誤寫入 `errors`，交給 `post_work`。
14. `post_work`
    1. 讀取：`current_item`、`errors`。
    2. 寫入：`work_log`。
    3. 副作用：失敗時，Agent 記錄 `last_error`。
    4. 副作用：Agent 依 9.4 判斷暫停。
    5. 副作用：Agent 補發失敗的覆核卡片。
    6. 副作用：Agent 更新進度卡片。
15. `finalize`
    1. 讀取：Store、`target`、`sources`、`work_log`。
    2. 寫入：`run_outcome`。
    3. 冪等鍵：`finalize:{thread_id}:{共識書版本}`。
    4. 失敗：run 以 `failed` 結束。下次 `wake` 時 Agent 重試。
    5. 改版後再次完成時，Agent 會再寫入一次。

### 5.2 關鍵 Node 詳述

#### 5.2.1 `extract_system_scope`

1. Agent 依章節標題找到以下章節：
   1. 第 2 節「方案定位」。
   2. 第 3 節「系統分工摘要」的 6 張表。
   3. 第 4 節「配合測試系統清單」。
   4. 第 5 節「本次不處理範圍」。
   5. 第 11 節「業務規則確認清單」。
2. Agent 清除 emoji 與粗體標記。
3. Agent 逐列比對系統欄位。
4. Agent 接受三種寫法：簡稱、代碼、簡稱加代碼。
5. Agent 排除標示「移至」或「已移出」的列。
6. Agent 不採用第 3 節的 ASCII 呼叫鏈。
7. Agent 不採用第 6 節「未採用方案」。
8. LLM 把命中的內容整理成職責摘要。
   1. 主責項目。
   2. 配合事項。
   3. 資料與規則的維護責任。
   4. 不處理的項目。
   5. 相關的 BR 與未結的 CL。
9. LLM 為每一條摘要附上出處。
10. Agent 檢查每個出處的行號存在。
11. Agent 檢查每個出處的原文存在。比對時，Agent 忽略空白差異。
12. Agent 刪除沒有出處的摘要。
13. Agent 把刪除的摘要記入 `errors`。
14. Agent 用相同方式處理高階需求說明。
15. 兩份來源文件衝突時，Agent 並列兩邊的內容。
16. Agent 標示「來源不一致」。
17. SA 判斷哪一邊正確。Agent 不自行裁決。

#### 5.2.2 `list_candidates`

1. Agent 用正則 `[A-Z]{2}\d{4}-SA-\d{6}-\d{5}` 抽出 SA 服務編號。
2. Agent 只保留本系統的資訊資產代碼。
3. LLM 依所有出現位置判斷每份 SA 文件的異動。
4. 判斷為 `change` 時，Agent 預設勾選。
5. 判斷為 `no_change` 時，Agent 不勾選。Agent 附上原文。
6. 判斷為 `unclear` 時，Agent 不勾選。Agent 標示黃色。
7. Agent 加入此需求曾經關聯的 SA 文件，判斷為 `unclear`。
8. Agent 查詢每份 SA 文件是否在 SharePoint。
9. Agent 取得每份 SA 文件的目前版本。
10. 本系統沒有 SA 服務編號時，候選清單為空。
11. 候選清單為空時，Agent 列出相關電文作為提示。

說明：同一個 SA 服務編號可能同時出現在「改」與「不改」的語境。因此 LLM 必須讀取所有出現位置。

#### 5.2.3 文件範圍驗證規則

`confirm_doc_scope` 與追加卡片使用同一個函式 `validate_doc_scope()`。程式碼強制執行以下規則：

1. SA 只能勾選候選清單中的 SA 文件。
2. 手動加入的 SA 服務編號必須符合正則。
3. 手動加入的資訊資產代碼必須是本系統。
4. 手動加入的 SA 文件必須在 SharePoint。
5. 手動加入的 SA 文件不在 SharePoint 時，卡片提供「改為新文件」。
6. 手動加入必須寫原因。
7. 新文件必須寫名稱與原因。
8. Agent 依命名規則產生新文件的暫定編號。
9. SA 可以修改暫定編號。
10. 文件範圍最多 20 份，包含追加（暫定）。
11. 追加只能新增 SA 文件。
12. 追加不能重複加入已存在的 SA 文件。
13. 追加時，SA 只能勾選尚未加入的候選項目。
14. 追加不能移除 SA 文件。SA 要使用「移出」。
15. 設定檔的 `max_docs_per_scope` 決定數量上限。

#### 5.2.4 `scheduler` 優先序

`scheduler` 每一輪執行以下步驟：

1. `scheduler` 從 Store 讀取所有狀態紀錄。
2. `scheduler` 排除暫停的 SA 文件。
3. `scheduler` 排除移出的 SA 文件。
4. `scheduler` 依以下優先序挑選一個工作項目：
   1. **中斷恢復**：狀態為「產製中」或「修訂中」的 SA 文件。閘門關閉時也執行。
   2. **寫入上傳檔**：上傳階段為 `confirmed` 的 SA 文件。閘門關閉時也執行。
   3. **比對上傳檔**：上傳階段為 `received` 的 SA 文件。閘門關閉時也執行。
   4. **閘門檢查**：閘門關閉時，`scheduler` 停止挑選，run 結束。
   5. **待修訂**：符合以下全部條件的 SA 文件。
      1. 狀態為「SA覆核中」。
      2. 有排隊的回饋，或有重做要求。
      3. 沒有進行中的上傳。
   6. **待產製**：狀態為「待產製」的 SA 文件，依 `order` 排序。
5. 沒有工作項目時，`scheduler` 檢查未移出的 SA 文件。
6. 未移出的 SA 文件全部完成時，`scheduler` 前往 `finalize`。
7. SA 移出了全部 SA 文件時，結果為 `no_change`。
8. 其他情況，run 以 `awaiting_review` 結束。
9. 這時，輸出列出等待覆核與暫停的 SA 文件。

補充規則：

1. 待修訂的 SA 文件依最早一筆回饋的時間排序。
2. 新 run 開始時，可能有 SA 文件停在「產製中」或「修訂中」。
3. 這些 SA 文件一定是前一次 run 中斷留下的。
4. `items_this_run` 達到上限時，run 結束。
5. 這時輸出 `continue_pending = true`。
6. Ingress 看到 `continue_pending` 後，送出 `wake`。
7. `scheduler` 沒有副作用。

這個優先序實現「回饋排隊」：

1. `scheduler` 不中斷執行中的 `doc_worker`。
2. 下一輪 `scheduler` 才會挑到回饋。
3. 修訂優先於下一份產製。

#### 5.2.5 `doc_worker` 子圖

`doc_worker` 依序執行以下步驟：

1. `load_baseline` 改變狀態。
   1. 產製時，狀態從「待產製」改為「產製中」。
   2. 修訂時，狀態從「SA覆核中」改為「修訂中」。
   3. 修訂時，Agent 把排隊的回饋移到處理中。
   4. 修訂時，Agent 把重做要求轉成一筆系統回饋。
   5. Agent 把這筆系統回饋也移到處理中。
   6. Agent 以同一次 CAS 完成步驟 2 到 5。
   7. 回饋與重做要求都已撤回時，Agent 放棄工作項目。
   8. 放棄時，Agent 不改變狀態。
   9. 產製時，Agent 清除重做要求。
   10. 中斷恢復時，狀態可能已經正確。
   11. 這時，Agent 跳過轉換，沿用處理中的回饋。
2. `load_baseline` 讀取基準內容。
   1. 產製現有 SA 文件時，Agent 讀取 SharePoint 的目前版本。
   2. 產製新文件時，Agent 讀取 SA 範本。
   3. 產製新文件時，Agent 也可以參考此需求用過的同系統 SA 文件。
   4. 修訂時，Agent 讀取最新草稿與處理中的回饋。
3. `plan_changes`：LLM 產生變更計畫。
   1. 計畫列出要改的章節。
   2. 計畫為每一項變更附上依據。
   3. 修訂時，計畫為每一筆回饋標示「已處理」或「不處理」。
   4. 標示「不處理」時，計畫附上原因。
4. `draft_content`：LLM 逐章節產製內容。LLM 只能改計畫內的章節。
5. `generate_diagrams`：Agent 產生需要的圖。
   1. 流程圖使用 Mermaid flowchart。
   2. 循序圖使用 Mermaid sequence。
   3. API Spec 使用 OpenAPI 3。
   4. 沒有受影響的圖時，Agent 跳過這一步。
6. `assemble_document`：Agent 依 SA 範本組裝 SA 文件。Agent 在附錄加上變更摘要與出處。
7. `validate_document`：程式碼檢查 SA 文件。
   1. 範本的必要章節都存在。
   2. Mermaid 可以解析。
   3. OpenAPI 通過驗證。
   4. 每一項變更都有出處。
   5. Agent 沒有改到計畫外的章節。
   6. SA 文件沒有修改其他系統的 SA 服務。
8. 驗證未通過時，Agent 回到步驟 4。Agent 最多重試 2 次。
9. `save_draft`：Agent 把 SA 文件寫入 SharePoint，成為草稿。
   1. Agent 寫入前比對 eTag。
   2. eTag 不符時，Agent 停止寫入（E-9）。
   3. 結果不確定時，Agent 先查詢再重寫。
10. `notify_review` 執行以下步驟。
    1. Agent 把狀態改為「SA覆核中」。
    2. 修訂時，Agent 把處理中的回饋移到已處理。
    3. Agent 更新變更摘要。
    4. Agent 發出覆核卡片。

順序規則：

1. Agent 在草稿寫入成功後，才改變狀態。
2. Agent 在狀態改變後，才發出覆核卡片。
3. 每次狀態轉換都使用 CAS（9.3）。
4. 中斷恢復時，Agent 跳過狀態已經正確的步驟。

冪等鍵：

1. `save_draft` 的冪等鍵為 `{doc_id}:{work_item_id}`。
2. `notify_review` 的冪等鍵為 `{doc_id}:{work_item_id}:notify`。

#### 5.2.6 改版的偵測與處理

**`check_sources` 的步驟**

1. `check_sources` 先檢查 SA 是否已經做出改版決定。
2. SA 已經決定時，`check_sources` 套用決定。
   1. Agent 把 `sources` 改為新版。
   2. Agent 把 `system_scope` 改為改版紀錄中的 `new_scope`。
   3. Agent 開啟閘門。
   4. Agent 把改版紀錄標為 `applied`。
3. `check_sources` 查詢來源文件的最新版本。
4. 有尚未分析的新版本時，Agent 前往 `analyze_source_change`。
5. 新的分析會取代尚未決定的舊分析。
   1. Agent 把舊的改版紀錄標為 `superseded`。
   2. Agent 更新舊的改版卡片，請 SA 看新卡片。
6. 改版紀錄為 `awaiting_decision` 時，Agent 關閉閘門。
7. 其他情況，Agent 開啟閘門。

**`analyze_source_change` 的步驟**

1. Agent 讀取新版的來源文件。
2. Agent 依標題把來源文件切成章節。
3. Agent 逐章節比對新舊版本。
4. Agent 列出新增、刪除、修改的章節。
5. Agent 用 5.2.1 與 5.2.2 的邏輯處理新版。
6. Agent 比較新舊的職責摘要。
7. Agent 比較新舊的候選清單。
8. LLM 判斷每份 SA 文件是否受影響。
9. LLM 為每個判斷附上理由與出處。
10. Agent 依結果走「沒有影響」或「有影響」的路徑。

**護欄規則**：程式碼強制執行護欄規則。變動章節提到以下任何一項時，Agent 不能判定為沒有影響。

1. 本系統的英文簡稱。
2. 本系統的資訊資產代碼。
3. 本系統的 SA 服務編號。

**沒有影響的路徑**

條件：沒有 SA 文件受影響、職責與候選清單都沒變、護欄沒有觸發。

1. Agent 把 `sources` 改為新版。
2. Agent 把 `system_scope` 改為新版。
3. Agent 把改版紀錄標為 `applied_no_impact`。
4. Agent 通知 SA：「共識書已更新，與本系統無關」。
5. Agent 附上變動章節的摘要。
6. Agent 繼續工作。

**有影響的路徑**

1. Agent 把分析結果寫入 `meta.source_change`。
2. Agent 把改版紀錄標為 `awaiting_decision`。
3. Agent 關閉閘門。
4. Agent 發出改版卡片。

**SA 決定後的處理**

Ingress 在 SA 確認改版卡片時處理每份 SA 文件。Ingress 把重做要求寫入 `source_rework`。Ingress 不把重做要求寫入回饋佇列。因此，任何狀態都可以登記重做要求。

| 目前狀態 | SA 選「重做」 | SA 選「不重做」 |
|---|---|---|
| 待產製 | 不處理。Agent 產製時會用新版。 | 不處理 |
| SA覆核中 | Ingress 登記重做要求。Agent 之後修訂。 | 不處理 |
| 完成 | Ingress 把狀態改回「SA覆核中」。Ingress 登記重做要求。 | 不處理 |
| 產製中 | Ingress 登記重做要求。`load_baseline` 會清除它。 | 不處理 |
| 修訂中 | Ingress 登記重做要求。Agent 修訂完成後再修訂一次。 | 不處理 |

補充規則：

1. 移出的 SA 文件不列入改版卡片。
2. SA 可以在改版卡片上加入新的候選項目。
3. 新的候選項目使用 5.2.3 的驗證規則。
4. SA 可以移出不再相關的 SA 文件。
5. 移出必須寫原因。
6. 「SA覆核中」的 SA 文件有進行中的上傳時，改版卡片顯示提示。
7. 提示內容：上傳確認時，重做要求會視為由上傳檔處理。

#### 5.2.7 `upload_worker` 子圖

SA 在「SA覆核中」的覆核卡片上傳上傳檔。Ingress 執行以下步驟：

1. Ingress 把上傳檔存入暫存區。
2. Ingress 記錄上傳檔的雜湊值。
3. Ingress 在狀態紀錄登記上傳，狀態為 `received`。
4. Ingress 送出 `wake`。

**比對上傳檔（`upload_diff`）**

1. `route_upload` 依工作項目分流。
2. `load_upload` 讀取上傳檔。
   1. Agent 比對雜湊值。
   2. Agent 把上傳檔依章節切分。
   3. Agent 確認上傳檔是同一份 SA 文件。
   4. 檢查失敗時，Agent 清除上傳登記。
   5. 檢查失敗時，Agent 刪除暫存檔。
   6. Agent 通知 SA（E-13）。
3. `diff_documents` 比對上傳檔與最新草稿。
   1. 程式碼計算差異。
   2. LLM 只把差異整理成摘要。
   3. Agent 以相似度比對版本歷程，推測上傳檔的基礎版本。
   4. 基礎版本不是最新草稿時，Agent 列出上傳檔會覆蓋的變更（E-14）。
   5. 差異卡片把基礎版本標示為「推測」。
4. `check_upload` 檢查上傳檔。`check_upload` 為檢查結果產生警示。
   1. Agent 檢查範本的必要章節。
   2. Agent 檢查 Mermaid 與 OpenAPI。
   3. Agent 檢查是否修改其他系統的 SA 服務。
   4. 發現疑似客戶個資時，Agent 擋下上傳檔。
   5. 擋下時，Agent 清除上傳登記。
   6. Agent 刪除暫存檔。
   7. Agent 請 SA 移除個資後重新上傳。
   8. 其他檢查結果只作為警示。
5. `send_diff_card` 執行以下步驟。
   1. Agent 先核對 `upload_id` 與上傳階段。
   2. 核對失敗時，Agent 結束，不發卡片。
   3. Agent 寫入差異摘要、警示與目前的 eTag。
   4. Agent 把上傳階段改為 `diff_ready`。
   5. Agent 發出差異卡片。

差異卡片的內容：

1. 變更摘要。
2. 逐章節差異。
3. 警示。
4. 未處理回饋的數量。
5. 重做要求（如果有）。
6. 說明：確認後，回饋與重做要求視為由上傳檔處理。
7. 按鈕：「確認並完成」、「取消」。

**寫入上傳檔（`upload_commit`）**

SA 按「確認並完成」後，Agent 才執行以下步驟：

1. `commit_upload` 把上傳檔寫入 SharePoint。
   1. Agent 帶上比對時的 eTag。
   2. eTag 不符時，Agent 不覆蓋。
   3. eTag 不符時，Agent 把上傳階段改為 `stale`。
   4. Agent 通知 SA（E-15）。
   5. 其他錯誤時，Agent 保持 `confirmed`，下一輪重試。
   6. 失敗 2 次後，Agent 把上傳階段改為 `stale`。
   7. 這時，Agent 通知 SA。
   8. 結果不確定時，Agent 先查詢 `AgentWorkItemId`。
2. `complete_review` 完成 SA 文件。
   1. Agent 核對 SA 文件沒有移出。
   2. Agent 核對 `upload_id`。
   3. Agent 以一次 CAS 執行步驟 4 到 11。
   4. Agent 把狀態從「SA覆核中」改為「完成」。
   5. Agent 記錄操作者為確認的 SA，`actor_type` 為 `sa_upload`。
   6. Agent 把目前版本與基準版本改為剛寫入的版本。
   7. Agent 把變更摘要改為差異摘要。
   8. Agent 把 `review_round` 加 1。
   9. Agent 把未處理的回饋移到已處理，註明「由上傳檔取代」。
   10. Agent 把重做要求移到已處理，註明「由上傳檔取代」。
   11. Agent 清除上傳登記。
   12. Agent 在 SharePoint 標記「SA 已覆核」。
   13. Agent 刪除暫存檔。
   14. Agent 通知 SA。

上傳規則：

1. 上傳失敗不使用暫停旗標。
2. 上傳失敗時，SA 直接重新上傳或取消。
3. Agent 不改寫上傳檔（ADR 0011）。
4. SA 確認的對象是差異本身。

冪等鍵：

1. `commit_upload` 在 SharePoint 欄位記錄 `AgentWorkItemId`。
2. `complete_review` 的冪等鍵為 `{doc_id}:{upload_id}:done`。

## 6. Edge 與控制流 ★

### 6.1 路由表

| 來源 | 條件 | 目標 |
|---|---|---|
| `ingest_event` | 事件重複 | END |
| `ingest_event` | 目標為空 | `resolve_target` |
| `ingest_event` | Store 有 `meta.scope` | `check_sources` |
| `ingest_event` | 否則 | `load_sources` |
| `confirm_target` | SA 確認，驗證通過 | `load_sources` |
| `confirm_target` | SA 取消，或目標已登記 | END（aborted） |
| `confirm_target` | 否則（驗證失敗） | `confirm_target` |
| `load_sources` | 找到唯一的來源文件 | `extract_system_scope` |
| `load_sources` | 否則 | `ask_source` |
| `ask_source` | SA 指定來源文件 | `load_sources` |
| `ask_source` | 否則（SA 放棄） | END（aborted） |
| `confirm_doc_scope` | 文件範圍不是空的 | `init_doc_records` |
| `confirm_doc_scope` | 文件範圍為空，SA 再確認 | `finalize` |
| `confirm_doc_scope` | 否則（驗證失敗） | `confirm_doc_scope` |
| `init_doc_records` | 一律 | `check_sources` |
| `check_sources` | 有未分析的新版本 | `analyze_source_change` |
| `check_sources` | 否則 | `scheduler` |
| `analyze_source_change` | 一律 | `scheduler` |
| `scheduler` | 達到單次上限 | END（awaiting_review） |
| `scheduler` | 產製或修訂 | `doc_worker` |
| `scheduler` | 比對或寫入上傳檔 | `upload_worker` |
| `scheduler` | 沒有工作，閘門關閉 | END（awaiting_source_decision） |
| `scheduler` | 沒有工作，未移出的 SA 文件全部完成 | `finalize` |
| `scheduler` | 否則 | END（awaiting_review） |
| `doc_worker`、`upload_worker` | 一律 | `post_work` |
| `post_work` | 一律 | `check_sources` |
| `load_baseline` | 回饋與重做要求都已撤回 | 子圖結束 |
| `load_baseline` | 否則 | `plan_changes` |
| `validate_document` | 通過 | `save_draft` |
| `validate_document` | 未通過，重試少於 2 次 | `draft_content` |
| `validate_document` | 否則 | 子圖結束 |
| `save_draft` | 成功 | `notify_review` |
| `save_draft` | 否則 | 子圖結束 |
| `route_upload` | 比對上傳檔 | `load_upload` |
| `route_upload` | 否則（寫入上傳檔） | `commit_upload` |
| `load_upload` | 檢查通過 | `diff_documents` |
| `load_upload` | 否則 | 子圖結束 |
| `commit_upload` | 寫入成功 | `complete_review` |
| `commit_upload` | 否則 | 子圖結束 |

### 6.2 規則

**主迴圈**

1. `check_sources` 執行。
2. `scheduler` 挑選工作項目。
3. worker 處理工作項目。
4. `post_work` 記錄結果。
5. 回到步驟 1。

**終止保證**

1. 每一輪都會讓一份 SA 文件的狀態前進。
2. 或者，`post_work` 設定暫停。
3. 或者，Agent 放棄已撤回的工作項目。
4. `scheduler` 不挑選暫停的 SA 文件。
5. 單次 run 最多處理 40 個工作項目（暫定）。
6. 因此，每次 run 一定會結束。

設定單次上限的理由：回饋會在 run 執行中持續進來。沒有上限時，run 可能一直延長。

**`recursion_limit = 250`**

主圖最長路徑的估算：

1. 前段最多 10 個 node。
2. 每個工作項目 4 步，共 40 個，合計 160 步。
3. 改版分析保守估 5 次。
4. `finalize` 等收尾 2 步。
5. 合計 177 步。

說明：interrupt 會把前段分散到多次 run。這裡取保守上界。

子圖最長路徑：

1. `doc_worker` 正常 8 步。
2. 每次驗證重試多 4 步。
3. 最多重試 2 次，合計 16 步。
4. `upload_worker` 最長 5 步。

**其他規則**

1. 所有路由函式都是純函式。
2. 路由函式不呼叫 LLM。
3. Agent 不使用 `Send` 並行（ADR 0008）。

## 7. Tool 與外部整合 ○

| Tool | 用途 | 讀寫 | 冪等鍵 | 逾時 |
|---|---|---|---|---|
| `context_store.get` | 取得來源文件 | 讀 | — | 10s |
| `context_store.latest_versions` | 查詢最新版本號 | 讀 | — | 5s |
| `context_store.put` | 寫入完成摘要 | 寫 | `finalize:{thread_id}:{版本}` | 10s |
| `system_registry.lookup` | 查詢資訊資產代碼與 SA 名單 | 讀 | — | 5s |
| `doc_repo.get` | 讀取 SA 文件的指定版本 | 讀 | — | 15s |
| `doc_repo.latest_version` | 取得最新版本與 eTag | 讀 | — | 5s |
| `doc_repo.versions` | 取得版本歷程 | 讀 | — | 5s |
| `doc_repo.exists` | 檢查 SA 文件是否存在 | 讀 | — | 5s |
| `doc_repo.save_draft` | 寫入草稿 | 寫 | `{doc_id}:{work_item_id}` | 30s |
| `doc_repo.save_upload` | 寫入上傳檔 | 寫 | `{doc_id}:{upload_id}` | 30s |
| `doc_repo.mark_reviewed` | 標記「SA 已覆核」 | 寫 | `{doc_id}:{version}:reviewed` | 10s |
| `upload_staging.get` | 讀取暫存的上傳檔 | 讀 | — | 15s |
| `template_engine` | 取得範本、組裝 SA 文件 | 讀 | — | 30s |
| `diagram_generator` | 產生並驗證圖與 API Spec | 讀 | — | 60s |
| `teams.send_card` | 發送卡片 | 寫 | `card_key` | 10s |
| `teams.update_card` | 更新卡片 | 寫 | `card_key` | 10s |
| `doc_status` | 讀取與轉換狀態 | 寫 | `expected_seq` | 2s |

權限規則：

1. `doc_repo` 只能讀寫本系統的 SA 文件。
2. tool 層從 SA 服務編號取出代碼。tool 層確認代碼屬於本系統。
3. `teams` 只能發給本 thread 的 SA 與本系統的 SA 名單。
4. `doc_status` 只能寫本 thread 的 namespace。

失敗規則：

1. `context_store.get` 找不到資料時回傳空值。
2. `context_store.latest_versions` 失敗時，Agent 沿用目前版本。
3. `doc_repo.get` 回傳 404 時，代表 SA 文件不存在。
4. 寫入時回傳 412，代表 eTag 不符。Agent 不重試。
5. 寫入逾時時，Agent 先查詢版本歷程，再決定是否重寫。
6. `teams.send_card` 失敗 3 次後，Agent 記錄待補發。
7. `post_work` 補發失敗的卡片。
8. `doc_status` 的 CAS 失敗時，Agent 重新讀取後再判斷。
9. `upload_staging.get` 的雜湊不符時，Agent 拒絕上傳檔。
10. `context_store.put` 失敗時，Agent 重試。
11. `template_engine` 失敗時，Agent 重試。
12. `diagram_generator` 驗證失敗時，回傳錯誤清單。

API Owner：

1. ContextStore 團隊負責 `context_store`。
2. SharePoint 管理者負責 `doc_repo`。
3. Teams Bot 團隊負責 `teams`。
4. 本團隊負責 `doc_status` 與 `upload_staging`。
5. `system_registry`、`template_engine`、`diagram_generator` 的 Owner 待填。

### 7.1 SharePoint 整合

**存取方式**

1. Agent 透過 Microsoft Graph API 存取 SharePoint。
2. Agent 使用專用的服務主體。
3. 服務主體的權限為 `Sites.Selected`。
4. 服務主體只能存取 SA 文件所在的網站。
5. tool 層把寫入範圍限定在本系統。

**版本策略**

1. Agent 每次寫入都是次要版本，例：2.1、2.2。
2. 次要版本就是草稿。
3. Agent 不發布主要版本。
4. SA 覆核完成時，Agent 在欄位標記「SA 已覆核」。

**樂觀鎖**

1. Agent 讀取 SA 文件時，記錄 eTag。
2. Agent 寫入時，帶上 `If-Match`。
3. eTag 不符代表有人修改過 SA 文件。
4. eTag 不符時，Agent 不覆蓋（E-9、E-15）。

**冪等**

1. Graph API 沒有冪等鍵。
2. Agent 在欄位 `AgentWorkItemId` 記錄工作項目 ID。
3. 結果不確定時，Agent 查詢版本歷程中的 `AgentWorkItemId`。
4. 已經寫入時，Agent 不重寫。

**自訂欄位**（SharePoint 管理者建立）

| 欄位 | 用途 |
|---|---|
| `AgentWorkItemId` | 記錄寫入的工作項目 |
| `AgentDocStatus` | 顯示狀態。Store 是唯一真相。 |
| `SAReviewedBy` | 記錄覆核的 SA |
| `SAReviewedAt` | 記錄覆核時間 |

**檔案格式**：SA 文件的格式尚未確認（15.3 #7）。格式會影響文件組裝與上傳檔的比對。

## 8. 模型與 Prompt 管理 ★

| Node | 模型角色 | 參數 | 輸出格式 |
|---|---|---|---|
| `extract_system_scope` | 推理模型 | temperature 0 | `SystemScope` |
| `list_candidates` | 中型模型 | temperature 0 | `list[CandidateDoc]` |
| `analyze_source_change` | 推理模型 | temperature 0 | `SourceChangeAnalysis` |
| `plan_changes` | 推理模型 | temperature 0 | `ChangePlan` |
| `draft_content` | 大型寫作模型 | temperature 0.2 | Markdown |
| `generate_diagrams` | 中型模型 | temperature 0 | Mermaid 或 OpenAPI |
| `diff_documents` | 中型模型 | temperature 0 | `UploadDiffSummary` |
| Ingress 意圖判斷 | 小型模型 | temperature 0 | `Intent` |

輸出規則：

1. `extract_system_scope` 與 `analyze_source_change` 的輸出附上出處。
2. `generate_diagrams` 的輸出必須通過 parser 驗證。
3. `diff_documents` 只整理程式碼算出的差異。
4. `diff_documents` 不判斷差異是否存在。

管理規則：

1. 本規格只寫模型角色。
2. 模型型號放在 `config/models.yaml`。
3. Prompt 放在 `prompts/<node>.v<N>.md`。
4. 共識書的章節規則放在 `config/consensus_layout.yaml`。
5. 共識書格式改版時，團隊只改設定，不改 prompt。
6. Prompt、模型或章節規則的變更必須附上 eval 報告。
7. 變更必須通過 13.3 的門檻，才能合併。

Fallback 規則：

1. 主要模型無法使用時，分析類 node 改用備援模型。
2. Agent 在 trace 標記 `degraded=true`。
3. `draft_content` 不使用備援模型。
4. `draft_content` 的主要模型無法使用時，Agent 暫停並通知 SA。
5. 理由：品質不足的 SA 文件會增加 SA 的負擔。

## 9. Memory 與 Persistence ○

### 9.1 Checkpoint 與短期記憶

| 項目 | 決定 |
|---|---|
| Checkpointer | 正式環境用 Postgres。測試環境用 in-memory。 |
| `thread_id` | `sa:{uuid}`。Agent 在 `start` 時產生。 |
| 保留期限 | 完成後保留 180 天（暫定，15.3 #5）。 |
| 訊息修剪 | `messages` 只保留最近 30 則。 |
| 訊息摘要 | Agent 把較早的訊息摘要成一則。 |

短期記憶規則：

1. Agent 不把 SA 文件內容放進 `messages`。
2. Agent 只放 SharePoint 連結與版本。

Replay 限制：

1. 以下 node 執行後，團隊不能對該 checkpoint 做 replay 分岔：
   1. `save_draft`
   2. `notify_review`
   3. `commit_upload`
   4. `complete_review`
   5. `finalize`
2. 理由：replay 會重複寫入或重複發卡片。
3. 團隊只能在測試環境做 replay 除錯。

### 9.2 長期記憶（Store）

| Namespace | Key | 內容 |
|---|---|---|
| `("sa_doc_agent", "threads")` | `{req_id}:{mvp_id}:{system_abbr}` | 登錄表 |
| `("sa_doc_agent", ..., "docs")` | `doc_id` | 狀態紀錄（9.3） |
| `("sa_doc_agent", ..., "meta")` | `"scope"` | 文件範圍的確認紀錄 |
| `("sa_doc_agent", ..., "meta")` | `"source_change"` | 改版紀錄 |
| `("sa_doc_agent", "events", thread_id)` | `event.id` | 去重紀錄 |

`...` 代表 `req_id, mvp_id, system_abbr`。

各 Namespace 的規則：

1. 登錄表
   1. 內容：`thread_id`、建立者、建立時間。
   2. `confirm_target` 以「不存在才寫入」登記。
   3. SA 在 `ask_source` 放棄時，Agent 釋放登記。
   4. Agent 只刪除 `thread_id` 相符的那筆。
2. 狀態紀錄
   1. 寫入者：`init_doc_records`、worker、`post_work`、Ingress。
3. 文件範圍的確認紀錄
   1. 內容：確認者、時間、`sa_notes`、來源文件版本、候選清單。
   2. 寫入者：`confirm_doc_scope`。
4. 改版紀錄
   1. 內容：新舊版本與差異摘要。
   2. 內容：職責與候選清單的變動。
   3. 內容：每份 SA 文件的影響判斷（`doc_impacts`）。
   4. 內容：新版的職責摘要（`new_scope`）。
   5. 內容：新版的候選清單（`new_candidates`）。
   6. 內容：決定者（`decided_by`）與決定內容（`decision`）。
   7. 紀錄值：`awaiting_decision`、`decided`、`applied`、`applied_no_impact`、`superseded`。
   8. 寫入者：`analyze_source_change`、`check_sources`、Ingress。
   9. Agent 在 `history` 保留歷次改版。
5. 去重紀錄
   1. 以 `thread_id` 分區。
   2. 目標確認前也能使用。

隱私規則：Agent 不在 Store 存放 SA 的個人偏好。

### 9.3 狀態機

**狀態定義**

| 狀態 | 代碼 | 寫入者 |
|---|---|---|
| 待產製 | `QUEUED` | `init_doc_records`、Ingress |
| 產製中 | `PRODUCING` | `load_baseline` |
| SA覆核中 | `IN_REVIEW` | `notify_review`、Ingress |
| 修訂中 | `REVISING` | `load_baseline` |
| 完成 | `DONE` | Ingress、`complete_review` |

進入時機：

1. 待產製：SA 確認文件範圍或追加 SA 文件後。
2. 產製中：Agent 開始產製時。
3. SA覆核中：Agent 寫入草稿並請 SA 覆核時。
4. 修訂中：Agent 開始處理回饋時。
5. 完成：SA 回覆覆核完成時。
6. 完成：SA 確認上傳檔的差異，Agent 寫入成功後。

「待產製」是內部狀態（ADR 0004）。

```mermaid
stateDiagram-v2
  [*] --> QUEUED: SA 確認範圍或追加
  QUEUED --> PRODUCING: Agent 開始產製
  PRODUCING --> IN_REVIEW: Agent 寫入草稿
  IN_REVIEW --> REVISING: Agent 開始修訂
  REVISING --> IN_REVIEW: Agent 完成修訂
  IN_REVIEW --> DONE: SA 覆核完成
  IN_REVIEW --> DONE: Agent 寫入上傳檔
  DONE --> IN_REVIEW: 改版決定為重做
  DONE --> [*]
  note right of IN_REVIEW
    收到回饋：放進佇列
    撤回回饋：移出佇列
    重做要求：登記後排修訂
    上傳檔：登記後等 SA 確認
  end note
  note left of REVISING
    收到回饋：放進佇列
    本輪修訂後再處理
  end note
```

圖中的 note 是佇列操作，不是狀態轉換。暫停與移出是旗標，不是狀態（9.4）。

**轉換規則**

`doc_status` 強制執行以下轉換。`doc_status` 拒絕其他轉換。

| 從 | 到 | 觸發者 |
|---|---|---|
| — | 待產製 | `init_doc_records`、Ingress |
| 待產製 | 產製中 | `load_baseline` |
| 產製中 | SA覆核中 | `notify_review` |
| SA覆核中 | 修訂中 | `load_baseline` |
| 修訂中 | SA覆核中 | `notify_review` |
| SA覆核中 | 完成 | Ingress |
| SA覆核中 | 完成 | `complete_review` |
| 完成 | SA覆核中 | Ingress |

各轉換的前置條件：

1. 建立「待產製」：狀態紀錄不存在。
2. 待產製 → 產製中：沒有暫停，沒有移出。
3. 產製中 → SA覆核中：草稿寫入成功。
4. SA覆核中 → 修訂中：
   1. 有排隊的回饋，或有重做要求。
   2. Agent 把兩者移到處理中。
5. 修訂中 → SA覆核中：
   1. 草稿寫入成功。
   2. Agent 把處理中的回饋移到已處理。
6. SA覆核中 → 完成（Ingress）：
   1. SA 按「覆核完成」。
   2. 沒有排隊的回饋。
   3. 沒有重做要求。
   4. 沒有進行中的上傳。
   5. SA 在本系統的 SA 名單內。
7. SA覆核中 → 完成（`complete_review`）：
   1. 上傳階段為 `confirmed`。
   2. 確認的 SA 在本系統的 SA 名單內。
   3. 上傳檔已寫入 SharePoint。
8. 完成 → SA覆核中：
   1. SA 在改版卡片上選「重做」。
   2. 改版紀錄為 `awaiting_decision`。
   3. Ingress 同時登記重做要求。
   4. Ingress 把 `review_round` 加 1。
   5. 這是唯一能重新開啟「完成」的方式。

**佇列規則**

1. 回饋
   1. Ingress 只在「SA覆核中」與「修訂中」受理回饋。
   2. 「SA覆核中」有進行中的上傳時，Ingress 不受理回饋。
   3. 受理的回饋放進佇列，狀態不變。
   4. 「修訂中」收到的回饋，在本輪修訂後處理。
2. 撤回
   1. SA 只能撤回排隊中的回饋。
   2. SA 不能撤回處理中的回饋。
3. 上傳
   1. 「進行中的上傳」指上傳登記不是空的。
   2. 「進行中的上傳」包含 `stale`。
   3. Ingress 只在「SA覆核中」受理上傳檔。
   4. 上傳階段為 `stale` 時，新上傳檔取代舊上傳檔。
   5. 有進行中的上傳時，`scheduler` 不排修訂。

**CAS 規則**

1. 每次轉換都帶 `expected_status` 與 `expected_seq`。
2. 轉換成功後，`seq` 加 1。
3. 佇列操作也使用 CAS。
4. Ingress 與 graph 同時操作時，CAS 防止互相覆蓋。

### 9.4 暫停與移出

暫停與移出是旗標。旗標不改變狀態。

**暫停**

1. 暫停只用於 `doc_worker` 的工作項目。
2. `post_work` 在以下情況設定暫停：
   1. eTag 不符：立即設定。
   2. `validate_document` 重試 2 次仍失敗：立即設定。
   3. 可重試的失敗（例如 tool 錯誤）累計 2 次：設定。
3. 暫停的效果：
   1. `scheduler` 不挑選這份 SA 文件。
   2. 進度卡片顯示原因與按鈕。
   3. Agent 發出 P2 指標。
4. SA 解除暫停的方式：
   1. SA 按「重試」。Ingress 清除暫停與失敗次數。
   2. eTag 不符時，SA 可以按「以最新版重做」。
   3. 「以最新版重做」把基準改為 SharePoint 的最新版。
   4. 狀態不變。Agent 重新執行工作項目。

**移出**

1. SA 可以移出任何未完成的 SA 文件，不限於暫停中的。
2. SA 按「移出」時，必須寫下原因。
3. SA 不能移出「完成」的 SA 文件。
4. SA 不能移出上傳寫入中的 SA 文件。
5. 移出的效果：
   1. `scheduler` 不再挑選這份 SA 文件。
   2. 完成判斷不計入這份 SA 文件。
   3. Agent 保留 SharePoint 上的草稿。
6. 移出不能復原（ADR 0010）。

**稽核**：Agent 把旗標的設定與清除寫入 `history`。

**狀態紀錄 schema**

```python
class DocRecord(TypedDict):
    doc_id: str
    doc_name: str
    origin: Literal["candidate", "manual", "new"]
    reason: str | None
    order: int
    status: Literal["QUEUED", "PRODUCING", "IN_REVIEW", "REVISING", "DONE"]
    seq: int                         # CAS 版本號
    base_version: str | None         # 基準版本
    current_version: str | None      # 最新草稿
    review_round: int                # 進入 IN_REVIEW 時加 1
    pending_feedback: list[Feedback]       # 排隊中，可撤回
    active_feedback: list[Feedback]        # 處理中，不可撤回
    resolved_feedback: list[ResolvedFeedback]
    pending_upload: PendingUpload | None   # 上傳登記
    source_rework: SourceRework | None     # 重做要求 {change_id, text, decided_by}
    last_change_summary: str | None        # 最新的變更摘要
    history: list[StatusChange]
    last_error: ErrorInfo | None
    notify_pending: bool             # 覆核卡片待補發
    fail_count: int                  # 可重試失敗的累計次數
    blocked: bool                    # 暫停
    blocked_reason: Literal["version_conflict", "validation", "repeated_failure"] | None
    withdrawn: bool                  # 移出
    withdrawn_reason: str | None
```

`PendingUpload` 的欄位：

1. `upload_id`、`by`、`at`。
2. `file_ref`、`sha256`。
3. `status`：`received`、`diff_ready`、`confirmed`、`stale`。
4. `base_version_guess`、`diff_summary`、`warnings`。
5. `sp_etag`、`confirmed_by`。

`StatusChange` 的欄位：`from`、`to`、`at`、`actor_type`、`actor`、`version`、`note`。

`actor_type` 的值：`agent`、`sa`、`sa_upload`。

## 10. Human-in-the-loop ○

Agent 有兩種人工介入：

1. 阻斷式確認：使用 `interrupt`，共三個，都在作業開始前。
2. 非阻斷式操作：Ingress 處理，不中斷 graph。

### 10.1 阻斷式確認

**`confirm_target`**

1. 觸發：每次新作業一定觸發。
2. 觸發：Orchestration 帶入目標時也觸發。
3. payload：`{card_key, prefill, system_options, mismatch_note?}`。
4. 恢復：`Command(resume={"action", "target", "by"})`。
5. `action` 的值：`confirm` 或 `cancel`。
6. 卡片內容：需求編號、MVP 編號、系統英文簡稱。

**`ask_source`**

1. 觸發：Agent 找不到共識書。
2. 觸發：Agent 找到多份共識書。
3. 觸發：Agent 找不到高階需求說明。
4. payload：`{card_key, query, found, missing}`。
5. 恢復：`Command(resume={"action", "consensus_id"?, "hld_id"?, "by"})`。
6. `action` 的值：`select`、`skip_hld`、`abandon`。
7. `skip_hld` 代表此需求沒有高階需求說明。
8. 卡片內容：查詢條件、候選的來源文件、手動輸入欄位。
9. 放棄時，Agent 釋放登記，run 以 `aborted` 結束。

**`confirm_doc_scope`**

1. 觸發：Agent 完成分析後，只觸發一次。
2. 追加由 Ingress 處理（10.2）。
3. payload：`{card_key, system_scope, candidates, limits}`。
4. 恢復：`Command(resume={"selected", "manual", "new", "sa_notes", "confirm_empty", "by"})`。
5. 卡片內容：
   1. 職責摘要。SA 可以展開出處。
   2. 候選清單與異動判斷。
   3. 手動加入區。
   4. 新文件區。
   5. 補充說明欄。

### 10.2 非阻斷式操作

**覆核卡片**

Agent 每完成一份 SA 文件，就發出覆核卡片。覆核卡片包含：

1. SA 文件名稱與連結。
2. 版本。
3. 變更摘要與出處。
4. 修訂時的回饋處理表。
5. 按鈕：「覆核完成」、「提出回饋」、「上傳修改後的文件」。

**Ingress 的處理步驟**

1. Ingress 驗證 SA 的身分。
2. Ingress 檢查前置條件。
3. Ingress 以 CAS 寫入 Store。
4. Ingress 更新卡片。
5. Ingress 以登錄表查出 `thread_id`。
6. Ingress 送出 `wake`。

**進度卡片**：進度卡片列出所有 SA 文件的狀態、旗標與佇列數量。Agent 在每次狀態或旗標變更時更新進度卡片。

**Ingress 受理的操作**

所有操作都由程式碼檢查。操作的 SA 必須在本系統的 SA 名單內。

1. 提出回饋
   1. 前置條件：狀態為「SA覆核中」或「修訂中」。
   2. 前置條件：沒有進行中的上傳，沒有移出。
   3. 結果：Ingress 把回饋放進佇列。
2. 撤回回饋
   1. 前置條件：回饋仍在佇列中。
   2. 結果：Ingress 把回饋移出佇列。
3. 覆核完成
   1. 前置條件：狀態為「SA覆核中」。
   2. 前置條件：沒有排隊的回饋，沒有重做要求。
   3. 前置條件：沒有進行中的上傳，沒有移出。
   4. 結果：Ingress 把狀態改為「完成」。
   5. 結果：Ingress 在 SharePoint 標記「SA 已覆核」。
4. 重試
   1. 前置條件：SA 文件有暫停旗標，沒有移出旗標。
   2. 結果：Ingress 清除暫停、暫停原因與失敗次數。
5. 以最新版重做
   1. 前置條件：暫停原因為 eTag 不符。
   2. 結果：Ingress 清除暫停。
   3. 結果：Ingress 把基準改為 SharePoint 的最新版。
6. 移出
   1. 前置條件：狀態不是「完成」。
   2. 前置條件：上傳階段不是 `confirmed`。
   3. 前置條件：SA 寫下原因。
   4. 結果：Ingress 設定移出旗標。
   5. 結果：Ingress 清除未確認的上傳登記。
7. 追加文件
   1. 前置條件：文件範圍已確認。
   2. 前置條件：通過 `validate_doc_scope()`。
   3. 結果：Ingress 建立狀態紀錄，排在最後。
8. 上傳修改後的文件
   1. 前置條件：狀態為「SA覆核中」，沒有移出。
   2. 前置條件：沒有上傳登記，或上傳階段為 `stale`。
   3. 前置條件：檔案類型與大小符合設定。
   4. 前置條件：檔案通過惡意程式掃描。
   5. 結果：Ingress 把檔案存入暫存區。
   6. 結果：Ingress 登記新的上傳，狀態為 `received`。
9. 確認上傳的差異
   1. 前置條件：上傳階段為 `diff_ready`。
   2. 前置條件：卡片的 `upload_id` 相符。
   3. 結果：Ingress 把上傳階段改為 `confirmed`。
10. 取消上傳
    1. 前置條件：上傳階段為 `received`、`diff_ready` 或 `stale`。
    2. 結果：Ingress 清除上傳登記。
    3. 結果：Ingress 刪除暫存檔。
11. 確認改版處理
    1. 前置條件：改版紀錄為 `awaiting_decision`。
    2. 前置條件：卡片的版本是最新的分析。
    3. 結果：Ingress 依 5.2.6 處理每份 SA 文件。
    4. 結果：Ingress 加入 SA 勾選的候選項目。
    5. 結果：Ingress 移出 SA 選擇的 SA 文件。
    6. 結果：Ingress 把改版紀錄改為 `decided`。

前置條件不符時，Ingress 回覆原因。例：「此上傳已失效，請重新上傳」。

### 10.3 共通規則

1. interrupt 前不能有非冪等的副作用。
   1. `confirm_target`、`ask_source`、`confirm_doc_scope` 恢復時會從頭重跑。
   2. Agent 以 `card_key` 去重卡片。
   3. Agent 在 interrupt 之後才寫入 State。
2. 權限
   1. 只有本系統的 SA 名單成員能操作。
   2. 目標確認前，Agent 以所填系統的 SA 名單檢查。
3. 逾時
   1. 確認卡片 3 個工作天沒有回應時，Agent 提醒 SA。
   2. 確認卡片 7 個工作天沒有回應時，Agent 把 thread 標為 `stale`。
   3. 標為 `stale` 時，Agent 通知 PO（暫定）。
   4. 覆核卡片沒有逾時。
   5. 進度卡片顯示每份 SA 文件停在「SA覆核中」的天數。
   6. 改版卡片 3 個工作天沒有處理時，Agent 提醒 SA。
   7. 上傳階段為 `stale` 超過 3 個工作天時，Agent 提醒 SA。
4. 稽核
   1. Agent 記錄所有確認、回饋、完成、上傳與改版決定。
   2. 紀錄包含操作者、時間、內容與 SA 文件版本。
   3. 上傳檔的紀錄包含雜湊值與寫入後的版本號。
   4. Store 的 `history` 與 checkpoint 都保存紀錄。

## 11. 錯誤處理與韌性 ★

| 失敗情境 | 偵測方式 | Agent 的處理 | SA 看到的訊息 |
|---|---|---|---|
| LLM 輸出不合 schema | Pydantic 驗證 | 重試 2 次 | 「分析失敗」，附重試按鈕 |
| 摘要沒有出處 | 出處驗證 | 刪除該條摘要 | 卡片註明省略的條數 |
| 找不到共識書 | `load_sources` | 前往 `ask_source` | 查詢條件與結果 |
| eTag 不符 | SharePoint 回傳 412 | 設定暫停，不重試 | 「有人修改了 SA 文件」 |
| 寫入逾時 | timeout | 查詢後再決定重寫 | 無 |
| SA 文件驗證失敗 | `validate_document` | 重試 2 次後設定暫停 | 「產製失敗」與原因 |
| 上傳檔無法解析 | `load_upload` | 清除上傳登記 | E-13 的說明 |
| 確認後 eTag 不符 | `commit_upload` | 標為 `stale`，不覆蓋 | E-15 的說明 |
| 版本查詢失敗 | `latest_versions` 錯誤 | 沿用目前版本 | 無 |
| 改版分析失敗 | 解析失敗 | 關閉閘門 | 「改版分析失敗，作業暫停」 |
| 卡片發送失敗 | API 錯誤 | 重試 3 次後待補發 | 進度卡片仍正確 |
| Tool 逾時或 5xx | HTTP 狀態 | 依 RetryPolicy 重試 | 長時間失敗時通知 |
| 超過 recursion_limit | `GraphRecursionError` | run 失敗，下次接續 | 「處理中斷，將自動接續」 |
| Checkpointer 無法使用 | 連線錯誤 | run 無法開始 | 「回饋已保存」 |
| Store 無法使用 | 連線錯誤 | 停止所有轉換 | 「系統維護中」 |
| 主要模型無法使用 | API 錯誤 | 分析類改用備援 | 「產製暫停」 |
| 執行中當機 | 狀態停在產製中或修訂中 | 重新執行工作項目 | 無 |

補充規則：

1. LLM 失敗
   1. 分析階段失敗時，run 以 `failed` 結束。
   2. 重試按鈕送出 `wake`。
   3. `ingest_event` 從 `load_sources` 重新開始。
   4. `doc_worker` 內失敗時，Agent 依 9.4 計算失敗次數。
2. 摘要沒有出處
   1. Agent 把刪除的摘要記入 `errors`。
   2. 刪除比例超過 30% 時，node 失敗。
3. 寫入逾時
   1. Agent 查詢版本歷程中的 `AgentWorkItemId`。
   2. 已經寫入時，Agent 繼續。
   3. 沒有寫入時，Agent 重試。
4. eTag 不符
   1. 進度卡片提供「以最新版重做」與「移出」。
5. SA 文件驗證失敗
   1. 進度卡片提供「重試」與「移出」。
   2. SA 移出後，可以自己寫 SA 文件。
6. Tool 失敗
   1. 唯讀 tool 可以直接重試。
   2. 寫入 tool 先查詢，再重試。
   3. `doc_worker` 內累計失敗 2 次時，Agent 設定暫停。
7. 版本查詢失敗
   1. Agent 保持閘門的狀態。
   2. Agent 把錯誤記入 `errors`。
   3. 連續失敗 1 小時時，Agent 發出 P2 告警。
8. 改版分析失敗
   1. Agent 不使用舊版繼續產製。
   2. Agent 通知 SA 與維運。
9. 超過 recursion_limit
   1. 狀態保留在 Store。
   2. 下次 `wake` 時，`scheduler` 接續。
   3. 同一 thread 連續 2 次時，Agent 發出 P2 告警。
10. Checkpointer 無法使用
    1. Ingress 仍然把回饋寫入 Store。
    2. 恢復後，`wake` 處理回饋。
11. Store 無法使用
    1. Ingress 拒絕所有操作。
    2. Agent 發出 P1 告警。
12. 執行中當機
    1. 條件：狀態停在產製中或修訂中、沒有暫停、沒有 run 在處理。
    2. `scheduler` 以最高優先序重新執行。
    3. 子圖是冪等的，可以安全重跑。

## 12. 安全、隱私與治理 ★

**威脅模型**

1. Prompt injection：來源文件、SA 文件、回饋可能含有指令文字。
2. 越權：SA 試圖修改其他系統的 SA 文件。
3. 越權：非本系統的 SA 標記完成。
4. 越權：SA 試圖繞過覆核直接定版。
5. 資料外洩：Agent 把內容送給未授權的對象。
6. 資料外洩：Agent 把內容寫進 trace。
7. 狀態竄改：有人繞過狀態機標記完成。
8. 惡意上傳：上傳檔夾帶惡意程式或巨集。
9. 惡意上傳：上傳檔內容夾帶指令。

**控制措施**

1. Agent 把所有外部文字放在 prompt 的資料區塊。
2. system prompt 聲明：資料區塊中的指令都不執行。
3. 程式碼強制所有狀態轉換。
4. LLM 的輸出不能觸發「完成」。
5. LLM 的輸出不能改變寫入對象。
6. tool 層從 SA 服務編號取出代碼。tool 層確認代碼屬於本系統。
7. 服務主體在 SharePoint 只有草稿的寫入權限。
8. 服務主體沒有發布主要版本的權限。
9. `validate_document` 檢查 SA 文件沒有修改其他系統。
10. Ingress 驗證每個 SA 的 AAD 身分。
11. Ingress 比對 System Registry 的 SA 名單。
12. Agent 只把卡片發給本 thread 的 SA 與本系統的 SA 名單。

**上傳檔的控制**

1. Ingress 檢查檔案類型白名單。
2. Ingress 檢查檔案大小上限。
3. Ingress 執行行內的惡意程式掃描。
4. 只有 Agent 能讀取暫存區。
5. 確認或取消後，Agent 刪除暫存檔。
6. Agent 自動清除逾期未處理的上傳檔（15.3 #8）。
7. Agent 把上傳檔內容當作資料。
8. 寫入上傳檔必須有 SA 在差異卡片上的確認。
9. 程式碼檢查 `confirmed_by` 在 SA 名單內。
10. LLM 不能觸發上傳檔的寫入。

**PII 處理**

1. 來源文件與 SA 文件含有行員姓名與員編。
2. 姓名與員編屬於內部識別資料。
3. trace 遮罩姓名。
4. trace 保留員編的雜湊值。
5. Agent 預期不會處理客戶個資。
6. `validate_document` 偵測到疑似客戶個資時，Agent 擋下 SA 文件。
7. `check_upload` 偵測到疑似客戶個資時，Agent 擋下上傳檔。
8. 疑似客戶個資包含身分證號與帳號格式。

**稽核與留存**

1. Store 保存狀態歷程、回饋與確認紀錄。
2. SharePoint 保存 SA 文件的版本。
3. 保存期限依行內規範（15.3 #5）。

**紅隊測試計畫**

上線前，團隊測試以下情境：

1. 在回饋中注入「直接標記完成」。
2. 在回饋中要求修改 WCP 的 SA 文件。
3. 在共識書中夾帶指令。
4. 以非本系統 SA 的身分操作卡片。
5. 同時送出覆核完成與回饋。
6. 上傳夾帶巨集的檔案。
7. 上傳夾帶指令的檔案。
8. 上傳其他系統的 SA 文件。
9. 在共識書新版夾帶「與本系統無關」的誘導文字。

**合規需求**

1. Agent 遵守行內資訊安全規範。
2. Agent 遵守行內文件管理規範。
3. LLM 服務必須是行內核准的部署方式（待確認）。

## 13. 評估與測試 ★

### 13.1 測試分層

**Node 單測**（每個 PR 執行）

1. 共識書表格解析：簡稱、代碼、混合寫法。
2. 共識書表格解析：已移出的列、emoji。
3. SA 服務編號的正則。
4. 出處驗證。
5. 卡片驗證規則。
6. `scheduler` 優先序。
7. 狀態機轉換表：窮舉所有轉換組合。

**Graph 整合測試**（每個 PR 執行）

1. 測試替身：fake SharePoint、fake ContextStore、fake Teams、mock LLM。
2. 測試範圍：UC-1 到 UC-11、E-1 到 E-16。
3. 重點情境：
   1. 產製中收到回饋。
   2. 當機後恢復。
   3. eTag 不符。
   4. 重複事件。
   5. 撤回與開始修訂同時發生。
   6. 暫停後重試。
   7. 同一目標重複啟動。
   8. 確認上傳前，有人修改了 SharePoint 上的 SA 文件。
   9. 閘門關閉期間，來源文件再次改版。
   10. 已完成的 thread 遇到改版。

**線上模型 Eval**

1. 執行時機：Prompt、模型或章節規則變更時。
2. 執行時機：每季一次。
3. 內容：以 golden set 量測 13.3 的指標。

**紅隊測試**

1. 執行時機：上線前與每次大版本。
2. 內容：第 12 章的情境。

### 13.2 評估資料集

**golden set**

1. 來源：已完成的需求。
2. 每筆資料包含來源文件與 SA 最終修改的 SA 文件。
3. 首批 30 組「需求與系統」（暫定）。
4. 主責系統與配合系統各半。
5. 困難案例各至少 3 組：
   1. 共識書沒有提到本系統（E-3）。
   2. 共識書沒有本系統的 SA 服務編號（E-4）。
   3. 同一編號同時有「改」與「不改」的語境。
   4. 共識書有舊方案的殘留敘述。
6. 該系統的 SA 標註正確的職責摘要。
7. 該系統的 SA 標註應修改的 SA 文件。

**改版案例集**

1. 每筆資料包含同一需求的新舊共識書。
2. SA 標註哪些 SA 文件應該重做。
3. 首批 10 組（暫定）。
4. 涵蓋以下情況：
   1. 改版與本系統無關。
   2. 改版只修改措辭。
   3. 職責實質改變。
   4. 新增或刪除 SA 服務。

**更新機制**

1. 團隊每季加入新完成的需求。
2. SA 指出摘要錯誤或漏列時，團隊把案例加入困難案例。

### 13.3 指標與發版門檻

| 指標 | 發版門檻 |
|---|---|
| 職責摘要正確率 | ≥ 90%（暫定） |
| 候選召回率 | ≥ 95%（暫定） |
| 候選精確率 | ≥ 80%（暫定） |
| 引用可追溯率 | = 100% |
| 首次驗證通過率 | ≥ 90%（暫定） |
| 回饋處理完整率 | = 100% |
| 改版召回率 | ≥ 95%（暫定） |
| 改版誤報率 | ≤ 30%（暫定） |
| 差異摘要完整率 | = 100% |
| 零容忍案例通過率 | = 100% |

指標定義：

1. 職責摘要正確率：正確條目除以（Agent 條目加遺漏條目）。
2. 候選召回率：應修改的 SA 文件中，出現在候選清單的比例。
3. 候選精確率：預設勾選的 SA 文件中，SA 確認要改的比例。
4. 引用可追溯率：摘要與變更都有有效出處的比例。
5. 首次驗證通過率：第一次就通過 `validate_document` 的比例。
6. 回饋處理完整率：每一筆回饋都有處理結果的比例。
7. 改版召回率：應重做的 SA 文件中，Agent 判為受影響的比例。
8. 改版誤報率：判為受影響但不需重做的比例。
9. 差異摘要完整率：程式碼算出的差異章節都出現在摘要的比例。

說明：改版誤報率的門檻較寬。理由：Agent 寧可多報，也不漏報。

**零容忍案例**（以下情況絕不可以發生）

1. Agent 寫入其他系統的 SA 文件。
2. SA 文件沒有經過 SA 操作就變成「完成」。
3. Agent 沒有經過 SA 確認就寫入上傳檔。
4. 狀態機以外的轉換。
5. Agent 覆蓋 SharePoint 中別人修改的版本。
6. Agent 預設勾選「不異動」的 SA 文件。
7. 變動章節提到本系統，Agent 卻判定沒有影響。

## 14. 可觀測性與營運 ★

**Tracing**

1. 工具：LangSmith 或行內 OpenTelemetry。
2. 標籤：
   1. `agent=sa-doc-agent`
   2. `spec_version`
   3. `thread_id`
   4. `req_id`、`mvp_id`、`system_abbr`
   5. `doc_id`、`work_item_id`
   6. `mode=produce|revise|upload_diff|upload_commit`
   7. `degraded`

**關鍵指標**

1. 每份 SA 文件的產製時間（P50 與 P90）。
2. 每份 SA 文件的修訂輪數。
3. 各狀態的停留時間，特別是「SA覆核中」。
4. 首版通過率。
5. 暫停的 SA 文件數。
6. 每份 SA 文件的 LLM 成本。
7. eTag 不符的次數。
8. Ingress 拒絕的操作次數。
9. 以上傳檔完成的比例。
10. 改版次數與受影響的 SA 文件數。
11. 閘門關閉的時間。

**告警**

| 條件 | 等級 |
|---|---|
| tool 層拒絕範圍外的寫入 | P1 |
| 狀態機拒絕違規的轉換 | P1 |
| Store 無法使用 | P1 |
| tool 層拒絕寫入未確認的上傳檔 | P1 |
| SA 文件停在產製中或修訂中超過 30 分鐘 | P2 |
| 同一 thread 連續 2 次 run 失敗 | P2 |
| 單日暫停的 SA 文件超過 5 份 | P2 |
| 改版分析失敗 | P2 |
| 閘門關閉超過 3 個工作天 | P2 |

告警說明：

1. 「停留超過 30 分鐘」只計算沒有暫停、沒有 run 處理的 SA 文件。
2. 閘門關閉超過 3 個工作天時，Agent 同時提醒 SA。

**SLO**（暫定）

1. 第一份 SA 文件
   1. 起點：SA 確認文件範圍。
   2. 目標：30 分鐘內進入「SA覆核中」（P90）。
2. 修訂
   1. 起點：Agent 結束目前的工作項目。
   2. 目標：Agent 在 30 分鐘內完成修訂（P90）。

**部署與設定**

1. Agent 部署在 LangGraph Server。
2. 模型、章節規則與上限值放在設定檔。
3. 設定檔依環境區分。

**灰度與回滾**

1. 團隊先開放 1 到 2 個系統的 SA 試用。
2. 回滾時，在途 thread 由舊版繼續處理。
3. LangGraph Server 以 `spec_version` 標籤路由 thread。
4. State schema 的 Major 變更必須附遷移腳本。
5. `DocRecord` 只新增欄位，保持向後相容。

**成本預算**

1. 每份 SA 文件的成本上限：<待定>。
2. 成本上限包含產製與平均 2 輪修訂。
3. 成本超過預算 2 倍時，團隊檢討 prompt。

**Runbook**（待建立）

1. 處理 eTag 不符。
2. 解除暫停。
3. 手動更改狀態的核准流程。

## 15. 決策紀錄、風險與待決事項 ★

### 15.1 重要決策

**ADR 0001：主圖使用受控 workflow**

1. 決定：主圖使用受控 workflow，每份 SA 文件使用子圖。
2. 理由：業務流程固定。
3. 理由：狀態轉換必須可保證。
4. 理由：子圖讓產製與修訂共用步驟。

**ADR 0002：覆核使用事件驅動**

1. 決定：覆核使用 Store 收件匣與 `wake`，不使用 `interrupt`。
2. 理由：`interrupt` 會讓 thread 停住。
3. 理由：thread 停住後，Agent 無法產製下一份。

**ADR 0003：狀態只存在 Store**

1. 決定：Store 是狀態的唯一真相。
2. 理由：卡片、Orchestration、Ingress 都要查詢狀態。
3. 理由：只存一處，避免不一致。

**ADR 0004：新增「待產製」狀態**（已確認）

1. 決定：Agent 使用內部狀態「待產製」。
2. 理由：SA 確認文件範圍後，SA 文件需要可查詢的狀態。
3. 理由：進度卡片需要完整顯示所有 SA 文件。

**ADR 0005：候選清單以規則為主**

1. 決定：Agent 以正則抽出 SA 服務編號。
2. 決定：LLM 判斷每份 SA 文件的異動。
3. 理由：SA 服務編號的格式固定。
4. 理由：「改」與「不改」常寫在同一句，需要語意判斷。
5. 理由：上游不標示 SA 文件是否異動。
6. 結果：Agent 提出判斷，SA 確認。

**ADR 0006：一個目標對應一個 thread**

1. 決定：`thread_id` 使用 uuid。
2. 決定：Store 的登錄表對應目標與 thread。
3. 理由：目標確認前後是同一個 thread，不需要搬移 State。
4. 理由：「不存在才寫入」防止重複作業。

**ADR 0007：Ingress 處理作業中的 SA 操作**

1. 決定：Ingress 處理以下操作，graph 不處理：
   1. 回饋與撤回。
   2. 覆核完成。
   3. 重試與移出。
   4. 追加文件。
   5. 上傳、確認上傳、取消上傳。
   6. 確認改版處理。
2. 理由：`interrupt` 會讓 thread 停住。
3. 理由：Ingress 可以立即回應 SA。
4. 理由：程式碼統一檢查前置條件。

**ADR 0008：不並行**

1. 決定：Agent 一次只處理一份 SA 文件。
2. 理由：SA 不會同時收到大量覆核卡片。
3. 理由：狀態轉換與 SharePoint 寫入更單純。

**ADR 0009：依改版的差異決定是否重做**

1. 決定：改版沒有影響時，Agent 自動套用新版。
2. 決定：改版有影響時，Agent 關閉閘門，SA 決定。
3. 理由：用舊版繼續產製只會增加重工。
4. 理由：護欄規則防止漏掉應該重做的 SA 文件。

**ADR 0010：暫停與移出使用旗標**（已確認）

1. 決定：暫停與移出使用旗標，不新增狀態。
2. 決定：移出不能復原。
3. 理由：狀態定義與需求保持一致。

**ADR 0011：SA 可以上傳 SA 文件**

1. 決定：Agent 比對、警示、寫入上傳檔。
2. 決定：Agent 不改寫上傳檔。
3. 決定：SA 確認差異後，狀態直接改為「完成」。
4. 理由：SA 不必透過回饋來回溝通。
5. 理由：SA 確認的是程式碼算出的差異，避免摘要遺漏。

**ADR 0012：SA 文件放在 SharePoint**

1. 決定：Agent 只寫入次要版本。
2. 決定：Agent 以 eTag 做樂觀鎖。
3. 決定：Agent 以 `AgentWorkItemId` 欄位做冪等。
4. 理由：次要版本不影響正式版。
5. 理由：Graph API 沒有冪等鍵。

### 15.2 已知風險

1. **共識書格式不一致**
   1. 影響：摘要錯誤，候選清單漏列。
   2. 緩解：章節規則放在設定檔。
   3. 緩解：Agent 只採用指定章節。
   4. 緩解：Agent 驗證出處。
   5. 緩解：團隊把困難案例加入 golden set。
2. **上游不標示 SA 文件是否異動**
   1. 影響：誤判會讓 SA 多改或漏改。
   2. 緩解：預設勾選只是建議，SA 逐一確認。
   3. 緩解：召回率與精確率列入發版門檻。
   4. 緩解：團隊把 SA 的修正加入 golden set。
3. **共識書沒有本系統的 SA 服務編號**
   1. 影響：候選清單為空。
   2. 緩解：Agent 列出相關電文作為提示。
   3. 緩解：Agent 加入此需求曾經關聯的 SA 文件。
4. **SA 直接在 SharePoint 修改草稿**
   1. 影響：eTag 不符。
   2. 緩解：Agent 不覆蓋。
   3. 緩解：Agent 詢問 SA。
5. **多位 SA 同時操作同一系統**
   1. 影響：回饋互相矛盾。
   2. 緩解：v0.1 允許名單內的 SA 都能操作。
   3. 緩解：Agent 記錄完整的稽核紀錄。
   4. 待決：鎖定規則（15.3 #3）。
6. **回饋大量排隊**
   1. 影響：SA 等待時間長。
   2. 緩解：進度卡片顯示佇列位置。
   3. 緩解：團隊監控「SA覆核中」的停留時間。
7. **共識書頻繁改版**
   1. 影響：閘門經常關閉。
   2. 緩解：只有影響本系統的改版才關閉閘門。
   3. 緩解：新的分析會取代舊的分析。
8. **Agent 誤判改版沒有影響**
   1. 影響：SA 文件依據過時的共識書。
   2. 緩解：護欄規則（5.2.6）。
   3. 緩解：改版召回率列入發版門檻。
   4. 緩解：通知仍然列出變動章節。
9. **上傳檔沒有經過 Agent 驗證就完成**
   1. 影響：SA 文件可能缺少章節或含有錯誤的圖。
   2. 緩解：差異卡片列出警示。
   3. 緩解：Agent 擋下疑似客戶個資。
   4. 緩解：最終以 SA 的確認為準。

### 15.3 開放問題

| # | 問題 | 負責人 | 期限 |
|---|---|---|---|
| 1 | 需求編號與 MVP 編號的格式為何？共識書何時補上 MVP 欄位？ | <待填> | <待填> |
| 2 | SA 範本有哪些文件類型？必要章節為何？ | <待填> | <待填> |
| 3 | 多位 SA 同時操作時，是否需要鎖定機制？ | <待填> | <待填> |
| 4 | 除了改版，SA 能否主動重新開啟「完成」的 SA 文件？ | <待填> | <待填> |
| 5 | thread、Store 與 trace 的保存期限為何？ | <待填：合規> | <待填> |
| 6 | SharePoint 的資料夾結構與權限如何設定？ | <待填：SharePoint 管理者> | <待填> |
| 7 | SA 文件在 SharePoint 的格式是 Word 還是 Markdown？ | <待填> | <待填> |
| 8 | 上傳檔的格式、大小上限與保留期限為何？ | <待填：資安> | <待填> |
| 9 | ContextStore 是否提供改版的事件通知？ | <待填：ContextStore 團隊> | <待填> |

補充說明：

1. 問題 2 的答案是 `validate_document` 與 `check_upload` 的依據。
2. 問題 6 包含 `Sites.Selected` 的授權申請。
3. 問題 6 包含自訂欄位的建立。
4. 問題 7 會影響文件組裝與上傳檔的比對。
5. 問題 8 包含行內的惡意程式掃描服務。
6. 問題 9：如果 ContextStore 沒有通知，Orchestration 必須轉發 `wake`。

**已決議的事項**（2026-10-03）

1. 新增「待產製」狀態（ADR 0004）。
2. 暫停與移出使用旗標（ADR 0010）。
3. 高階需求說明與共識書放在同一位置，格式為 md（1.4）。
4. SA 文件放在 SharePoint（ADR 0012）。
5. Agent 依改版的差異決定是否重做（ADR 0009）。
6. Agent 不並行（ADR 0008）。
7. 上游不標示 SA 文件是否異動（ADR 0005）。

### 15.4 變更紀錄

| 版本 | 日期 | 摘要 | 影響 |
|---|---|---|---|
| 0.1.0 | 2026-10-03 | 初版 | — |
| 0.2.0 | 2026-10-03 | 新增上傳、改版處理與 SharePoint 整合 | Major |
| 0.2.0（STE 版） | 2026-10-04 | 依 ASD-STE100 原則改寫，內容不變 | — |

0.2.0 的變更：

1. 確認「待產製」狀態與旗標設計。
2. 把資訊資產代碼的欄位改名為 `info_asset_code`。
3. 把 SA 文件的存放位置定為 SharePoint。
4. 新增上傳檔的流程（`upload_worker`）。
5. 新增改版的偵測與處理。
6. 確定不並行。
7. 確定上游不標示異動。

0.2.0 是 Major 變更。理由：State schema 的欄位改名，WorkItem 新增模式。
