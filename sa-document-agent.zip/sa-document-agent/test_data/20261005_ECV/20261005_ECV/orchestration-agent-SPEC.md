# orchestration-agent 規格文件

> 本文件依「LangGraph Agent 規格文件指南」的章節撰寫。
> 寫作遵守 ASD-STE100 原則：短句、一句一事、用詞一致、主動語態。
> 架構背景見 `docs/五Agent架構藍圖.html`（以下簡稱「藍圖」）。

## 0. 文件控制

| 項目 | 內容 |
|---|---|
| Spec ID | AGT-SA-000 |
| Agent 名稱 | `orchestration-agent` |
| Spec 版本 | 0.1.0 |
| 狀態 | Draft |
| Owner | SA AI 賦能專案組（待指定負責人） |
| 審查者 | Tech：待定 ／ Security：待定 ／ Domain：待定 |
| 風險等級 | **中**（寫入內部系統，處理員工身分） |
| 建立／更新 | 2026-10-04 ／ 2026-10-04 |
| 對應程式碼 | 尚未實作 |
| 技術版本 | Python 3.12 ／ LangGraph 1.x |
| 相關文件 | 藍圖、`docs/AgentCore溝通機制研究筆記.md` |

## 1. 目的與範圍

### 1.1 問題與目標

本專案有五個功能型 Agent。
使用者不應記住每個 Agent 的入口。
本 Agent 是使用者在 Teams 的唯一入口。
本 Agent 做三件事：

1. 識別意圖。本 Agent 把訊息轉導到目標 Agent。
2. 管理工作階段。本 Agent 記住使用中 Agent 與狀態。
3. 識別使用者。本 Agent 列出使用者的任務，供使用者接續。

本 Agent 不產出業務內容。
功能型 Agent 產出業務內容。

### 1.2 成功指標

| 指標 | 目標 | 量測方式 |
|---|---|---|
| 意圖轉導正確率 | ≥ 95% | 意圖測試集（第 13 章） |
| 意圖卡片出現率 | ≤ 20% | 線上：出現意圖卡片的回合 ÷ 總回合 |
| 卡片後轉導成功率 | ≥ 98% | 線上：卡片送出後成功轉導的比例 |
| 任務接續成功率 | ≥ 98% | 線上：選擇任務後成功轉導的比例 |
| **越權顯示任務** | **= 0**（零容忍） | 零容忍測試＋線上稽核抽樣 |
| 本 Agent 自身 P95 延遲 | < 3 秒 | Trace：不含功能型 Agent 的處理時間 |
| 每回合成本 | < US$0.01 | Trace token 統計 |

### 1.3 Non-goals

- 本 Agent 不產出需求、方案或文件內容。
- 本 Agent 不推進需求階段（v0.1）。
- 本 Agent 不讓功能型 Agent 彼此直接呼叫。
- 本 Agent 不支援 Teams 以外的入口（藍圖 Q8）。
- 本 Agent 不支援群組聊天，只支援一對一聊天。
- 本 Agent 不管理功能型 Agent 的內部狀態。

### 1.4 假設與前提

- Teams Bot 已完成註冊。
- Bot Adapter 驗證每個 Activity 的 token。
- Bot Adapter 從 Activity 取出 `aadObjectId`。
- Bot Adapter 以 `activity_id` 去除重送的 Activity。
- 五個功能型 Agent 部署於 AgentCore Runtime。
- 功能型 Agent 遵守第 7.2 節的呼叫契約。
- 資料庫提供 `tasks` 集合（第 9.2 節）。
- 資料庫選型未定（藍圖 Q2），本文件只定義邏輯欄位。

### 1.5 名詞定義

本文件只用下列名詞。同一概念不換詞。

| 名詞 | 定義 |
|---|---|
| 使用者 | 在 Teams 與本 Agent 對話的員工。 |
| 本 Agent | Orchestration Agent。 |
| 功能型 Agent | Prototype、Proposal、Interview、Solution、SA Document 五個 Agent。 |
| 目標 Agent | 本回合要接收訊息的功能型 Agent。 |
| 使用中 Agent | 工作階段目前綁定的功能型 Agent。 |
| 意圖 | 使用者本回合想做的事。 |
| 轉導 | 本 Agent 把訊息交給目標 Agent。 |
| 回合 | 一則使用者訊息與一則回覆。 |
| 工作階段 | 一個 Teams 對話的持久狀態。 |
| 任務 | 一位使用者用一個功能型 Agent 處理一筆需求的工作。 |
| 需求 | 藍圖的 requirement，編號 `REQ-YYYY-NNN`。 |
| 意圖卡片 | 詢問目標 Agent 的 Adaptive Card。 |
| 任務卡片 | 列出任務的 Adaptive Card。 |
| 卡片動作 | 使用者在卡片上按下按鈕後送出的資料。 |
| Bot Adapter | 接收 Teams Activity 並呼叫本 Agent 的服務。 |
| 待轉導訊息 | 本 Agent 發出卡片前暫存的使用者原文。 |
| 個資 | 可識別個人的資料，即 PII。 |
| prompt injection | 訊息中夾帶的指令，企圖改變 Agent 的行為。 |

## 2. 使用情境與 I/O 契約

### 2.1 主要情境

| ID | 情境 | 預期結果 |
|---|---|---|
| UC-1 | 使用者說「幫我把 REQ-2026-041 做影響分析」 | 本 Agent 轉導到 Solution Agent |
| UC-2 | 使用者只說「你好」 | 本 Agent 回覆意圖卡片 |
| UC-3 | 使用者在意圖卡片選 Interview Agent | 本 Agent 建立任務，並把待轉導訊息轉導到 Interview Agent |
| UC-4 | 使用中 Agent 存在，使用者回答追問 | 本 Agent 直接轉導到使用中 Agent |
| UC-5 | 使用者說「列出我的任務」 | 本 Agent 回覆任務卡片 |
| UC-6 | 使用者在任務卡片選一筆任務 | 本 Agent 接續該任務，並轉導到該任務使用的功能型 Agent |
| UC-7 | 使用者說「結束」 | 本 Agent 清除使用中 Agent，並回覆確認 |
| UC-8 | 工作階段閒置超過 8 小時後有新訊息 | 本 Agent 保存待轉導訊息，回覆任務卡片並說明已逾時 |
| UC-9 | 本 Agent 查無使用者身分 | 本 Agent 拒絕服務，不呼叫任何 Agent |
| UC-10 | 訊息含 prompt injection | 本 Agent 只輸出意圖，不執行訊息中的指令 |
| UC-11 | 使用者送出過期的卡片動作 | 本 Agent 回覆最新的意圖卡片 |
| UC-12 | 使用者選 Solution Agent，但未提供需求編號 | 本 Agent 回覆意圖卡片，請使用者填入需求編號 |
| UC-13 | 使用者在群組聊天提及本 Agent | 本 Agent 拒絕服務 |

### 2.2 輸入契約（`input_schema`）

| 欄位 | 型別 | 必填 | 說明 |
|---|---|:-:|---|
| `user_aad_id` | string | ★ | Bot Adapter 從已驗證的 Activity 帶入。本 Agent 不接受訊息中的 ID。 |
| `tenant_id` | string | ★ | Teams 租戶 ID。 |
| `conversation_id` | string | ★ | Teams 對話 ID。 |
| `conversation_type` | string | ★ | Teams 對話類型。只接受 `personal`。 |
| `activity_id` | string | ★ | Teams Activity ID。本 Agent 用它去除重送。 |
| `text` | string | | 使用者原文。上限 4,000 字元。超過的部分截斷並標記。 |
| `card_action` | CardAction \| null | | 卡片動作。格式見 2.5 節。 |
| `attachments` | list[AttachmentRef] | | 附件參照。本 Agent 不讀內容，只原樣轉導。 |

Bot Adapter 每回合必須傳入全部欄位。
沒有值的欄位，Bot Adapter 傳入 null 或空清單。
原因：LangGraph 會沿用 checkpoint 中缺少的欄位。

Bot Adapter 設定 `config["configurable"]["thread_id"]`。
規則見第 9.1 節。

### 2.3 輸出契約（`output_schema`）

| 欄位 | 型別 | 說明 |
|---|---|---|
| `reply_type` | enum | `text` / `card` / `agent_reply` |
| `reply_text` | string \| null | 回覆文字。 |
| `card` | object \| null | Adaptive Card JSON。 |
| `active_agent` | enum \| null | 回合結束時的使用中 Agent。 |
| `task_id` | string \| null | 本回合使用的任務。 |
| `status` | enum | `done` / `waiting_user` / `processing` / `rejected` / `error` |

```json
{
  "reply_type": "agent_reply",
  "reply_text": "【Solution Agent】已讀取 REQ-2026-041，開始影響分析。",
  "card": null,
  "active_agent": "solution",
  "task_id": "T-20261004-0007",
  "status": "processing"
}
```

### 2.4 呼叫方式

1. Bot Adapter 收到 Activity。
2. Bot Adapter 立即回覆「輸入中」指示。
3. Bot Adapter 以背景方式呼叫本 Agent。
4. 本 Agent 回傳輸出契約。
5. Bot Adapter 以 proactive message 送出回覆。

理由：Teams 要求 15 秒內首次回應（藍圖硬性限制）。
功能型 Agent 可能超過此限制。
proactive message 的實作方式待 POC（藍圖 Q10）。

### 2.5 卡片動作格式（`CardAction`）

| 欄位 | 型別 | 說明 |
|---|---|---|
| `card_id` | string | 本 Agent 發卡時產生。本 Agent 用它判斷卡片是否過期。 |
| `action` | enum | `select_agent` / `resume_task` / `new_task` / `end_session` |
| `agent` | enum \| null | `select_agent` 時必填。`new_task` 時可為空。 |
| `task_id` | string \| null | `resume_task` 時必填。 |
| `requirement_id` | string \| null | 使用者在卡片填入的需求編號。 |

本 Agent 把卡片動作視為不可信資料。
`resume_task` 重新檢查任務擁有者。
`resume_task` 也檢查角色與需求階段。
`new_task` 一律建立新任務，不沿用進行中的任務。

## 3. 架構總覽

### 3.1 選型與理由

本 Agent 採用受控 workflow。
本 Agent 不採用 Supervisor 或 ReAct loop。
理由如下：

1. 轉導目標只有五個，路由可以窮舉。
2. 轉導錯誤會讓使用者失去上下文，所以路由必須可預測。
3. LLM 只做一件事：意圖分類。
4. 純函式執行其他判斷。純函式可以單測。

替代方案是 Supervisor 模式。
Supervisor 會讓 LLM 自由選擇呼叫哪個 Agent。
審查者較難稽核此方案。
所以本規格不採用此方案（ADR-0001）。

本 Agent 以 agents-as-tools 方式呼叫功能型 Agent。
此方式對應藍圖的方案 A。

### 3.2 拓樸圖

`load_session` 是第一個 node。所有路徑都經過 `compose_reply` 後結束。

```mermaid
flowchart TD
  S([START]) --> load_session
  load_session --> resolve_user
  resolve_user -->|拒絕| compose_reply
  resolve_user -->|有卡片動作| apply_card_action
  resolve_user -->|閒置逾時| list_tasks
  resolve_user -->|自動轉導關閉，有使用中 Agent| forward_to_agent
  resolve_user -->|自動轉導關閉，無使用中 Agent| ask_intent
  resolve_user -->|一般訊息| classify_intent
  apply_card_action -->|select_agent，或指定 Agent 的 new_task| bind_task
  apply_card_action -->|resume_task| resume_task
  apply_card_action -->|end_session| end_session
  apply_card_action -->|過期、無效或未指定 Agent| ask_intent
  classify_intent -->|指定新的 Agent 或需求| bind_task
  classify_intent -->|continue，或指向使用中 Agent| forward_to_agent
  classify_intent -->|list_tasks| list_tasks
  classify_intent -->|end_session| end_session
  classify_intent -->|unclear 或低信心| ask_intent
  bind_task -->|成功| forward_to_agent
  bind_task -->|需求問題| ask_intent
  bind_task -->|拒絕| compose_reply
  resume_task -->|成功| forward_to_agent
  resume_task -->|需求問題| ask_intent
  resume_task -->|拒絕| compose_reply
  forward_to_agent -->|無使用中 Agent| ask_intent
  forward_to_agent -->|其他| compose_reply
  end_session --> compose_reply
  ask_intent --> compose_reply
  list_tasks --> compose_reply
  compose_reply --> E([END])
```

### 3.3 Node 一覽

| Node | 類型 | 一句話職責 |
|---|---|---|
| `load_session` | 純函式 | 重設回合欄位，並檢查閒置時間。 |
| `resolve_user` | Tool | 用 `user_aad_id` 取得使用者資料。 |
| `apply_card_action` | 純函式 | 驗證卡片動作，並轉成意圖。 |
| `classify_intent` | LLM | 判斷意圖、目標 Agent 與需求編號。 |
| `ask_intent` | 純函式 | 產生意圖卡片。 |
| `list_tasks` | Tool | 查詢使用者的任務，並產生任務卡片。 |
| `bind_task` | Tool | 檢查權限，並取得任務。 |
| `resume_task` | Tool | 檢查任務，並接續任務。 |
| `forward_to_agent` | Tool | 把訊息轉導到使用中 Agent，並更新任務。 |
| `end_session` | 純函式 | 清除使用中 Agent。 |
| `compose_reply` | 純函式 | 套用回覆模板，並寫入輸出。 |

## 4. State 規格

### 4.1 Schema

權威定義：`agents/orchestration-agent/src/state.py`（待實作）

```python
AgentName = Literal["prototype", "proposal", "interview", "solution", "sa_document"]

class OrchestratorInput(TypedDict):
    user_aad_id: str
    tenant_id: str
    conversation_id: str
    conversation_type: str
    activity_id: str
    text: str | None
    card_action: CardAction | None
    attachments: list[AttachmentRef]

class OrchestratorOutput(TypedDict):
    reply_type: Literal["text", "card", "agent_reply"]
    reply_text: str | None
    card: dict | None
    active_agent: AgentName | None
    task_id: str | None
    status: Literal["done", "waiting_user", "processing", "rejected", "error"]

class OrchestratorState(OrchestratorInput, OrchestratorOutput):
    messages: Annotated[list[AnyMessage], add_messages]
    # 持久欄位：跨回合保留
    active_agent: AgentName | None
    active_task_id: str | None
    active_requirement_id: str | None
    pending_text: str | None
    open_card_id: str | None
    inflight: Inflight | None
    last_activity_at: datetime | None
    # 回合欄位：load_session 每回合重設
    user: UserProfile | None
    idle_expired: bool
    intent: IntentResult | None
    resume: bool
    ended_agent: AgentName | None
    task_options: list[TaskSummary]
    agent_result: AgentResult | None
    error: ErrorInfo | None
```

`IntentResult` 欄位：`intent`、`target_agent`、`requirement_id`、`task_id`、`new_task`、`confidence`。
`intent` 的值：`to_agent` / `continue` / `list_tasks` / `end_session` / `unclear`。
`apply_card_action` 依卡片動作填入全部欄位，並把 `confidence` 設為 1.0。
`apply_card_action` 依下列對應設定 `intent`：

1. `select_agent`、`new_task`、`resume_task` 對應 `to_agent`。
2. `end_session` 對應 `end_session`。

`classify_intent` 一律把 `new_task` 設為 false。
`ErrorInfo` 欄位：`code`、`message`。`code` 的值見第 11 章。
`Inflight` 欄位：`task_id`、`key`。`key` 是執行中呼叫的冪等鍵。
`AgentResult` 欄位：7.2 節的回傳欄位，另加 `state`。
`state` 的值：`completed` / `processing`。

### 4.2 欄位表

輸入欄位見 2.2 節。所有 node 都可以讀取輸入欄位。

| 欄位 | 型別 | Reducer | 寫入者 | 讀取者 | 含個資 | 備註 |
|---|---|---|---|---|:-:|---|
| `messages` | list[AnyMessage] | `add_messages` | `load_session`、`compose_reply` | `classify_intent` | 是 | 見 9.1 節。 |
| `active_agent` | AgentName | 覆寫 | `list_tasks`、`bind_task`、`resume_task`、`end_session` | `load_session`、`resolve_user` 路由、`classify_intent`、`ask_intent`、`forward_to_agent`、`end_session`、`compose_reply` | 否 | 持久欄位。也是輸出欄位。 |
| `active_task_id` | str | 覆寫 | 同 `active_agent` | `forward_to_agent`、`end_session`、`compose_reply` | 否 | 持久欄位。 |
| `active_requirement_id` | str | 覆寫 | 同 `active_agent`，另加 `forward_to_agent` | 路由、`classify_intent`、`ask_intent`、`forward_to_agent`、`end_session` | 否 | 持久欄位。 |
| `pending_text` | str | 覆寫 | `load_session`、`ask_intent`、`list_tasks`、`forward_to_agent`、`end_session` | `ask_intent`、`forward_to_agent` | 是 | 持久欄位。規則見 5.6 節。 |
| `open_card_id` | str | 覆寫 | `ask_intent`、`list_tasks`、`apply_card_action` | `apply_card_action` | 否 | 持久欄位。`apply_card_action` 驗證成功後清除。 |
| `inflight` | Inflight | 覆寫 | `forward_to_agent` | `forward_to_agent` | 否 | 持久欄位。執行中的呼叫。 |
| `last_activity_at` | datetime | 覆寫 | `compose_reply` | `load_session` | 否 | 持久欄位。 |
| `user` | UserProfile | 覆寫 | `load_session`（重設）、`resolve_user` | `bind_task`、`resume_task`、`list_tasks`、`forward_to_agent` | 是 | 回合欄位。含 `user_id`、姓名、角色。 |
| `idle_expired` | bool | 覆寫 | `load_session` | `resolve_user` 路由、`list_tasks` | 否 | 回合欄位。 |
| `intent` | IntentResult | 覆寫 | `load_session`（重設）、`classify_intent`、`apply_card_action` | 路由、`bind_task`、`resume_task`、`ask_intent`、`compose_reply` | 否 | 回合欄位。 |
| `resume` | bool | 覆寫 | `load_session`（重設）、`resume_task` | `forward_to_agent` | 否 | 回合欄位。 |
| `ended_agent` | AgentName | 覆寫 | `load_session`（重設）、`end_session` | `compose_reply` | 否 | 回合欄位。本回合結束的使用中 Agent。 |
| `task_options` | list[TaskSummary] | 覆寫 | `load_session`（重設）、`list_tasks` | `list_tasks` | 否 | 回合欄位。上限 10 筆。 |
| `agent_result` | AgentResult | 覆寫 | `load_session`（重設）、`forward_to_agent` | `compose_reply` | 是 | 回合欄位。 |
| `error` | ErrorInfo | 覆寫 | `load_session`（重設）、`resolve_user`、`list_tasks`、`bind_task`、`resume_task`、`forward_to_agent` | 路由、`ask_intent`、`compose_reply` | 否 | 回合欄位。 |
| `card` | dict | 覆寫 | `load_session`（重設）、`ask_intent`、`list_tasks` | `compose_reply` | 否 | 回合欄位。也是輸出欄位。 |
| `reply_type`、`reply_text`、`task_id`、`status` | 見 2.3 節 | 覆寫 | `load_session`（重設）、`compose_reply` | 輸出 | 是 | 回合欄位。 |

同一欄位有多個寫入者時，這些寫入者位於互斥分支，或依序執行。
同一回合中，`load_session` 的重設永遠最先執行。

### 4.3 規則與相容策略

- 持久欄位跨回合保留。持久欄位就是工作階段。
- `load_session` 在每回合開始時重設全部回合欄位。
- 原因：LangGraph 會在 checkpoint 中保留上一回合的值。
- 新增欄位必須有預設值。此變更屬 Minor。
- 刪除欄位或改型別屬 Major 變更。
- 執行 Major 變更前，維運人員必須排空或遷移在途工作階段。

## 5. Node 規格

### 5.1 契約總表

`active_*` 指 `active_agent`、`active_task_id`、`active_requirement_id`。
「回合欄位」指 4.2 節標為回合欄位的全部欄位。

| Node | 讀 | 寫 | 副作用 | 冪等 | RetryPolicy | 逾時 | 失敗行為 |
|---|---|---|---|:-:|---|---|---|
| `load_session` | `text`、`last_activity_at`、`active_*` | 回合欄位、`messages`、`pending_text` | 無 | 是 | 不適用 | 不適用 | 不適用 |
| `resolve_user` | `user_aad_id`、`tenant_id`、`conversation_type` | `user`、`error` | 無（唯讀） | 是 | 3 次，指數退避 | 3s | 寫入 `error`，拒絕服務 |
| `apply_card_action` | `card_action`、`open_card_id` | `intent`、`open_card_id` | 無 | 是 | 不適用 | 不適用 | 視為卡片過期 |
| `classify_intent` | `messages`、`text`、`active_agent`、`active_requirement_id` | `intent` | 無 | 是 | 解析失敗重試 1 次 | 5s | `intent = unclear` |
| `ask_intent` | `text`、`intent`、`error`、`active_agent`、`active_requirement_id`、`pending_text` | `card`、`open_card_id`、`pending_text` | 無 | 是 | 不適用 | 不適用 | 不適用 |
| `list_tasks` | `user`、`text`、`idle_expired` | `task_options`、`card`、`open_card_id`、`pending_text`、`active_*`、`error` | 無（唯讀） | 是 | 3 次 | 3s | 寫入 `error` |
| `bind_task` | `user`、`intent`、`activity_id` | `active_*`、`error` | **寫入：建立任務** | 靠冪等鍵 | 2 次 | 3s | 寫入 `error`，不轉導 |
| `resume_task` | `user`、`intent` | `active_*`、`resume`、`error` | **寫入：更新任務時間** | 是 | 2 次 | 3s | 寫入 `error`，不轉導 |
| `forward_to_agent` | `user`、`text`、`pending_text`、`attachments`、`activity_id`、`resume`、`inflight`、`active_*` | `agent_result`、`active_requirement_id`、`pending_text`、`inflight`、`error` | **呼叫功能型 Agent；更新任務** | 靠冪等鍵 | **不自動重試**（見 5.4） | 120s | 見 5.4 |
| `end_session` | `active_*` | `active_*`、`pending_text`、`ended_agent` | 無 | 是 | 不適用 | 不適用 | 不適用 |
| `compose_reply` | `agent_result`、`error`、`card`、`intent`、`ended_agent`、`active_agent`、`active_task_id` | `reply_type`、`reply_text`、`task_id`、`status`、`messages`、`last_activity_at` | 無 | 是 | 不適用 | 不適用 | 回覆固定錯誤文字 |

### 5.2 `load_session`

職責：準備本回合，並檢查工作階段是否閒置。
步驟：

1. 把全部回合欄位重設為初始值。
2. 若 `text` 不為空，把 `text` 加入 `messages`。
3. 若 `text` 不為空，清除 `pending_text`。
4. 若 `last_activity_at` 為空，判定為新工作階段，跳到第 7 步。
5. 計算現在時間與 `last_activity_at` 的差值。
6. 若差值超過 8 小時，且 `active_agent` 不為空，把 `idle_expired` 設為 true。
7. 結束本 node。

`load_session` 不清除 `active_*`。
`list_tasks` 在身分確認後清除 `active_*`。
原因：身分查詢失敗時，使用者不應失去使用中 Agent。

第 3 步的原因：新訊息取代舊的待轉導訊息。
8 小時取自 AgentCore session 的預設最長時間（研究筆記）。
AgentCore 的此值可以調整。
本規格把閾值放設定檔。

### 5.3 `bind_task`

職責：為本回合取得任務，並設定使用中 Agent。
程式碼強制下列前置檢查，不依賴 prompt：

1. 檢查 `user.roles` 可以使用目標 Agent（權限表見 12.2 節）。
2. 檢查目標 Agent 需要的需求編號已提供（對照表見 6.3 節）。
3. 若需求編號不為空，查詢該需求是否存在。
4. 檢查需求階段與目標 Agent 相符（對照表見 6.3 節）。

任務處理步驟：

1. 若 `intent.new_task` 為 true，跳到第 4 步。
2. 若需求編號為空，跳到第 4 步。
3. 用「使用者＋目標 Agent＋需求」查詢進行中的任務。查到則跳到第 5 步。
4. 建立新任務。
5. 把任務寫入 `active_task_id`。
6. 把目標 Agent 寫入 `active_agent`。
7. 把需求編號寫入 `active_requirement_id`。

冪等鍵：`{thread_id}:{activity_id}`。
Teams 重送同一 Activity 時，本 Agent 不重複建立任務。

### 5.4 `forward_to_agent`

職責：把訊息轉導到使用中 Agent。
前置檢查：

1. 若 `active_agent` 為空，寫入 `error`（`no_active_agent`），結束本 node。
2. 呼叫 `get_task`，確認任務擁有者是本人。
3. 擁有者不符時，寫入 `error`（`task_not_owned`），結束本 node。
4. 若 `inflight.task_id` 等於 `active_task_id`，呼叫 `get_invocation_status`。
5. 若該呼叫仍在執行，寫入 `error`（`agent_busy`），結束本 node。
6. 若該呼叫已完成，取回結果，並呼叫 `update_task` 寫入結果。
7. 第 5 步不成立時，清除 `inflight`。

轉導步驟：

1. 若 `text` 不為空，使用 `text`。否則使用 `pending_text`。
   兩者皆空時，本 Agent 轉導空字串。功能型 Agent 依 7.2 節回覆。
2. 組出呼叫內容（第 7.2 節）。`resume` 欄位取自 state。
3. 呼叫 `invoke_agent`，冪等鍵為 `{thread_id}:{activity_id}`。
4. 呼叫 `update_task`，寫入回應中的 `task_status`、`task_summary`、`requirement_id`。
5. 若回應帶新的 `requirement_id`，更新 `active_requirement_id`。
6. 清除 `pending_text`。

逾時時，本 Agent 執行下列步驟：

1. 本 Agent 不直接重送。
2. 本 Agent 呼叫 `get_invocation_status`，以冪等鍵查詢呼叫狀態。
3. 若狀態為已完成，本 Agent 取回結果，並執行轉導步驟 4–6。
4. 若狀態為執行中，本 Agent 把任務 ID 與冪等鍵寫入 `inflight`。
5. 第 4 步之後，本 Agent 把 `agent_result.state` 設為 `processing`。
6. 若狀態為不存在，本 Agent 重送一次。
7. 若狀態查詢失敗，本 Agent 寫入 `error`（`agent_unknown`）並告警。

第 7 步不重送。原因：功能型 Agent 可能已寫入需求或 Jira。
`compose_reply` 依 `agent_result.state` 輸出 `status = processing`。
功能型 Agent 完成後通知使用者。
通知機制依藍圖 Q10 的 POC 結果決定。

### 5.5 `resume_task`

職責：接續使用者在任務卡片選擇的任務。
步驟：

1. 呼叫 `get_task`，取得 `intent.task_id` 的任務。
2. 若查無任務或擁有者不是本人，寫入 `error`（`task_not_owned`）。
3. 若任務狀態為 `done` 或 `cancelled`，寫入 `error`（`task_closed`）。
4. 執行 5.3 節的前置檢查 1、3、4。
5. 呼叫 `update_task`，更新 `updated_at`。
6. 把任務記錄的功能型 Agent、任務 ID、需求編號寫入 `active_*`。
7. 把 `resume` 設為 true。

第 2 步不區分「查無」與「非本人」。原因：避免洩漏任務是否存在。

### 5.6 待轉導訊息規則（`pending_text`）

1. `load_session` 在新訊息到達時清除 `pending_text`。
2. `ask_intent` 只在 `text` 不為空時寫入 `pending_text`。
3. `list_tasks` 只在 `idle_expired` 為 true 時寫入 `pending_text`。
4. `forward_to_agent` 轉導成功後清除 `pending_text`。
5. `end_session` 清除 `pending_text`。

第 2 步的原因：卡片回合的 `text` 為空，不得覆蓋原文。

### 5.7 `list_tasks`

職責：列出使用者的任務，並產生任務卡片。
步驟：

1. 若 `idle_expired` 為 true，清除 `active_*`。
2. 若 `idle_expired` 為 true，把 `text` 存為待轉導訊息。
3. 呼叫 `list_tasks` Tool，查詢本人的任務（規則見 9.2 節）。
4. 把結果寫入 `task_options`。
5. 產生任務卡片，寫入 `card` 與 `open_card_id`。
6. 若 `idle_expired` 為 true，任務卡片說明工作階段已逾時。

`idle_expired` 為 false 時，本 node 不改使用中 Agent。
原因：使用者只想查看任務，不一定要離開使用中 Agent。
查詢失敗時，本 node 寫入 `error`（`list_failed`）。

## 6. Edge 與控制流

### 6.1 路由表

路由函式依表格由上而下比對。第一個成立的條件決定目標。
表中「門檻」：使用中 Agent 為空時是 0.8，不為空時是 0.9。

| 來源 | 條件（路由函式） | 目標 |
|---|---|---|
| `load_session` | 一律 | `resolve_user` |
| `resolve_user` | `error is not None` | `compose_reply` |
| `resolve_user` | `card_action is not None` | `apply_card_action` |
| `resolve_user` | `idle_expired` | `list_tasks` |
| `resolve_user` | `auto_route_enabled == false` 且 `active_agent` 不為空 | `forward_to_agent` |
| `resolve_user` | `auto_route_enabled == false` | `ask_intent` |
| `resolve_user` | 否則 | `classify_intent` |
| `apply_card_action` | `action == new_task` 且 `agent` 為空 | `ask_intent` |
| `apply_card_action` | `action in {select_agent, new_task}` 且有效 | `bind_task` |
| `apply_card_action` | `action == resume_task` 且有效 | `resume_task` |
| `apply_card_action` | `action == end_session` 且有效 | `end_session` |
| `apply_card_action` | 否則（過期或無效） | `ask_intent` |
| `classify_intent` | `to_agent` 且 `confidence ≥ 0.8`，目標等於使用中 Agent，需求為空或等於使用中需求 | `forward_to_agent` |
| `classify_intent` | `to_agent` 且 `confidence ≥ 門檻` | `bind_task` |
| `classify_intent` | `active_agent` 不為空，且 `intent == continue` | `forward_to_agent` |
| `classify_intent` | `active_agent` 不為空，`to_agent` 且 `confidence ≥ 0.8` | `forward_to_agent` |
| `classify_intent` | `intent == list_tasks` 且 `confidence ≥ 0.8` | `list_tasks` |
| `classify_intent` | `intent == end_session` 且 `confidence ≥ 0.8` | `end_session` |
| `classify_intent` | 否則（含 `unclear`、`confidence < 0.8`、無使用中 Agent 的 `continue`） | `ask_intent` |
| `bind_task`、`resume_task` | `error is None` | `forward_to_agent` |
| `bind_task`、`resume_task` | `error.code in {requirement_missing, requirement_not_found, stage_mismatch}` | `ask_intent` |
| `bind_task`、`resume_task` | 否則 | `compose_reply` |
| `forward_to_agent` | `error.code == no_active_agent` | `ask_intent` |
| `forward_to_agent`、`end_session`、`ask_intent`、`list_tasks` | 一律（`forward_to_agent` 為否則） | `compose_reply` |
| `compose_reply` | 一律 | END |

### 6.2 規則

- 所有路由函式是純函式。路由函式不呼叫 LLM。
- 每個來源都有 fallback 去向。
- 本圖沒有迴圈。
- 下一回合在同一 thread 接續多輪對話。
- `recursion_limit = 12`。理論最長路徑是 7 個 node。
- 使用中 Agent 存在時，切換門檻提高到 0.9。
- 信心介於 0.8 與 0.9 時，本 Agent 轉導到使用中 Agent。
- 原因：本 Agent 不應把追問的回答誤判為切換。
- `to_agent`、`list_tasks`、`end_session` 的信心低於 0.8 時，本 Agent 回覆意圖卡片。
- `continue` 不看信心。使用中 Agent 存在時，本 Agent 一律轉導。
- 本規格把門檻放設定檔。

### 6.3 需求階段對照表

| 目標 Agent | 允許的需求階段 | 需求編號 |
|---|---|---|
| Prototype | 任何階段 | 可為空 |
| Proposal | 無需求或「提案中」 | 可為空 |
| Interview | 訪談中 | 必填 |
| Solution | 方案評估 | 必填 |
| SA Document | 開發規劃 | 必填 |

本表的階段值沿用藍圖 D6 的提議版（藍圖 Q5 未定）。
檢查失敗時，`bind_task` 寫入 `error`。
`ask_intent` 依 `error` 產生意圖卡片。
意圖卡片顯示錯誤原因，並提供需求編號輸入欄。

### 6.4 主要流程

**流程 A：意圖明確**

1. 使用者送出訊息。
2. `classify_intent` 判斷出目標 Agent。
3. `bind_task` 取得任務。
4. `forward_to_agent` 呼叫目標 Agent。
5. `compose_reply` 回覆目標 Agent 的結果。

**流程 B：意圖不明**

1. 使用者送出訊息。
2. `classify_intent` 輸出 `unclear`。
3. `ask_intent` 保存待轉導訊息。
4. `ask_intent` 產生意圖卡片。本回合結束。
5. 使用者在意圖卡片選擇 Agent。
6. 下一回合，`apply_card_action` 驗證卡片動作。
7. `bind_task` 取得任務。
8. `forward_to_agent` 把待轉導訊息轉導到目標 Agent。

**流程 C：接續任務**

1. 使用者說「列出我的任務」。
2. `list_tasks` 產生任務卡片。本回合結束。
3. 使用者在任務卡片選一筆任務。
4. 下一回合，`apply_card_action` 驗證卡片動作。
5. `resume_task` 檢查任務，並設定使用中 Agent。
6. `forward_to_agent` 以 `resume = true` 轉導到該任務使用的功能型 Agent。

**流程 D：閒置逾時**

1. 使用者在閒置 8 小時後送出訊息。
2. `load_session` 判定閒置逾時。
3. `list_tasks` 清除使用中 Agent，並保存待轉導訊息。
4. `list_tasks` 產生任務卡片。卡片說明工作階段已逾時。
5. 使用者選一筆任務或選新任務。
6. 後續步驟同流程 B 或流程 C。

## 7. Tool 與外部整合

### 7.1 Tool 清單

| Tool | 用途 | 讀／寫 | 權限 scope | 冪等鍵 | Timeout | 失敗語意 | API Owner |
|---|---|---|---|---|---|---|---|
| `get_user_profile` | 取得使用者姓名與角色 | 讀 | `users:read` | 不需 | 3s | 查無 → 拒絕服務 | 待定（開放問題 3） |
| `list_tasks` | 查詢使用者的任務 | 讀 | `tasks:read`（限本人） | 不需 | 3s | 5xx → 重試 | 本專案 |
| `get_task` | 查詢單筆任務 | 讀 | `tasks:read`（限本人） | 不需 | 3s | 查無 → 拒絕 | 本專案 |
| `upsert_task` | 建立任務 | 寫 | `tasks:write`（限本人） | `{thread_id}:{activity_id}` | 3s | 5xx → 重試 | 本專案 |
| `update_task` | 更新任務狀態 | 寫 | `tasks:write`（限本人） | `task_id` | 3s | 覆寫，可重試 | 本專案 |
| `get_requirement` | 查詢需求階段 | 讀 | `requirements:read` | 不需 | 3s | 查無 → 拒絕 | 本專案 |
| `invoke_agent` | 呼叫功能型 Agent | 寫 | `agents:invoke` | `{thread_id}:{activity_id}` | 120s | 見 5.4 | 本專案 |
| `get_invocation_status` | 查詢呼叫狀態 | 讀 | `agents:invoke` | 不需 | 3s | 失敗 → `agent_unknown` | 本專案 |

規則：

- 資料層強制「限本人」。本 Agent 不依賴 prompt。
- `agents:invoke` 指 AgentCore Runtime 的呼叫權限。
- Graph config 注入 `user_id`。
- 本 Agent 忽略 LLM 輸出中的任何使用者 ID。

### 7.2 功能型 Agent 呼叫契約

本 Agent 送出：

| 欄位 | 型別 | 說明 |
|---|---|---|
| `task_id` | string | 任務 ID。 |
| `requirement_id` | string \| null | 需求編號。 |
| `user` | object | `user_id` 與角色。本 Agent 不傳送姓名。 |
| `text` | string | 使用者原文。可為空。 |
| `attachments` | list | 附件參照。 |
| `resume` | bool | 接續任務時為 true。 |

`text` 為空時，功能型 Agent 回覆任務目前的進度或開場說明。

功能型 Agent 回傳：

| 欄位 | 型別 | 說明 |
|---|---|---|
| `reply_text` | string | 給使用者的文字。 |
| `card` | object \| null | 功能型 Agent 自己的卡片。 |
| `task_status` | enum | `in_progress` / `waiting_user` / `done` / `cancelled` |
| `task_summary` | string | 一句話摘要，顯示於任務卡片。 |
| `requirement_id` | string \| null | Proposal Agent 建立需求後回傳。 |

`runtimeSessionId` 規則：

1. 本 Agent 用 `task_id` 產生 `runtimeSessionId`。
2. 同一任務使用同一 `runtimeSessionId`。
3. AgentCore 在 session 閒置 15 分鐘後終止 session。
4. 所以功能型 Agent 必須用 `task_id` 載入任務狀態。

## 8. 模型與 Prompt 管理

| Node | 模型角色 | 參數 | 輸出格式 |
|---|---|---|---|
| `classify_intent` | 小型快速模型 | temperature 0 | 結構化（`IntentResult`，Pydantic 驗證） |

- 只有 `classify_intent` 使用 LLM。
- `compose_reply` 用模板產生回覆文字。
- 設定檔位置：`agents/orchestration-agent/config/models.yaml`。
- Prompt 位置：`agents/orchestration-agent/prompts/classify_intent.v<N>.md`。
- Prompt 內容必須包含五個功能型 Agent 的職責說明。
- 職責說明取自藍圖。藍圖更新時，Owner 同步更新 prompt。
- 變更流程：Prompt 或模型變更必須附第 13 章的 eval 報告。
- Fallback：主要模型不可用時，`classify_intent` 輸出 `unclear`。
- 結果：使用者收到意圖卡片。服務不中斷。

## 9. Memory 與 Persistence

### 9.1 工作階段

| 項目 | 決定 |
|---|---|
| Checkpointer | 正式環境：資料庫型 checkpointer；測試環境：in-memory |
| `thread_id` 規則 | `teams:{tenant_id}:{conversation_id}` |
| 工作階段範圍 | 一個一對一聊天對應一個工作階段 |
| 閒置規則 | 閒置超過 8 小時，清除使用中 Agent（見 5.2、5.7） |
| 保留期限與清理 | 最後活動後 90 天刪除 checkpoint |
| 短期記憶 | `compose_reply` 把回覆文字加入 `messages`，再以 `RemoveMessage` 保留最近 10 則 |
| 長期記憶（`Store`） | **v0.1 不使用**。任務清單由 `tasks` 集合提供。 |
| Replay／time-travel | 只允許在複本環境除錯。禁止重放 `forward_to_agent`。 |

本 Agent 的 checkpoint 只存工作階段。
功能型 Agent 自行保存自己的對話內容。
保存位置是藍圖的 `conversations` 集合。

### 9.2 `tasks` 集合（新增）

藍圖沒有任務實體。本規格新增 `tasks` 集合。

| 欄位 | 型別 | 說明 |
|---|---|---|
| `task_id` | string | 格式 `T-YYYYMMDD-NNNN`。 |
| `user_id` | string | 任務擁有者。 |
| `agent` | AgentName | 處理任務的功能型 Agent。 |
| `requirement_id` | string \| null | 對應需求。 |
| `status` | enum | `in_progress` / `waiting_user` / `done` / `cancelled` |
| `summary` | string | 功能型 Agent 回傳的一句話摘要。 |
| `runtime_session_id` | string | 由 `task_id` 產生。 |
| `created_at` | datetime | 建立時間。 |
| `updated_at` | datetime | 更新時間。 |

任務卡片規則：

1. `list_tasks` 只查 `user_id` 等於本人的任務。
2. `list_tasks` 排除 `done` 與 `cancelled`。
3. `list_tasks` 依 `updated_at` 由新到舊排序。
4. 任務卡片最多顯示 10 筆。
5. 每筆顯示 Agent、需求編號、摘要、更新時間。
6. 任務卡片另提供「新任務」按鈕。
7. 只有 `idle_expired` 為 true 時，`list_tasks` 才寫入 `pending_text`。

v0.1 的「與使用者有關」只指使用者擁有的任務。
擴大範圍見開放問題 2。

## 10. Human-in-the-loop

不適用 `interrupt`：本 Agent 沒有高風險動作需要人工核准。

意圖卡片與任務卡片不使用 `interrupt`。
原因如下：

1. 卡片動作是新的 Teams Activity。
2. 新的 Activity 會觸發新的回合。
3. 本 Agent 以「結束本回合、下回合接續」處理卡片。
4. 此方式不會重跑 node，沒有重放風險。

卡片過期規則：

- 本 Agent 只接受 `open_card_id` 對應的卡片動作。
- `apply_card_action` 驗證成功後，清除 `open_card_id`。
- 所以每張卡片只能使用一次。
- 本 Agent 把舊卡片的動作視為過期，並回覆新的意圖卡片。

## 11. 錯誤處理與韌性

| 失敗情境 | `error.code` | 偵測方式 | 處理策略 | 對使用者的呈現 |
|---|---|---|---|---|
| LLM 輸出不合 schema | — | Pydantic 驗證失敗 | 重試 1 次；仍失敗則 `intent = unclear` | 意圖卡片 |
| LLM 逾時或不可用 | — | 逾時例外 | `intent = unclear` | 意圖卡片 |
| 查無使用者 | `user_not_found` | `get_user_profile` 回傳 404 | 拒絕服務，記錄稽核 | 「您沒有使用權限，請聯絡管理員。」 |
| 群組聊天或頻道 | `group_chat` | `conversation_type` 不是 `personal` | 拒絕服務 | 「請在一對一聊天中使用。」 |
| 使用者資料服務 5xx | `user_service_down` | HTTP 狀態 | 重試 3 次；仍失敗則拒絕服務 | 「系統忙碌，請稍後再試。」 |
| 角色無權使用目標 Agent | `role_denied` | `bind_task` 檢查 1 | 不轉導，記錄稽核 | 「您的角色無法使用 {Agent}。」 |
| 未提供需求編號 | `requirement_missing` | `bind_task` 檢查 2 | 不轉導 | 意圖卡片＋需求編號輸入欄 |
| 需求不存在 | `requirement_not_found` | `bind_task` 檢查 3 | 不轉導 | 意圖卡片＋「找不到這筆需求」 |
| 需求階段不符 | `stage_mismatch` | `bind_task` 檢查 4 | 不轉導 | 意圖卡片＋目前階段 |
| 任務不屬於本人 | `task_not_owned` | `resume_task`、`forward_to_agent` 檢查 | 不轉導，記錄稽核，告警 | 「找不到這筆任務。」 |
| 無使用中 Agent | `no_active_agent` | `forward_to_agent` 檢查 | 不轉導 | 意圖卡片 |
| 任務查詢失敗 | `list_failed` | `list_tasks` 5xx | 重試 3 次 | 「暫時無法列出任務，請稍後再試。」 |
| 功能型 Agent 逾時 | — | 逾時例外；`agent_result.state == processing` | 先查詢後重送（見 5.4） | 「仍在處理中，完成後通知您。」 |
| 呼叫狀態未知 | `agent_unknown` | `get_invocation_status` 失敗 | 不重送，告警 | 「處理狀態不明，請稍後查看任務。」 |
| 功能型 Agent 回傳錯誤 | `agent_error` | 回應錯誤碼 | 不重試；保留使用中 Agent | 「{Agent} 暫時無法處理，請稍後再試。」 |
| Teams 重送 Activity | — | Bot Adapter 發現重複的 `activity_id` | Bot Adapter 丟棄重送。Tool 冪等鍵是第二道防線 | 無感 |
| 上一次呼叫仍在執行 | `agent_busy` | `forward_to_agent` 前置檢查 5 | 不轉導 | 「{Agent} 仍在處理上一則訊息，請稍後。」 |
| 任務已結束 | `task_closed` | `resume_task` 步驟 3 | 不轉導 | 「這筆任務已結束。請說『列出我的任務』。」 |
| 超過 `recursion_limit` | — | Bot Adapter 捕捉例外 | Bot Adapter 告警，並以 `update_state` 清除使用中 Agent | 「系統發生錯誤，請重新開始。」 |
| 任務或需求服務 5xx | `task_service_down` | `bind_task`、`resume_task`、`forward_to_agent` 的 Tool 失敗 | 依 RetryPolicy 重試；仍失敗則不轉導 | 「系統忙碌，請稍後再試。」 |
| 結束工作階段 | — | `ended_agent` 不為空 | `compose_reply` 讀取 `ended_agent` | 「已結束與 {Agent} 的對話。」 |
| Checkpointer 不可用 | — | 連線錯誤 | 拒絕服務，不做無狀態處理 | 「系統忙碌，請稍後再試。」 |

## 12. 安全、隱私與治理

### 12.1 威脅模型

1. 使用者在訊息中夾帶指令，誘導本 Agent 轉導或越權。
2. 使用者偽造卡片動作，接續他人的任務。
3. 使用者在訊息中冒用他人 ID。
4. Trace 或日誌洩漏個資。

### 12.2 控制措施

- 本 Agent 把使用者訊息視為資料，不視為指令。
- Prompt 以分隔標記包住使用者訊息。
- `classify_intent` 只輸出 `IntentResult`。
- `classify_intent` 不能呼叫 Tool。
- 本 Agent 只採用 Bot Adapter 驗證後的 `user_aad_id`。
- `resolve_user` 拒絕 `personal` 以外的對話類型。
- 資料層強制任務擁有者檢查。
- `resume_task` 與 `forward_to_agent` 每回合重新檢查擁有者。
- 程式碼強制下列角色權限表：

| 角色 | 可使用的功能型 Agent |
|---|---|
| 需求提案人 | Prototype、Proposal |
| 提案 BA | Prototype、Proposal |
| BA | Prototype、Proposal、Interview、Solution |
| SA | 全部 |

本表的角色沿用藍圖。
Domain 審查者需確認本表（開放問題 4）。

### 12.3 個資、稽核與合規

- 個資分類：姓名與 AAD ID 屬個資。
- Trace 遮罩姓名。
- Trace 以雜湊值記錄 AAD ID。
- 本 Agent 不把姓名傳給 LLM。
- 本 Agent 記錄四類稽核事件：拒絕服務、越權嘗試、任務建立、任務接續。
- 稽核紀錄的保留期限依銀行資料保存政策（開放問題 5）。
- 紅隊測試：上線前完成一輪，紀錄存於 `evals/redteam/`。
- 合規：資料落地與權限模型待藍圖 Q7 決議。

## 13. 評估與測試

### 13.1 測試分層

| 層級 | 內容 | 執行時機 |
|---|---|---|
| Node 單測 | mock LLM 與 Tool；驗證讀寫契約與路由函式 | 每個 PR |
| Graph 整合測試 | 真實 graph＋fake Tool＋腳本化 LLM；驗證四條主要流程、卡片過期、卡片重按、冪等 | 每個 PR |
| 線上模型 Eval | 意圖測試集＋真實模型 | Prompt／模型變更時；每週排程 |
| 紅隊測試 | injection、偽造卡片、冒用 ID | 上線前、重大變更時 |

### 13.2 評估資料集

- 來源：試點案例的真實訊息（去識別化）＋人工構造的邊界案例。
- 規模：v0.1 共 200 筆。
- 組成：五個 Agent 各 25 筆、`continue` 30 筆、`list_tasks` 15 筆、`end_session` 10 筆、`unclear` 20 筆。
- 另含惡意輸入 25 筆。
- 每筆包含：輸入、使用中 Agent、期望意圖、期望目標 Agent、期望需求編號。
- 更新機制：每月從線上意圖卡片的選擇結果回補。

### 13.3 指標與發版門檻

| 指標 | 定義 | 發版門檻 |
|---|---|---|
| 意圖轉導正確率 | 目標 Agent 與標註一致的比例 | ≥ 95% |
| 需求編號擷取正確率 | `requirement_id` 與標註一致的比例 | ≥ 98% |
| `continue` 正確率 | 使用中 Agent 存在時，不誤判為切換的比例 | ≥ 97% |
| 路徑正確率 | 實際 node 路徑與期望一致的比例 | ≥ 95% |
| **零容忍案例通過率** | 不得顯示或接續他人任務；查無使用者或群組聊天時不得呼叫 Agent | **= 100%** |
| 待轉導訊息保留率 | 卡片回合後，目標 Agent 收到原文的比例 | = 100% |
| P95 延遲／每回合成本 | 見 1.2 節 | 達標 |

任一指標低於門檻，即阻擋合併或發版。

## 14. 可觀測性與營運

- Tracing 方案：OpenTelemetry，接 AgentCore Observability。
- Trace 標籤：`agent=orchestration-agent`、`spec_version`、`prompt_version`、`thread_id`、`task_id`。
- 關鍵指標：
  1. 意圖分佈
  2. 意圖卡片出現率
  3. 各 Agent 轉導量
  4. 任務接續率
  5. P50／P95 延遲
  6. 每回合成本
- 告警：

| 條件 | 等級 |
|---|---|
| 越權嘗試（任何一次） | P1 |
| `invoke_agent` 錯誤率 > 5%（5 分鐘） | P1 |
| 意圖卡片出現率 > 40%（1 小時） | P2 |
| P95 延遲 > 5 秒（15 分鐘） | P2 |

- SLO：可用性 99.5%（月）。
- 部署：AgentCore Runtime。
- Secret Manager 管理秘密值。
- Feature flag：`auto_route_enabled`。
- 關閉 flag 後，本 Agent 不呼叫 LLM。
- 關閉 flag 後，使用中 Agent 存在時，本 Agent 直接轉導。
- 關閉 flag 後，使用中 Agent 為空時，本 Agent 回覆意圖卡片。
- 灰度與回滾：

1. 先開放試點 SA 群組。
2. 再開放全部 SA 與 BA。
3. 最後開放需求提案人。
4. 回滾時，Prompt 與 graph 版本一起回滾。
5. State 的 Major 變更前，先排空在途工作階段。

- 成本預算：每月上限於 FinOps 看板設定。
- Runbook：`ops/orchestration-agent.md`（待撰寫）。

## 15. 決策紀錄、風險與待決事項

### 15.1 重要決策

| ADR | 決定 | 理由摘要 |
|---|---|---|
| 0001 | 採用受控 workflow，不採用 Supervisor | 轉導可窮舉，必須可預測與可稽核。 |
| 0002 | 卡片採「結束本回合、下回合接續」 | 卡片動作是新 Activity，不需要 `interrupt`。 |
| 0003 | 新增 `tasks` 集合 | 藍圖沒有任務實體，任務卡片需要它。 |
| 0004 | 回覆文字用模板，不用 LLM | 降低延遲與成本。避免改寫功能型 Agent 的內容。 |
| 0006 | 卡片前暫存使用者原文（`pending_text`） | 使用者選卡片後，目標 Agent 仍收到原問題。 |
| 0005 | 使用中 Agent 存在時，提高切換門檻 | 避免追問回答被誤判為切換。 |

### 15.2 已知風險

| 風險 | 影響 | 緩解 |
|---|---|---|
| Teams 長任務回呼無官方樣式（藍圖 Q10） | 使用者收不到結果 | 先做 POC；失敗時改用輪詢 |
| 需求階段值未定（藍圖 Q5） | 6.3 節對照表需改 | 對照表放設定檔 |
| 角色資料來源未定 | `resolve_user` 無法實作 | 開放問題 3 |
| 功能型 Agent 未遵守 7.2 節契約 | 任務狀態錯誤 | 契約測試列入每個 Agent 的 CI |

### 15.3 開放問題

| # | 問題 | 負責人 | 期限 |
|---|---|---|---|
| 1 | 本 Agent 的 LangGraph 選型是否與功能型 Agent 一致？ | 待定 | 待定 |
| 2 | 「與使用者有關的任務」是否包含使用者參與的需求？ | 待定 | 待定 |
| 3 | 使用者角色從哪個系統取得？Entra ID 群組或行內系統？ | 待定 | 待定 |
| 4 | 12.2 節的角色權限表是否正確？ | Domain 審查者 | 待定 |
| 5 | 稽核紀錄保留期限為多久？ | Security 審查者 | 待定 |
| 6 | 是否支援群組聊天與頻道？ | 待定 | 待定 |
| 7 | 閒置 8 小時的閾值是否合適？ | 待定 | 待定 |

### 15.4 變更紀錄

| 版本 | 日期 | 摘要 | 影響（Major／Minor／Patch） |
|---|---|---|---|
| 0.1.0 | 2026-10-04 | 初版 | — |
