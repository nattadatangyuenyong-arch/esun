# AML 未完成高風險定審支出交易管控 - 执行紀錄（整理版）

## 1. 執行背景
- 需求編號：CONF_B01_20260408_02_[AML]
- 類型：Solution Agent 模擬執行紀錄
- 目標：確認需求範圍、蒐集 EDLS/WCP 證據、判斷系統責任邊界，最終產出方案共識書
- 結論：SOL-B（責任分離）

---

## 2. N0 — 任務受理
- 受理內容：確認沒有重複執行、建立 thread / revision / run 紀錄
- 狀態：PASS
- 備註：以需求編號與需求摘要作為唯一識別，避免同一需求重跑

---

## 3. N1～N4 — 範圍識別與候選範圍確認
- 來源：結構化需求文件、SA 查證文件
- 候選關鍵字：EDLS、智富/財富系統、WCP、WISE、AML、交易通路、臨櫃、自動化設備
- 初步候選集：EDLS、NBS、PIB、MIB、WISE、WCP、GIB、IVR、AML
- 使用者補充後：固定範圍為 [EDLS, WCP, WISE]
- 但實際執行中發現：CodeGraph 專案清單中僅存在 edls、wcp，WISE 不在索引中
- 因此，N4 之後的調查策略改為：先以 EDLS 強證據為主，另以 WCP 通路/transfer/wise 相關語意補強

---

## 4. N5 — CodeGraph 證據蒐集（實際執行紀錄）

### 4.1 專案索引
執行：codegraph_list_project

輸出：
```text
edls
wcp
```

判定：
- EDLS 可查
- WCP 可查
- WISE 不在目前 CodeGraph 專案索引內，需由需求文件與業務邏輯補強

### 4.2 EDLS：AML 狀態欄位
執行：project: edls / queryText: AML

結果摘要：
```text
field       amlMark
  .../DeptAccPo.java:85
  String amlMark

field       amlMarker
  .../DepositAccountInfo.java:96
  String amlMarker

field       amlReviewStatusCode
  .../CifCustomerPo.java:446
  String amlReviewStatusCode

field       amlControlStatusCode
  .../CifCustomerPo.java:448
  String amlControlStatusCode

method      setAmlReviewStatusCode
  .../CifCustomerPo.java:2281

method      setAmlControlStatusCode
  .../CifCustomerPo.java:2295
```

解讀：
- EDLS 內部確實存有 AML 狀態欄位
- 顧客層級 AML 管控狀態是實際資料層資訊，不只是 UI 展示
- 這與需求文件中的 H030 / Account Review 管控語意相一致

### 4.3 EDLS：Account Review 語意查證
執行：project: edls / queryText: "Account Review"

結果摘要：
```text
class       ReviewSealDataAccessorImpl
method      ReviewSealStatusEnum
```

判定：
- 這類字串不是單一明確 symbol
- 噪音較大，不適合直接作為唯一證據
- 但它仍顯示 EDLS 內存在 review / seal / status 的制度化資料模型

### 4.4 EDLS：交易阻擋與轉出處理
執行：project: edls / queryText: transferregistered

摘要：
```text
method transferRegistered
method transferRegisteredInputCheck
```

執行：project: edls / queryText: "deposit block"

摘要：
```text
method block
  DepositBlockServiceImpl.java:691
```

解讀：
- EDLS 內有明確的轉出交易與 block 處理邏輯
- 這非常接近需求中的「支出交易被管控」描述
- 支持結論：EDLS 是交易管控實作邊界的重要系統

### 4.5 H030 的查證
執行：project: edls / queryText: H030

結果：
- 無明確 H030 symbol 命中
- 僅有 loan/common enum 中的其他代碼值（如 B030 / C030 / L030 / P030 / Y030）

判定：
- H030 更像業務語意，而非直接 technical symbol
- 應由 amlReviewStatusCode / amlControlStatusCode 反推其真實狀態
- 因此在模擬資料中，H030 不應被視為硬編碼常數，而是「顧客 AML 控制狀態」的業務命名

---

## 5. N5（續）— WCP 轉向交易通路比對法

### 5.1 WCP：AML / Account Review 查不到
執行：project: wcp / queryText: AML
結果：無命中

執行：project: wcp / queryText: "Account Review"
結果：無命中

解讀：
- WCP 並不是以 AML / Account Review 字面命名來建模
- 這不代表 WCP 不做判斷，而是代表它更可能依交易通路、轉帳、wise、riskCheck 做邏輯判斷

### 5.2 WCP：改查通路與交易邏輯
執行：project: wcp / queryText: transfer
結果摘要：
```text
class       TransferLog
method      transferAccBal
```

執行：project: wcp / queryText: channel
結果摘要：
```text
field       channel
field       channelTyp
```

執行：project: wcp / queryText: wise
結果摘要：
```text
class       WiseWmBatchAction
class       WiseWme000000Action
class       WiseWme027010Action
class       WiseWme039050Action
```

執行：project: wcp / queryText: risk check
結果摘要：
```text
field       riskCheckItem
```

判定：
- WCP 最關鍵的實作語意是 channel / transfer / wise / riskCheck
- 這與需求文件中的「WCP 依交易通路放行或阻擋」完全吻合
- 因此當 AML 查不到時，正確策略不是重複搜 AML，而是轉到通路與轉帳判斷邏輯

---

## 6. N6 — 證據足夠性判斷
- 狀態：SUFFICIENT
- 理由：
  - EDLS 有強證據：AML 狀態欄位、交易阻擋邏輯、transfer/block service
  - 需求文件已明確寫出問題範圍與責任邊界
  - WCP 的責任可由 channel/transfer/risk-check 邏輯補強，而非依賴 AML 字面查找

---

## 7. N7 — 影響分析（執行結論）
- 問題的本質不是「AML 檢核失效」
- 問題的本質是「責任邊界錯誤」
- 一般存款與財富業務的交易通路判斷，原本被誤判為同一套條件，導致臨櫃也被一起阻擋
- 正確做法：
  - EDLS 負責一般存款帳戶的 Account Review 管控
  - WCP 負責財富業務之交易通路判斷
  - 臨櫃放行／自動化設備阻擋由通路判斷決定

---

## 8. N8 — 使用者回饋與補充
- 使用者補充：WCP/WISE 的責任邊界還需更明確
- 要點：
  1. WCP 是否直接負責財富業務通路判斷
  2. WISE 是否只是前端或實際交易系統
  3. WCP/WISE 是否仍需在 H030 管控下維持統一阻擋
- 回應：
  - 需求文件與 CodeGraph 證據已有足夠支持：EDLS 對一般存款是核心控管；WCP 對財富業務是通路判斷層
  - 但 WISE 是否為前端或交易系統，仍屬補充事項，未完整索引到該系統時，只能先以業務責任邊界去推定

---

## 9. N9～N15 — 方案生成與最終決策

### 9.1 方案 A：EDLS 統一管控
- 概念：維持 EDLS 在交易管控中的主導角色，直接在通路判斷層做臨櫃/自動化差異化
- 優點：改動集中，流程簡單
- 缺點：會讓財富業務與一般存款共用同一套管理邏輯，邊界不清，後續更難維護

### 9.2 方案 B：責任分離
- 概念：
  - EDLS 只負責一般存款帳戶的 Account Review 管控
  - WCP 負責財富業務交易路徑與通路判斷
  - 兩者分工清楚，避免財富業務被誤帶入一般存款的 AML 控制邏輯
- 優點：邊界清晰、符合需求文件、兼顧法遵與顧客體驗
- 缺點：需兩系統協調，部署時序需要注意

### 9.3 決策結果
- 最終選擇：SOL-B
- 決策理由：
  - 需區分 EDLS 與 WCP 的責任範圍
  - 程式邏輯與需求層面的責任邊界一致
  - 可以避免「臨櫃被誤判為自動化設備」的情境
  - 更能符合洗錢防制與顧客因應需求

---

## 10. 最終共識
- 一般存款：EDLS 應依通路差異放行或攔截
- 財富業務：WCP 應依交易通路做判斷
- 臨櫃：可放行
- 自動化設備/理財快易通：維持暫停
- 結論：方案採用 SOL-B，並納入共識書作為最終結果

---

## 11. 產出物
- 需求範圍已確認
- CodeGraph 證據已整理
- 影響分析已完成
- 終案已定案為 SOL-B
- 目標文件：方案共識書 CONF_B01_20260408_02_AML未完成高風險定審支出交易管控範疇調整

---

## 12. 事後備註（實務觀察）
- WISE 不在目前索引專案中，表示實務上若要做更完整證據鏈，仍需要另補一份 WISE/WCP 文件或系統卡
- 在本需求中，最關鍵的實際證據並不是 AML 字面，而是通路判斷與交易阻擋邏輯
- 因此，後續若要強化證據，可改查：
  - transfer
  - channel
  - wise
  - riskCheck
  - deposit block
  - amlReviewStatusCode / amlControlStatusCode

這些字串的組合，才更貼近真實業務與程式碼發生位置。
此時模擬流程必須停在這個節點，拋回給 User：

> User 補充：WCP/WISE 相關的交易通路判斷邏輯與責任界線，請提供至少一份 WCP 交易規則文件或系統卡片，確認：
> 1. WCP 是否直接負責財富業務的通路判斷（臨櫃/自動化）
> 2. WISE 是否為財富業務前端或是其實際交易系統
> 3. WCP/WISE 會不會在 H030 管控下仍需要統一檢查/阻擋

這個補充是必要的，否則 N6 會因為「證據不足」而無法確定 WCP 的管控責任範圍。

### 5.2 實際 CodeGraph 更完整查證（2026-09-19）

以下是本次再進一步執行後的真實查詢紀錄；這一輪目標不再只搜 `AML`，而是朝著「交易阻擋/放行」的落點去找，因為它更接近需求文件的整體論述。

#### 5.2.1 先做篩選：專案清單與語意範圍

```text
mcp_mcp-wrapper-h_codegraph_list_project
stdout:
  edls
  wcp
```

結論：

- `edls` 是本次最重要的證據庫
- `wcp` 可以查，但沒有直接對應 AML / account review 的結果
- `wise` 不存在於 CodeGraph 專案清單中，這符合需求文件中的「WCP/WISE 業務責任界線還需要補充」情境

#### 5.2.2 真實查詢 A：EDLS AML 狀態欄位

```text
project: edls
queryText: AML
```

實際結果摘要：

```text
field       amlMark
  edls-deposit/dao/dao-deposit-base/.../DeptAccPo.java:85
  String amlMark

field       amlMark
  edls-deposit/dao/dao-depositwithdrawal/.../DpWlDeptAccDo.java:65
  String amlMark

field       amlMarker
  edls-deposit/dao/.../DepositAccountInfo.java:96
  String amlMarker

field       amlReviewStatusCode
  edls-common/.../CifCustomerPo.java:446
  String amlReviewStatusCode

field       amlControlStatusCode
  edls-common/.../CifCustomerPo.java:448
  String amlControlStatusCode

method      setAmlReviewStatusCode
  CifCustomerPo.java:2281

method      setAmlControlStatusCode
  CifCustomerPo.java:2295
```

此結果有兩個關鍵意義：

1. EDLS 內部確實存有 AML 狀態欄位，這支持「AML 管控不是前端展示，而是資料層狀態」的認定
2. `CifCustomerPo` 是很重要的證據點，因為它代表顧客層級 AML 狀態被抱在共用資料模型內，和需求文件中「H030 註記在顧客身上」相一致

#### 5.2.3 真實查詢 B：EDLS Account Review 相關字串

```text
project: edls
queryText: "Account Review"
```

實際結果：

- 查詢結果非常雜，很多是 `account`、泛用的 account 相關欄位，不是本需求的核心
- 這說明：`Account Review` 這個字串在 EDLS 內部不是一個單一明顯 symbol，而是跨多層系統的概念，必須依需求文件再做篩選

```text
project: edls
queryText: amlReviewStatusCode
queryText: amlControlStatusCode
```

這兩個精準查詢比整體 `Account Review` 更有價值，因為它們直接對應到顧客 AML 狀態與控管狀態，而且是具體可追蹤的 fields。

#### 5.2.4 真實查詢 C：EDLS 交易阻擋與轉出相關實體

這一輪我有意識地從「轉出交易」與「block」著手：

```text
project: edls
queryText: transferregistered
```

實際結果呈現：

```text
method transferRegistered
  TransferRegisteredController.java
  TransferRegisteredFacadeService.java
  TransferRegisteredFacadeServiceImpl.java

method transferRegisteredInputCheck
  TransferRegisteredFacadeServiceImpl.java:288
```

這代表 EDLS 內有明確的「註冊/轉出/交易狀態」處理層，這比單純搜 `AML` 更接近需求中的「轉出交易控管」。

```text
project: edls
queryText: "deposit block"
```

實際結果顯示：

```text
method block
  DepositBlockServiceImpl.java:691
```

這是很有價值的信號：

- EDLS 內部有明確的 `block` 處理 service
- 這種查法能把需求職責往真正的「交易阻擋」邏輯拉近，而不只是資料欄位
- 這是後續模擬中該保留的證據，因為它支撐「交易受控是由 EDLS 端的 block service/transfer service 判斷」的架構假設

#### 5.2.5 真實查詢 D：H030 這個語意不直接存在

```text
project: edls
queryText: H030
```

實際結果：

- 沒有直接命中 `H030` 相關 symbol
- 只有 loan common enum 內的 `B030 / C030 / L030 / P030 / Y030`

這個結果很關鍵：

- 表示 `H030` 很可能不是 EDLS 內直接字面值的 code，而是業務層的狀態語義（例如 `AML Review Status` / `Control Status`）
- 這與需求文件中的說法一致：H030 是「顧客層狀態」而非硬編碼字面 constant
- 因此在模擬中，我們不應該把 H030 直接當成明確 technical symbol，而是當作一個業務狀態概念，從 `amlReviewStatusCode` / `amlControlStatusCode` 反推它。

#### 5.2.6 真實 Explore：聚焦交易阻擋與顧客 AML 狀態的關聯

```text
project: edls
exploreText: "Find the EDLS AML and Account Review control mechanisms relevant to deposit transfer blocking, especially amlReviewStatusCode, amlControlStatusCode, H030-like customer status, and where transfer/outgoing rules are evaluated."
```

實際結果摘要：

- 系統回傳了大量符號，範圍大約 200 個符號 across 93 files
- 最有價值的回應是：
  - `CifCustomerPo` 中的 AML 相關狀態欄位
  - `TransferRegistered*` 相關資料流
  - `DepositBlockServiceImpl` 中的 `block` 邏輯

這表示：

- 我們已找到「顧客 AML 狀態」和「交易阻擋處理」的兩條主線
- 但仍未直接命中 `WISE`/`WCP` 的具體政策 code，因此這裡界線仍須由需求文件補強

#### 5.2.7 WCP：實際查詢與正確查找策略

當 `AML` / `Account Review` 在 WCP 查不到時，正式的做法是改查「交易通路 / 轉出 / block / channel / wise」等業務入口字串，而不是持續追 `AML` 這種不在此專案中的標籤。

```text
project: wcp
queryText: transfer
```

實際結果摘要：

```text
class       TransferLog
  src/main/java/com/ddsc/platform/log/entity/TransferLog.java:5

method      transferAccBal
  src/main/java/com/ddsc/efly/ptr/service/impl/Ptrb32010ProcessAndWriteServiceImpl.java:596
```

```text
project: wcp
queryText: channel
```

實際結果摘要：

```text
field       channel
  src/main/java/com/ddsc/efly/entity/EflyWrkPicUpd.java:58

field       channelTyp
  src/main/java/com/ddsc/wise/wmi/action/WiseWmi036010Action.java:99
  String channelTyp
```

```text
project: wcp
queryText: wise
```

實際結果摘要：

```text
class       WiseWmBatchAction
class       WiseWme000000Action
class       WiseWme027010Action
class       WiseWme039050Action
```

```text
project: wcp
queryText: branch
```

實際結果摘要：

```text
field       branch
  src/main/java/com/ddsc/common/comm/helper/edls/RequestEDLSApiRequestBodyHeader.java:59
  CommBranch branch
```

```text
project: wcp
queryText: risk check
```

實際結果摘要：

```text
field       riskCheckItem
  src/main/java/com/ddsc/wise/wmw/action/WiseWmw032010Action.java:155
  StringBuilder riskCheckItem
```

這些查詢的共通點是：

- WCP 的 codebase 並不是以 `AML` / `Account Review` 命名，而是以 `transfer`、`channel`、`wise`、`riskCheck` 等實作語意出現
- 這恰好符合需求文件中「WCP 依交易通路判斷放行/阻擋」的敘述
- 因此，當 `AML` 回傳空白時，正確的下一步不是重複 `AML`，而是改查 `channel` / `transfer` / `wise` / `riskCheck` 這些交易決策相關語意

#### 5.2.8 依需求文件削減結論

從結構化需求文件與 CodeGraph 的實際檢索結果來看，以下保留：

- 保留：`EDLS` 內確實存在 `amlReviewStatusCode`、`amlControlStatusCode`，屬於顧客層級 AML 狀態；這對應需求文件中的 H030 管控狀態／Account Review
- 保留：`DepositBlockServiceImpl`、`TransferRegistered*` 這一類 service 位於 EDLS，代表交易阻擋判斷實際落點在 EDLS side
- 保留：需求文件中「財富業務因通路誤判被 EDLS 一律阻擋」的敘述，因為這個技術根因與 `AML` / `transfer` 相關符號的資料流相當吻合
- 削除：`Account Review` 這類廣泛字串大量結果，因為噪音太大，不能拿來直接證明本需求的影響範圍
- 削除：`H030` 直接字面查詢，因為它不在 EDLS code 裡是明確 symbol，應視為業務語意而非 technical symbol
- 削除：`WISE` 直接查詢（目前 project 不存在），因為 CodeGraph 目前無法提供該系統的圖譜證據，需由 User 補充或交由需求文件承接

這樣的削減邏輯，剛好符合你前面要求的「搭配結構化需求文件削減結果」：

- 以需求為主，工具為輔
- 先找強證據（AML 欄位、transfer/block service）
- 再把不具體的模糊字串或不存在的系統排除

---

## N6

### 判斷證據是否足夠產生 Impact Analysis

### 6.1 判斷基準

Agent 在這裡用的是「能否支持下一步 Impact Analysis」的標準，而不是「全部了解細節」的標準。

本次的關鍵判斷：

- EDLS 端有明確 AML 欄位／Account Review 訊號，足以支撐「EDLS 是實際管制層」"這個重點
- WCP 端缺乏直接機碼證據，代表它的責任更多在制度與商業判斷層，而非圖譜中裸露的程式元件
- 需求文件本身已明確陳述：財富業務通路誤傳為自動化設備，導致 EDLS 誤判；因此根本問題是職責分離與通路識別

### 6.2 判斷結果

```text
evidenceSufficiency = SUFFICIENT
```

理由：

1. 需求文件已具體說明問題、目標與方案選擇
2. CodeGraph 能證實 EDLS 內部存在 `amlMark` / `amlReviewStatusCode` / `amlControlStatusCode` 等資料與狀態欄位
3. 需求文件已表明 `Header.資訊資產代號` / `TS0036(TS0068)` 白名單方式是關鍵設計，而這些資訊可作為影響範圍的根據
4. 雖然 WCP 的實作證據不足，但因為本次目標是產生「方案總結」與「Impact Analysis 草稿」，不需要直接到最底層包/函式實作細節，已足以進入草稿產出

因此，進入 N7。

---

## N7

### 生成 Impact Analysis Draft

這是第一個真正定義「影響範圍」與「方案驗證」的節點。以下為模擬產出的草稿內容：

```json
{
  "impactAnalysisDraft": {
    "problemStatement": "因 WISE/FST 等財富業務通路在 EDLS 端被誤判為自動化設備，導致 H030 管控中之顧客在臨櫃交易時同步受限，形成過度管制問題。",
    "rootCause": {
      "technicalDimension": "EDLS 內部對 AML 控制狀態與 review 狀態維持明確資料模型，但財富業務的交易通路判斷被視為固定自動化設備，導致無法識別臨櫃協助情境。",
      "businessDimension": "顧客對 AML 執行過當的認知差異，造成主管機關陳情與客訴風險。"
    },
    "affectedAreas": [
      "EDLS - Account Review 交易控管（TS0108-SA-010122-00008）",
      "EDLS - 財富系統帳務交易（TS0108-SA-010301-00179）",
      "WCP - 財富業務交易通路判斷邏輯",
      "各財富業務前端系統（TS0036 / TS0068 / 其他交易入口）"
    ],
    "expectedChanges": [
      "在 EDLS 的白名單新增 TS0036 / TS0068 / 純臨櫃系統白名單",
      "移除已無使用情境的圈存邏輯呼叫",
      "WCP 依交易通路維持臨櫃放行／自動化阻擋邏輯",
      "TS0035（NICE）維持既有管制"
    ],
    "riskAssessment": [
      "若 WCP 與 EDLS 上線時序不一致，會出現財富業務自動化通路短暫失控風險",
      "若通路欄位缺失或值域不正確，WCP 可能採保守封鎖導致過度管制",
      "若白名單設計不精準，純臨櫃系統可能被錯誤放行"
    ],
    "assumptions": [
      "WCP 能正確識別交易通路",
      "EDLS 的 HEADER.資訊資產代號帶原始呼叫方",
      "CIP 上的 H030 狀態是同步資料來源",
      "TS0035 不屬本次放行範圍"
    ]
  }
}
```

這份草稿已抓住核心：

- 問題並非「AML 管控失效」，而是「職責邊界錯誤」
- 根本修正方法不是讓 EDLS 變成強辨識器，而是讓責任回歸各自系統

---

## N8

### 人工審批關卡：Impact Analysis Review

回報進度，等待人工核准。這次模擬為：

```text
N8 interruptForImpactReview

回應：
- 使用者：這份 Impact Analysis 大方向正確，但 WCP/WISE 的責任界線仍要更明確
- 補充要求：請把 WCP 與 WISE 的交易通路差異說清楚，並確認 `理財快易通` 與臨櫃的區分方法
- 決定：補查後再核准，因為目前未能完全 Affirm 這個輸入邏輯
```

此時代理必須遵循 Conditional Edge：

- `使用者認為證據不夠或範圍抓錯，要求補查` → 回到 `N5`

所以再次走一輪 N5 補查，但這次目標是補足 WCP/WISE 交易通路與前端通路定義。 

### 8.1 補查需求與補查結果

補查內容：

- WCP 交易邏輯中，是否存在「交易通路欄位」
- 是否將 `理財快易通` 視為自動化通路
- WCP 是否在財富業務臨櫃與自動化間明確分流

模擬對話：

```text
User: WCP 的通路判斷邏輯沒有 CodeGraph 證據，我可以補充：
- 交易通路欄位會有 value，如：臨櫃、網銀、行動銀行、理財快易通
- WISE/FST 由 WCP 判斷後再決定是否放行或阻擋
- EDLS 只負責基本存款的 Account Review 控制，財富業務則交由 WCP
```

此時 `evidenceSufficiency` 仍然是 `SUFFICIENT`，因為規則已得到可操作的業務定義； Agent 不必再追求程式碼證據。

使用者核准 Impact Analysis：

```text
N8 -> N9
```

---

## N9

### 組裝標準報告

這個節點將需求、範圍、證據、Impact Analysis 整合為標準報告內容。

```json
{
  "reportPayload": {
    "requirementId": "CONF_B01_20260408_02_[AML]",
    "projectName": "AML未完成高風險定審支出交易管控範疇調整",
    "scope": {
      "inScope": [
        "EDLS Account Review 管控",
        "財富業務通路判斷責任分離",
        "H030 管控中之臨櫃/自動化通路差異",
        "TS0036/TS0068 白名單調整"
      ],
      "outOfScope": [
        "ATM 提款",
        "批次交易",
        "H030 觸發邏輯本身",
        "分行關懷 SOP 變更"
      ]
    },
    "evidence": [
      "EDLS code graph: amlMark, amlReviewStatusCode, amlControlStatusCode",
      "需求文件: 職責分離方案與白名單設計",
      "業務共識: WCP 承接財富業務通路判斷"
    ],
    "impactAnalysis": {
      "decision": "採用 SOL-B：管控責任分離",
      "reason": "在技術與責任邊界上將財富業務通路歸屬明確，避免 EDLS 在錯誤的通路認知下過度阻擋。"
    }
  }
}
```

這些內容後續將成為整份方案共識書的底稿。

---

## N10

### 發佈報告 Artifacts

#### 10.1 產出物

```text
reportS3JsonUrl = s3://solution-agent/reports/CONF_B01_20260408_02_[AML]/report-v1.json
reportS3MarkdownUrl = s3://solution-agent/reports/CONF_B01_20260408_02_[AML]/report-v1.md
reportDownloadLink = https://short.link/xxx-report-download
reportDashboardLink = https://dashboard.example/solution-agent/CONF_B01_20260408_02_[AML]
reportDeliveredAt = 2026-09-19T09:00:00Z
```

#### 10.2 模擬記錄

Agent 在這裡已完成最初的「正式報告交付」，但並不代表方案已確認；這個節點之後必須等人工開始解決方案流程，才會進 N11。

---

## N11

### 人工審批關卡：開始產生方案

這個關卡不是自動執行，而是等待使用者明確聲明：

```text
User: 這份報告可用，請開始產出 2 個解決方案，並至少劃分一個與現行作法最接近的方案（保守版）與一個高分離原則的方案。
```

因此：

```text
proposalCount = 2
workflowStatus = SOLUTIONS_PENDING
```

Agent 進入 N12。

---

## N12

### 生成 Implementation Proposals

這裡模擬產生 2 套方案。為了符合需求文件，方案名稱採用實際共識書的命名：

#### 方案 A：EDLS 統一管控（修正 WISE/WCP 傳值）

```json
{
  "proposalId": "SOL-A",
  "name": "EDLS 統一管控（通路旗標由 WISE/WCP 正確傳入）",
  "summary": "維持 EDLS 為統一 AML 管制中心，要求 WCP/WISE 修正發送至 EDLS 的自動化設備交易註記，從固定 Y 改成依實際通路值傳送。",
  "pros": [
    "責任中心仍集中在 EDLS，實作邏輯直觀",
    "短期可能較容易落地，若 WCP/WISE 皆能正確傳值",
    "EDLS 仍可維持一套統一規則"
  ],
  "cons": [
    "需要 WCP/WISE 共同修正資料傳遞，若任一端漏傳或錯傳，EDLS 會直接誤判",
    "未根本處理財富業務通路認知差異，風控依賴資料品質",
    "整體執行風險高於責任分離方案"
  ],
  "risks": [
    "WCP/WISE 通路欄位缺值造成 EDLS 全面誤判",
    "跨系統協作失敗，導致臨櫃與自動化通路都被錯誤阻擋"
  ],
  "assumptions": [
    "WCP/WISE 能準確傳輸實際通路值",
    "所有交易入口皆已正確帶值"
  ],
  "evidenceRefs": [
    "需求文件: SOL-A 說明",
    "EDLS CodeGraph: amlMark / amlControlStatusCode",
    "共識書: 其他討論過但未採用方案」
  ]
}
```

#### 方案 B：管控責任分離（本次最終採用方案）

```json
{
  "proposalId": "SOL-B",
  "name": "管控責任分離（WCP 承接財富業務管控，EDLS 僅維持一般存款與純臨櫃白名單）",
  "summary": "一般存款由 EDLS 負責；財富業務由 WCP 根據交易通路判斷進行放行或阻擋；EDLS 只保留基本白名單和一般存款臨櫃豁免邏輯。",
  "pros": [
    "根本解決通路認知差異問題",
    "職責分離清楚，不互相干擾",
    "異動面最小，僅需 EDLS 白名單新增與圈存邏輯移除",
    "可維持一般存款自動化設備阻擋，不弱化風控"
  ],
  "cons": [
    "需要 WCP 以及財富業務通路判斷邏輯同步上線",
    "WCP 早於或同時 EDLS 上線是前提，否則可能出現過渡期管控真空",
    "需要明確阻擋訊息文案，避免顧客感知不一致"
  ],
  "risks": [
    "WCP 上線時序錯誤",
    "通路欄位缺值導致 WCP 保守封鎖",
    "前端顯示文案與 EDLS 4220 不一致"
  ],
  "assumptions": [
    "WCP 能先於或同時 EDLS 上線",
    "CIP 同步資料正常",
    "財富業務交易通路欄位必填且有值域檢核"
  ],
  "evidenceRefs": [
    "需求文件: 使用者與業管共識採用 SOL-B",
    "EDLS CodeGraph: amlMark / amlReviewStatusCode / amlControlStatusCode",
    "共識書: 方案定位、規則維護責任、成功樣貌"
  ]
}
```

這兩個提案都符合「2 個方案」的要求，也都能落到需求文件與工具證據中。

---

## N13

### 發佈方案至 Dashboard

```text
proposalPackageVersion = package-fixture-001
availableActions = ["APPROVE_SOL_A", "APPROVE_SOL_B", "REJECT_ALL"]
```

並生成:

```text
dashboard link: https://dashboard.example/solution-agent/CONF_B01_20260408_02_[AML]/proposal-package
```

此時 `workflowStatus` 為 `SOLUTIONS_PUBLISHED`，待使用者在 N14 做決策。

---

## N14

### 人工審批關卡：方案選擇

這裡使用者做出最終決策：

```text
User: 我們選擇方案 B。理由是：
- 這最符合責任邊界
- 可避免 EDLS 強行判定財富業務通路
- 目前需求文件與業管共識已明確支持 SOL-B
- 解決問題最根本、最小異動、最符合合規發展
```

因此：

```json
{
  "decision": {
    "selectedProposalId": "SOL-B",
    "status": "APPROVED",
    "reason": "責任分離是根本解法，且與現有 EDLS/WCP 職責界線最一致，異動最小且最風險可控。",
    "actor": "User",
    "decidedAt": "2026-09-19T09:10:00Z"
  }
}
```

Conditional Edge 為：

- `選一個核准` → `N15`

---

## N15

### finalizeAndArchiveDecision

在最後一個節點中，Agent 需要做以下事情：

1. CAS 儲存決策紀錄
2. 封存決策套件
3. 寫入最終執行摘要
4. 回傳 `__end__`

#### 15.1 最終決策紀錄

```json
{
  "threadId": "run_fixture_req_001",
  "revision": 15,
  "workflowStatus": "COMPLETED",
  "decision": {
    "selectedProposalId": "SOL-B",
    "status": "APPROVED",
    "reason": "根本處理財富業務通路誤判問題，責任邊界清晰，最小異動且合理合法。"
  },
  "archivedPackageUrl": "s3://solution-agent/archive/CONF_B01_20260408_02_[AML]/proposal-package-sol-b-v1.zip",
  "finalOutcome": "方案共識書可依此內容進一步整理與簽核。"
}
```

#### 15.2 產出成品：方案共識書（最終版摘要）

這裡要特別注意：模擬流程不能只停在提案選型，必須把「最後成品」也補齊。以下是由此模擬導出的方案共識書內容骨架，與使用者現有的共識書文件方向一致：

```markdown
# 方案共識書

## 0. 文件資訊
- 專案名稱：CONF_B01_20260408_02_[AML]未完成高風險定審支出交易管控範疇調整
- 版本：V1.1
- 日期：2026-09-19
- 提案者：風險管理處-AML部
- 負責 PO：賴怡伶、王心荷
- 負責 BA：徐千惠
- Sol. Archi.：張哲綸

## 1. 我們要解決的問題
- 因 H030 管控中，財富業務通路被誤判為自動化設備，導致臨櫃交易被一律阻擋。
- 主管機關與顧客認為這是執行過當。
- 鑑於 EDLS 在財富業務與一般存款之間缺乏責任明確性，關鍵問題在於通路識別與責任分離。

## 2. 本次選擇的方案
### SOL-B：管控責任分離
- 一般存款：EDLS 負責。
- 財富業務：WCP 負責實際通路判斷。
- EDLS 白名單增加 TS0036、TS0068 等純臨櫃或財富業務系統識別。
- TS0108-SA-010301-00179 的圈存邏輯移除已無使用情境。

## 3. 系統分工摘要
- EDLS：一般存款 Account Review 管控；新增財富業務白名單。
- WCP：財富業務交易通路判斷。
- TS0035（NICE）：維持原有 EDLS 管制機制。

## 4. 配合測試系統清單
- TS0036 / TS0068：WCP 整合驗證
- TS0035：回歸測試
- EDLS 白名單系統：純臨櫃系統回歸測試

## 5. 本次不處理範圍
- ATM 提款
- 批次交易
- H030 自身觸發邏輯
- 分行關懷 SOP

## 6. 其他討論過但未採用方案
- SOL-A：EDLS 統一管控（不採用）
- SOL-C：中介管控閘道（不採用）

## 7. 成功時的樣子
- 一般存款顧客臨櫃可正常轉出
- 自動化設備仍阻擋
- 財富業務臨櫃正常放行
- 財富業務自動化通路仍阻擋

## 8. 待確認事項
- CL-001：阻擋訊息文案
- CL-009：WCP / EDLS 上線時序

## 9. 結論
本次以 SOL-B 作為最終方案，目的在於把 AML 管控責任由「EDLS 強行辨識財富業務通路」改為「各系統照責任邊界維護」，讓問題從技術根源處解決，而不是事後補救。
```

這份內容正是最終要產出的方案共識書雛形；若後續要進入正式設計階段，下一步就要基於這份共識書撰寫詳細設計、UAT 測試與上線時序計畫。

---

## 10. 結語：此模擬的核心發現

本次模擬最重要的收斂點不是「CodeGraph 找到什麼」，而是：

- EDLS 的 AML/Account Review 欄位與資料模型是確實存在的，因此不可能完全忽略其角色
- 財富業務通路的辨識與放行/阻擋，較適合交給 WCP，而不是讓 EDLS 兜底全部判斷
- 這樣的職責分離，既符合系統責任邊界，也符合客訴與法遵風險管理要求
- 因此，最終結論自然落在 SOL-B：管控責任分離

這也說明了為什麼這份模擬最終不是「單純尋找證據」，而是「在證據不足與業務邏輯交叉下，收斂到最合理的共識方案」。

```text
__end__
```

