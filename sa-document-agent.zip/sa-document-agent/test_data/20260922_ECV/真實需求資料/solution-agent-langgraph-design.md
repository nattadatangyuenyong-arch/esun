# 需求方案小幫手 Solution Agent — LangGraph 設計文件（限縮範圍版）

## 範圍與前提

- 依據 `solution-agent-sequence-diagram-detail.md` 的「Whole Workflow Sequence Diagram」（0930 MVP 限縮範圍）。不含 `SolutionAgent_SD.md` 完整版才有的 Jira/Epic 建立、Checkpointer／LongTermStore／SemanticStore 多層記憶架構。
- 「Knowledge Release 聯合啟用」為主流程外的前提：由 Publisher 觸發，完成 catalog 上傳 S3、CodeGraph pinned snapshot 部署、KB ingestion、Aurora 交易啟用 `knowledgeReleaseVersion`。不在本次 LangGraph 設計範圍內，本流程只讀取它已啟用完成的版本作為輸入前提。
- 整個 MVP 故事線視為同一個 `threadId`、同一次連續執行，中間 4 個人工關卡多次 interrupt/resume，不是拆成多個獨立 graph run。
- 下方 State Schema 為完整欄位定義；各 node 僅讀寫其中對應子集，非全部欄位皆與各 node 相關。各欄位並標示所屬用途類別（業務資料／流程機制），以利區分承載業務內容之欄位與支撐流程運作機制之欄位：`threadId`／`revision`／`expectedRevision`／`eventId` 屬 CAS 與冪等控制；`catalogVersion`／`knowledgeReleaseVersion`／`systemCardVersion`／`codeGraphVersion` 屬版本鎖定；`retryCount.*` 屬容錯重試；`workflowStatus`等欄位屬流程狀態控制。
- 欄位更新方式：除 `codeGraphBindings`／`expectedChanges` 兩欄位於證據補查時採 Merge/Upsert（新查得證據併入既有內容，不覆蓋既有資料）外，State Schema 其餘欄位之更新方式均為 Overwrite（新值取代舊值）。

---

## 0. State Schema

### 追蹤與版本控制

| 欄位 | 型態 | 用途 | 說明 |
|---|---|---|---|
| threadId | string | 流程機制（CAS與冪等） | 本次執行唯一識別 |
| revision | number | 流程機制（CAS與冪等） | 業務狀態版本號，每次狀態變更遞增，寫入前用來做 CAS（compare-and-swap）比對，避免併發覆寫 |
| expectedRevision | number | 流程機制（CAS與冪等） | 指令方帶入的預期版本號，用來跟目前 revision 比對，不符就拒絕寫入 |
| eventId | string | 流程機制（CAS與冪等） | 指令的冪等鍵，同一個 eventId 重複送達時不重複處理 |
| catalogVersion | string | 流程機制（版本鎖定） | 本次執行固定使用的候選目錄版本 |
| knowledgeReleaseVersion | string | 流程機制（版本鎖定） | 本次執行固定使用的 KB release 版本 |
| systemCardVersion | string | 流程機制（版本鎖定） | 本次執行固定使用的 SystemCard 版本 |
| codeGraphVersion | string | 流程機制（版本鎖定） | 本次執行固定使用的 CodeGraph 版本 |
| workflowStatus | enum( ACCEPTED \| SCOPE_PENDING \| SCOPE_NEEDS_INPUT \| EVIDENCE_PENDING \| EVIDENCE_NEEDS_INPUT \| IMPACT_PENDING_APPROVAL \| REPORT_DELIVERED \| SOLUTIONS_PENDING \| SOLUTIONS_PUBLISHED \| DECIDED \| COMPLETED ) | 流程機制（狀態控制） | 整個流程目前所在的主狀態 |

### 需求輸入與範圍確認

| 欄位 | 型態 | 用途 | 說明 |
|---|---|---|---|
| structuredRequirement | object | 業務資料 | 使用者提交的結構化需求內容 |
| requirementId | string | 業務資料 | 需求編號 |
| moduleId | string | 業務資料 | 表示某一個內部系統模組之編號，查 SystemCard 時使用 |
| candidateSnapshot | object[] | 業務資料 | KB retrieve＋精確比對合併＋Nova 排序後的候選卡片清單，供使用者確認範圍時選 |
| selectedCardVersion | string | 業務資料 | 使用者確認選定的卡片版本 |
| scopeConfirmedAt | timestamp | 業務資料 | 範圍確認時間 |

### CodeGraph 證據與 Impact Analysis

| 欄位 | 型態 | 用途 | 說明 |
|---|---|---|---|
| codeGraphBindings | object[] | 業務資料 | 已釘選的 CodeGraph bindings（受影響的程式元件關聯）；補查時採 Merge/Upsert，新查得結果併入既有內容 |
| expectedChanges | object[] | 業務資料 | 預期異動範圍；補查時採 Merge/Upsert，新查得結果併入既有內容 |
| sourceAvailable | boolean | 業務資料 | 是否有原始碼可查驗，此版固定 false，只提供圖結構證據，不含原始碼本身 |
| evidenceSufficiency | enum(SUFFICIENT\|EVIDENCE_NEEDS_INPUT) | 流程機制（狀態控制） | 證據是否足夠產生 Impact Analysis |
| impactAnalysisDraft | object | 業務資料 | Impact Analysis 草稿內容 |
| impactVersion | string | 業務資料 | Impact Analysis 核准版本號 |
| impactApprovedAt | timestamp | 業務資料 | 核准時間 |
| retryCount.bedrock / codeGraph / s3 | number | 流程機制（容錯用） | 各外部服務暫時性失敗的重試次數，上限 1 次 |

### 報告交付

| 欄位 | 型態 | 用途 | 說明 |
|---|---|---|---|
| reportPayload | object | 業務資料 | 標準報告內容，含需求、範圍、證據、Impact Analysis |
| reportS3JsonUrl / reportS3MarkdownUrl | string | 業務資料 | 報告存放的不可變 S3 物件位置 |
| reportDownloadLink | string | 業務資料 | 短效下載連結 |
| reportDashboardLink | string | 業務資料 | Dashboard 檢視連結 |
| reportDeliveredAt | timestamp | 業務資料 | 報告交付時間 |

### 解決方案產生與決策

| 欄位 | 型態 | 用途 | 說明 |
|---|---|---|---|
| proposalCount | enum(2\|3) | 業務資料 | 使用者指定要產生的方案數 |
| proposals | object[] | 業務資料 | 每個提案，各自附固定的 Evidence References |
| proposalPackageVersion | string | 業務資料 | 提案套件版本 |
| availableActions | string[] | 流程機制（狀態控制） | 目前使用者可執行的操作清單 |
| decision.selectedProposalId | string | 業務資料 | 使用者選定的提案 |
| decision.status | enum(APPROVED\|ALL_REJECTED) | 業務資料 | 最終決策結果 |
| decision.reason | string | 業務資料 | 決策原因 |
| decision.actor / decision.decidedAt | string / timestamp | 業務資料 | 決策人與時間 |
| archivedPackageUrl | string | 業務資料 | 決策套件封存位置 |

---

## 1. Node 清單

| ID | 名稱 | 類型 | 說明 |
|---|---|---|---|
| N0 | validateAndAcceptRequest | 運算/邏輯節點 | 驗證 context、需求編號所有權與是否已有 active-run（避免同一需求被重複執行），通過後以 threadId 與 revision 建立受理紀錄寫入 Aurora，作為圖的真正入口 |
| N1 | fetchSystemCardCandidates | 工具節點 | 呼叫 AWS Knowledge Base Retrieve API，帶 moduleId 與 active catalogVersion，取得 SystemCards 候選 |
| N2 | mergeCandidatesByExactMatch | 運算/邏輯節點 | 對檢索結果做精確比對去重合併；KB 不可用時僅能用 active catalog 做精確比對 |
| N3 | rankCandidatesWithNova | 模型/LLM 節點 | 用 Nova 對候選排序，產出候選快照 |
| N4 | interruptForScopeConfirmation | 人工審批節點 | 回傳候選快照（或 SCOPE_NEEDS_INPUT）等待使用者確認範圍；核准後 CAS 固定 catalog／card／graph／release 版本 |
| N5 | queryCodeGraphViaMcp | 工具節點 | 呼叫 CodeGraph MCP（`codegraph_query`／`codegraph_explore`，必要時先 `codegraph_list_project`／`codegraph_show_pwd`），查詢已釘選 bindings 與 expectedChanges，回傳圖結構證據 |
| N6 | evaluateEvidenceSufficiency | 運算/邏輯節點 | 判斷證據是否足以產生 Impact Analysis |
| N7 | generateImpactAnalysisDraft | 模型/LLM 節點 | 證據足夠時，產生 Impact Analysis 草稿 |
| N8 | interruptForImpactReview | 人工審批節點 | 回報進度，使用者核准 Impact Analysis，或提供補充卡片/資訊 |
| N9 | assembleStandardReport | 運算/邏輯節點 | 核准後組裝標準報告內容 |
| N10 | publishReportArtifacts | 工具節點 | 寫入不可變 S3 JSON／Markdown，建立短效下載連結與 Dashboard 連結 |
| N11 | interruptForSolutionStart | 人工審批節點 | 等待使用者明確下達啟動解決方案指令（proposalCount），報告交付不自動觸發 |
| N12 | generateImplementationProposals | 模型/LLM 節點 | 產生恰好 2 或 3 個提案，各自固定 Evidence References |
| N13 | publishProposalsToDashboard | 工具節點 | 儲存提案套件版本與可用操作，發布至 Dashboard 並通知 |
| N14 | interruptForSolutionDecision | 人工審批節點 | 使用者核准選定提案或全部拒絕，帶 packageVersion 與原因 |
| N15 | finalizeAndArchiveDecision | 運算/邏輯節點 | CAS 儲存決策紀錄，封存決策套件，回傳最終結果（`__end__`） |

本場景未設計 Guardrail／檢查與防護節點。

---

## 2. Edge 清單

### Edge（線性推進）

| From | To |
|---|---|
| N0 | N1 |
| N1 | N2 |
| N2 | N3 |
| N3 | N4 |
| N5 | N6 |
| N7 | N8 |
| N9 | N10 |
| N10 | N11 |
| N12 | N13 |
| N13 | N14 |

### Conditional Edge

| From | 條件 | To |
|---|---|---|
| N4 | 使用者看到候選卡片後，確認這次需求的範圍與要用的卡片版本 | N5 |
| N4 | KB 查不到夠好的候選（沒有可接受的精確比對命中），現有候選不足以讓使用者選 | N1 |
| N6 | CodeGraph 查回來的圖結構證據足夠支撐寫出 Impact Analysis | N7 |
| N6 | 證據不足或 CodeGraph 查詢結果不可用，沒辦法可靠產出 Impact Analysis 草稿，跳過草稿產生直接進人工關卡 | N8 |
| N8 | 使用者核准這份 Impact Analysis | N9 |
| N8 | 使用者認為證據不夠或範圍抓錯，要求補查 | N5 |
| N11 | 使用者看到報告後，明確下指令要開始產生解決方案，並指定要 2 個或 3 個方案；系統不會自己啟動 | N12 |
| N14 | 使用者從提案中選一個核准 | N15（決策結果記為 APPROVED） |
| N14 | 使用者把全部提案都拒絕，不重新產生方案，流程直接結束 | N15（決策結果記為 ALL_REJECTED） |

**Retry 邏輯**：Bedrock／CodeGraph／S3 暫時性失敗最多重試一次，屬節點內部邏輯（N1、N5、N10），不另畫 edge。

---

## 3. 拓樸圖

```mermaid
flowchart TD
    N0[N0 validateAndAcceptRequest 邏輯] --> N1[N1 fetchSystemCardCandidates 工具]
    N1 --> N2[N2 mergeCandidatesByExactMatch 邏輯]
    N2 --> N3[N3 rankCandidatesWithNova LLM]
    N3 --> N4{{N4 interruptForScopeConfirmation 人工}}
    N4 -->|確認範圍| N5[N5 queryCodeGraphViaMcp 工具]
    N4 -->|候選不足需重查| N1
    N5 --> N6[N6 evaluateEvidenceSufficiency 邏輯]
    N6 -->|證據足夠| N7[N7 generateImpactAnalysisDraft LLM]
    N6 -->|證據不足| N8
    N7 --> N8{{N8 interruptForImpactReview 人工}}
    N8 -->|核准| N9[N9 assembleStandardReport 邏輯]
    N8 -->|要求補查| N5
    N9 --> N10[N10 publishReportArtifacts 工具]
    N10 --> N11{{N11 interruptForSolutionStart 人工}}
    N11 -->|下達啟動指令| N12[N12 generateImplementationProposals LLM]
    N12 --> N13[N13 publishProposalsToDashboard 工具]
    N13 --> N14{{N14 interruptForSolutionDecision 人工}}
    N14 -->|核准選定提案| N15[N15 finalizeAndArchiveDecision 邏輯]
    N14 -->|全部拒絕| N15
    N15 --> End([__end__，0930 MVP 到此結束，不含 Jira 建立])
```
