# SystemCard 值域字典

- **日期**：2026-09-20
- **版本**：v1.0
- **狀態**：待簽核
- **定位**：**本文件為 SystemCard 三區塊所有欄位值域之唯一權威來源。** 下列文件之值域敘述一律以本文件為準，如有不一致以本文件為正：
  - `2026-09-20-systemcard-field-spec (對外版)_v2.md`
  - `2026-09-20-systemcard-field-spec_v2.md`
  - `2026-09-20-scd-bian-domain-schema-redesign_v2.md`
- **取代**：原始三份文件中散落於各節之值域敘述（原始文件保留不動，僅作歷史紀錄）

---

## 1. 為什麼需要這份文件

原始三份規格對同一欄位給了不同的值，主要有三類問題：

| 問題 | 具體例子 |
|---|---|
| 同欄位中英文各寫一套，未說明哪個是 JSON 層的權威值 | 介接機制：對外版 §3 寫 `API`／`排程批次/ETL`；對外版 §4 JSON 範例寫 `api`／`batch_etl`；schema redesign §3.2 寫 `api`／`batch_etl` 並另有 `data_platform`／`dedicated_line` 兩個對外版沒出現的代碼 |
| 有值域但沒有 JSON 層定義 | 三態（全資產／部分／無）共 9 個欄位，JSON 範例直接存中文，未定義英文 enum |
| 有受控清單但沒有承接「其他」的欄位 | 主要前端框架「Vue｜其他」——選其他無處記載實際框架；介接機制有 `mechanism_other`，技術堆疊沒有對應欄位 |
| 值域存在但語意未定義 | 系統關聯之重要性 A／B／C，規格從未說明判斷標準 |
| 缺少必要的缺值表示 | 無「不適用」與「未確認」，導致「確定沒有」、「本質上不適用」、「尚未調查」三件事都被迫填「無」 |

本文件把上述全部收斂為單一定義，並標明每一項是**沿用原規格**、**由原規格推導**或**本次新增**。

---

## 2. 通用規則

### R-01 兩層表示

| 層 | 用途 | 值 |
|---|---|---|
| **Excel 層** | 人工填寫（`SystemCard 格式.xlsx`） | 中文標籤（如「全資產」） |
| **JSON 層** | 系統串接、MongoDB 儲存與查詢 | 英文 enum（如 `full`） |

轉換由管線依本文件之對照表執行，**雙向唯一對應，不得有一對多**。JSON 層一律只存英文 enum，不並存中文欄位（避免兩欄不同步）。

> ⚠️ **本規則變更了對外版 §4 JSON 範例**。該範例對 `status`、`system_category`、`critical_category`、`build_type`、`ops_type`、`packaged_software`、SBOM／現代化／DevOps／PQC 等欄位直接存中文字串。對外版 §4 自述「實際欄位命名可再調整，這裡是示意結構」，故本次一併收斂為英文 enum，使 JSON 層風格一致（`relations[]` 與 `bian[]` 原本即為英文 enum）。見決議 D-02。

### R-02 空值與缺值

| 欄位型態 | 無值時的表示 | 可否留空 |
|---|---|---|
| 列舉欄位 | 必須明確填 `not_applicable`（不適用）或 `unknown`（未確認） | **不可留空** |
| 自由文字 | JSON 填 `""`，Excel 留空 | 可（除條件必填者） |
| 陣列 | JSON 填 `[]`，**不使用 `null`** | 可 |
| 占位欄位 | JSON 填 `null`（僅限 `interfaces[].detail`） | — |

### R-03 多值

- Excel 層：同一格內以**全形分號「；」**分隔（沿用原規格 §1 填寫慣例）。
- JSON 層：字串陣列。
- 具名值與 `other` **可併存**，例如前端同時使用 Vue 與 React Native → `["vue", "other"]` ＋ `frontend_other: "React Native"`。

### R-04 條件必填

| 欄位 | 條件 |
|---|---|
| `sbom.management_tool` | 當 `sbom.has_sbom` 為 `full` 或 `partial` 時**必填**；為 `none`／`not_applicable`／`unknown` 時填 `""` |
| `tech_stack.frontend_other` | 當 `tech_stack.frontend` 含 `other` 時**必填**；否則填 `""` |
| `tech_stack.backend_other` | 同上規則，對應 `backend` |
| `tech_stack.database_other` | 同上規則，對應 `database` |
| `interfaces[].mechanism_other` | 當 `mechanism` 為 `other` 時**必填**；否則填 `""`（沿用原規格 §3） |

規則統一為：**受控清單選 `other` 者，對應 `_other` 欄位必填；未選 `other` 者該欄位必須為空。** 此為可機器驗證之雙向約束。

### R-05 大小寫與空白

- JSON enum 一律**小寫 snake_case**；例外：`importance` 沿用大寫 `A`／`B`／`C`（見 E12）。
- BIAN 四層分類值一律**逐字沿用權威表原文**，含大小寫與既有拼寫，不得自行修正（見第 5 節警告）。
- 所有值不得含前後空白。

---

## 3. 列舉值域

### E01 資產覆蓋率（三態＋二）

**適用 9 個欄位**：`sbom.has_sbom`、`modernization.cloud_ready`、`modernization.containerized`、`modernization.cloud_migrated`、`modernization.ai_used`、`devops.alp`、`devops.cicd`、`devops.apm`、`pqc_ready`

| JSON | Excel 中文 | 定義 | 來源 |
|---|---|---|---|
| `full` | 全資產 | 該系統範圍內**所有**資產皆具備 | 沿用 |
| `partial` | 部分 | 部分資產具備，部分未具備 | 沿用 |
| `none` | 無 | 已確認**所有**資產皆不具備 | 沿用 |
| `not_applicable` | 不適用 | 該概念對此系統本質上不適用（例：大型主機系統之容器化） | **本次新增** |
| `unknown` | 未確認 | 尚未調查，或無法取得資料 | **本次新增** |

> `none` 與 `not_applicable`、`unknown` 之區別是資料品質的關鍵。原規格只有 `none`，三種情形混填後無從評估資料完整度，亦無法產出「待調查清單」。

### E02 是否

**適用**：`packaged_software`

| JSON | Excel 中文 | 來源 |
|---|---|---|
| `yes` | 是 | 沿用 |
| `no` | 否 | 沿用 |
| `unknown` | 未確認 | **本次新增** |

> 不提供 `not_applicable`——任何系統皆可判定是否為套裝軟體。

### E03 資訊資產狀態

**適用**：`status`

| JSON | Excel 中文 | 定義 | 來源 |
|---|---|---|---|
| `online` | 上線 | 已上線並提供服務 | 沿用 |
| `offline` | 下線 | 已停止服務 | 沿用 |

> ⚠️ 待決議 Q-A：規格未提供「建置中／待上線」之狀態。新建系統於建置期間依現行值域無法登錄（只能填「上線」或不建卡）。見第 8 節。

### E04 業務系統類別

**適用**：`system_category`

| JSON | Excel 中文 | 來源 |
|---|---|---|
| `class_1` | 第一類 | 沿用 |
| `class_2` | 第二類 | 沿用 |
| `class_3` | 第三類 | 沿用 |

> ⚠️ 待決議 Q-B：三類之判斷標準未於任何規格文件中定義，填寫者只能各自解讀。

### E05 關鍵系統分類

**適用**：`critical_category`

| JSON | Excel 中文 | 來源 |
|---|---|---|
| `core_ict_system` | 核心資通系統 | 沿用 |
| `critical_business_system` | 關鍵業務系統 | 沿用 |

> ⚠️ 待決議 Q-C：原規格基數為 1（必填且單值），意即每個系統**必須**是兩者之一。實務上可能存在既非核心資通系統亦非關鍵業務系統之一般系統（如內部管理工具），現行值域無法表達。

### E06 建置方式

**適用**：`build_type`

| JSON | Excel 中文 | 來源 |
|---|---|---|
| `in_house` | 自建 | 沿用 |
| `outsourced` | 委外 | 沿用 |

> ⚠️ 待決議 Q-D：混合模式（自建核心＋委外模組）無法表達。

### E07 維運方式

**適用**：`ops_type`

| JSON | Excel 中文 | 來源 |
|---|---|---|
| `self_managed` | 自主維運 | 沿用 |
| `outsourced_staff` | 委外人力 | 沿用 |

### E08 主要前端框架

**適用**：`tech_stack.frontend[]`（搭配 `tech_stack.frontend_other`）

| JSON | Excel 中文 | 來源 |
|---|---|---|
| `vue` | Vue | 沿用 |
| `other` | 其他 | 沿用 |
| `not_applicable` | 不適用 | **本次新增**（批次系統、無使用者介面之服務） |

### E09 主要後端語言

**適用**：`tech_stack.backend[]`（搭配 `tech_stack.backend_other`）

| JSON | Excel 中文 | 來源 |
|---|---|---|
| `java` | Java | 沿用 |
| `dotnet` | .NET | 沿用 |
| `other` | 其他 | 沿用 |

### E10 主要資料庫

**適用**：`tech_stack.database[]`（搭配 `tech_stack.database_other`）

| JSON | Excel 中文 | 來源 |
|---|---|---|
| `oracle` | Oracle | 沿用 |
| `mssql` | MS SQL | 沿用 |
| `edb` | EDB | 沿用 |
| `other` | 其他 | 沿用 |
| `not_applicable` | 不適用 | **本次新增**（無自有資料庫之系統） |

### E11 BIAN 對應等級與信心程度

**適用**：`bian.service_domains[].rank`、`.confidence`

| 欄位 | JSON | Excel 中文 | 來源 |
|---|---|---|---|
| rank | `primary` | primary（主要能力） | 沿用 |
| rank | `supporting` | supporting（支援性能力） | 沿用 |
| confidence | `high` | high | 沿用 |
| confidence | `medium` | medium | 沿用 |
| confidence | `low` | low | 沿用 |

> 此兩欄原規格即為英文小寫，Excel 層與 JSON 層同值，無須轉換。

### E12 系統關聯重要性

**適用**：`relations[].importance`

| JSON／Excel | 定義 | 來源 |
|---|---|---|
| `A` | 關係中斷將導致主系統之**核心業務功能無法提供**，且無替代方案，或替代方案無法於當營業日內恢復 | **本次新增定義**（值沿用） |
| `B` | 關係中斷將導致**部分功能不可用**，或須改採人工／備援程序，核心業務仍可持續 | **本次新增定義**（值沿用） |
| `C` | 關係中斷僅影響**輔助性功能**（報表、通知、統計），不影響業務辦理 | **本次新增定義**（值沿用） |

> 原規格僅載「A｜B｜C」與「這組系統關係的整體重要性」，未定義判斷標準。上述定義以「缺失影響」為單一判準，與同區塊之 `impact_if_unavailable` 欄位互相印證，可供覆核時交叉檢查。
>
> 重要性掛在 **relation 層**（一對系統一個值），不下放到 `interfaces[]`（沿用 schema redesign §3.2 之決策）。

### E13 介接方向

**適用**：`relations[].interfaces[].direction`

| JSON | Excel 中文 | 定義 | 來源 |
|---|---|---|---|
| `outbound` | 主→外 | 資料由主系統流向外部系統 | 沿用（redesign §3.2） |
| `inbound` | 外→主 | 資料由外部系統流向主系統 | 沿用（redesign §3.2） |
| `bidirectional` | 雙向 | 雙向流動 | 沿用（redesign §3.2） |

> 對外版 §3 只給中文、§4 JSON 範例只出現 `outbound`，未載明「雙向」之 JSON 值。以 redesign §3.2 為權威，補齊 `bidirectional`。

### E14 介接機制

**適用**：`relations[].interfaces[].mechanism`（搭配 `mechanism_other`）

| JSON | Excel 中文 | 來源 |
|---|---|---|
| `api` | API | 沿用 |
| `kafka` | Kafka | 沿用 |
| `mq` | MQ | 沿用 |
| `data_platform` | 數據中台交換 | **以 redesign §3.2 為權威** |
| `file_transfer` | File Transfer(SFG/FTP) | 沿用 |
| `db_link` | 資料庫直連/共用庫(DB Link) | 沿用 |
| `dedicated_line` | 專線/VPN 點對點 | **以 redesign §3.2 為權威** |
| `batch_etl` | 排程批次/ETL | 沿用 |
| `webhook` | Webhook/事件回呼 | 沿用 |
| `other` | 其他 | 沿用（必填 `mechanism_other`） |

> ⚠️ **此處為三份原始文件不一致最嚴重之處**。對外版 §3 只有中文清單、§4 JSON 範例只出現 `api`／`batch_etl`／`file_transfer` 三個代碼，兩者未給完整對照；`data_platform` 與 `dedicated_line` 兩個代碼**僅出現在 redesign §3.2**。任何依對外版實作者都會自行造字（例如寫成 `data_hub`、`p2p_line`），造成資料無法比對。本表為完整對照，以 redesign §3.2 為權威。

### E15 布林旗標

**適用**：`bian.service_domains[].validated`、`.needs_review`、`relations[].target_is_external_party`

| JSON | 說明 |
|---|---|
| `true` / `false` | JSON 原生布林，不使用字串 `"true"` |

| 欄位 | 語意 | 預設 | 來源 |
|---|---|---|---|
| `validated` | 此筆 BIAN 對應是否已由權威 taxonomy 驗證四條分類路徑正確 | `false` | 沿用 redesign §4.2 |
| `needs_review` | 此筆 BIAN 對應是否已標記待人工覆核 | `false` | 沿用 redesign §4.2 |
| `target_is_external_party` | 對手系統是否為行外機構（非本行資訊資產） | `false` | **本次新增**（見 F-02） |

> `validated`／`needs_review` 出現在 redesign §4.2 schema，但**對外版 §2.2 欄位表與 §4 JSON 範例皆遺漏**。本次補齊。

---

## 4. 格式受控欄位

### F-01 資訊資產代碼

**適用**：`asset_code`（主鍵）、`relations[].target`

| 項目 | 規則 |
|---|---|
| 字元集 | 大寫英文字母與數字 |
| 首字元 | 必須為英文字母 |
| 長度 | 2–10 碼 |
| 正規表示式 | `^[A-Z][A-Z0-9]{1,9}$` |
| 唯一性 | 全行唯一；為 §2／§3 之外來鍵（FK）串接依據 |
| 範例 | `EDLS`、`FEP`、`CIF`、`ATMS` |

> **本次新增**。原規格僅載「唯一識別鍵，如 `EDLS`、`FEP`」，未定義字元集、長度與格式，無法做欄位驗證。

### F-02 行外機構之對手系統表示法

**適用**：`relations[].target`

| 項目 | 規則 |
|---|---|
| 前綴 | `EXT.` |
| 後段 | 機構英文簡稱，大寫英數，1–15 碼 |
| 正規表示式 | `^EXT\.[A-Z][A-Z0-9]{0,14}$` |
| 必要條件 | 同筆 relation 之 `target_is_external_party` 必須為 `true` |
| 範例 | `EXT.JCIC`（聯合徵信中心）、`EXT.FISC`（財金資訊公司）、`EXT.SWIFT`、`EXT.TWNCH`（票據交換所） |

> **本次新增**。原規格 §3 之「外部系統代碼」隱含對手必為本行資訊資產，但實務上大量介接指向行外機構（聯徵、財金、SWIFT、電信業者簡訊閘道）。無此規則時，這些關聯要嘛被迫略去（關聯圖失真），要嘛填入不存在的代碼（產生懸空參照，且無法與 §1 join）。
>
> 加上前綴與布林旗標後：① 懸空參照可由驗證器自動區分為「合法的行外參照」與「真正的資料錯誤」；② 查詢「本行系統對外依賴」可直接以 `target_is_external_party: true` 篩選。

### F-03 現況基準日

**適用**：`as_of`（**本次新增欄位**）

| 項目 | 規則 |
|---|---|
| 格式 | `YYYY-MM-DD`（ISO 8601 date） |
| 語意 | 此張系統卡所反映之現況基準日 |
| 基數 | 1，必填 |

> **本次新增**。SystemCard 為資產現況登錄，但原規格無任何欄位記載資料有效日期。系統異動頻繁時，使用者無從判斷手上的卡是否過期，亦無法排程複核。

---

## 5. 外部權威值域：BIAN 四層分類

**適用**：`bian.service_domains[].service_domain`、`.matrix.business_area`、`.matrix.business_domain`、`.value_chain.top`、`.value_chain.mid`

### 5.1 權威來源

| 項目 | 內容 |
|---|---|
| 檔案 | `BIAN_341_dual_view_knowledge.csv` |
| 版本 | BIAN Service Landscape v14.0.0 |
| 筆數 | 341 個 Service Domain，各自一組固定雙路徑 |
| 填寫方式 | **依 `service_domain` 葉節點查表填入四個分類欄位**；人工研判僅及於「本系統對應到哪些 Service Domain」與 `rank`／`confidence`／`rationale`／`source_responsibility` |

### 5.2 ⚠️ 兩條路徑不得互推（沿用對外版 §2.3 與 redesign §4.1）

36 個 Matrix Business Domain 中有 **31 個**，其底下之 Service Domain 散落在多個不同的 Value Chain 路徑。**依 Matrix 路徑推算 Value Chain 路徑必定出錯**，反之亦然。四個分類欄位必須逐筆查表。

### 5.3 ⚠️ 逐字沿用權威表拼寫

權威表中 `ValueChain-Mid` 有一個值為 **`Intelectual Property And Knowledge`**（`Intelectual` 少一個 `l`）。此為來源資料之既有拼寫，**必須原樣沿用**，不得自行修正為 `Intellectual`，否則與 taxonomy 的 join 會失敗。

此類情形應由驗證器以「與權威表逐欄比對」處理，而非交由填寫者判斷。

### 5.4 Matrix-Business Area（5 個）

`Business Support`、`Operations and Execution`、`Reference Data`、`Risk and Compliance`、`Sales and Service`

### 5.5 ValueChain-Top（8 個）

`Business Development`、`Business Management`、`Channels`、`Customers`、`Finance And Risk Management`、`Operations`、`Products`、`Resource Management`

### 5.6 Matrix-Business Domain（36 個）

`Account Management`、`Bank Portfolio and Treasury`、`Buildings Equipment and Facilities`、`Business Analysis`、`Business Command and Control`、`Business Direction`、`Cards`、`Channel Specific`、`Collateral Administration`、`Consumer Services`、`Corporate Financing and Advisory Services`、`Corporate Relations`、`Cross Channel`、`Customer Management`、`Document Management and Archive`、`External Agency`、`Finance`、`Human Resource Management`、`IT Management`、`Investment Management`、`Knowledge and Intellectual Property Management`、`Loans and Deposits`、`Market Data`、`Market Operations`、`Marketing`、`Models`、`Non-IT and Non-HR Enterprise Services`、`Operational Services`、`Party`、`Payments`、`Product Management`、`Regulations and Compliance`、`Sales`、`Servicing`、`Trade Banking`、`Wholesale Trading`

### 5.7 ValueChain-Mid（43 個）

`Accounting Services`、`Advisory Services`、`Buildings And Equipment`、`Business Direction`、`Cards`、`Channel Management`、`Channel Specific`、`Clearing And Settlement`、`Compliance`、`Consumer Banking`、`Corporate Banking`、`Corporate Finance`、`Corporate Relations`、`Corporate Services`、`Credit Risk`、`Cross Channel`、`Custody, Collateral And Documents`、`Customer Care`、`Distribution`、`External Agency`、`Financial Control`、`Group Treasury`、`Human Resources`、`Information Providers`、`Intelectual Property And Knowledge`、`Investment Services`、`Loans and Deposits`、`Market Operations`、`Market Risk`、`Market Trading`、`Marketing And Development`、`Models And Analytics`、`Operational Risk`、`Operational Services`、`Party Reference`、`Platform Operations`、`Product Management`、`Relationship Management`、`Sales`、`Servicing`、`Solution Development`、`Trade Banking`、`Unit Management`

> `Custody, Collateral And Documents` 含**半形逗號**，CSV 處理須正確引號跳脫。

### 5.8 341 個 Service Domain

不於本文件列舉，以 `BIAN_341_dual_view_knowledge.csv` 為唯一來源。驗證方式：以 `service_domain` 為鍵查表，取回四個分類欄位並與填寫值逐欄比對。

---

## 6. 欄位 × 值域對照總表

### 6.1 系統基本資料（§1）

| # | Excel 欄位 | JSON key | 值域 | 基數 | 必填 |
|---|---|---|---|---|---|
| 1 | 資訊資產名稱 | `asset_name` | 自由文字 | 1 | Y |
| 2 | 資訊資產代碼 | `asset_code` | F-01 | 1 | Y（主鍵） |
| 3 | 資訊資產英文全稱 | `asset_name_en_full` | 自由文字 | 1 | Y |
| 4 | 資訊資產英文簡稱 | `asset_name_en_short` | 自由文字 | 1 | Y |
| 5 | 資訊資產狀態 | `status` | E03 | 1 | Y |
| 6 | 業務系統類別 | `system_category` | E04 | 1 | Y |
| 7 | 關鍵系統分類 | `critical_category` | E05 | 1 | Y |
| 8 | 系統簡介 | `description` | 自由文字 | 1 | Y |
| 9 | 建置方式 | `build_type` | E06 | 1 | Y |
| 10 | 維運方式 | `ops_type` | E07 | 1 | Y |
| 11 | 套裝軟體 | `packaged_software` | E02 | 1 | Y |
| — | （新增）現況基準日 | `as_of` | F-03 | 1 | Y |
| 12 | 主要前端框架 | `tech_stack.frontend[]` | E08 | 0..* | N |
| — | （新增）主要前端框架-其他說明 | `tech_stack.frontend_other` | 自由文字 | 1 | 條件（R-04） |
| 13 | 主要後端語言 | `tech_stack.backend[]` | E09 | 0..* | N |
| — | （新增）主要後端語言-其他說明 | `tech_stack.backend_other` | 自由文字 | 1 | 條件（R-04） |
| 14 | 主要資料庫 | `tech_stack.database[]` | E10 | 0..* | N |
| — | （新增）主要資料庫-其他說明 | `tech_stack.database_other` | 自由文字 | 1 | 條件（R-04） |
| 15 | 是否有SBOM | `sbom.has_sbom` | E01 | 1 | Y |
| 16 | SBOM管理方式 | `sbom.management_tool` | 自由文字 | 1 | 條件（R-04） |
| 17 | 是否已經cloudReady | `modernization.cloud_ready` | E01 | 1 | Y |
| 18 | 是否已經容器化 | `modernization.containerized` | E01 | 1 | Y |
| 19 | 是否已經上雲 | `modernization.cloud_migrated` | E01 | 1 | Y |
| 20 | 是否有使用AI | `modernization.ai_used` | E01 | 1 | Y |
| 21 | 是否有導入ALP | `devops.alp` | E01 | 1 | Y |
| 22 | 是否有導入CI/CD | `devops.cicd` | E01 | 1 | Y |
| 23 | 是否有導入APM | `devops.apm` | E01 | 1 | Y |
| 24 | 是否PQC ready | `pqc_ready` | E01 | 1 | Y |
| 25 | 業管單位 | `contacts.business_unit` | 自由文字 | 1 | Y |
| 26 | 業管單位系統負責人 | `contacts.business_owner` | 自由文字 | 1 | Y |
| 27 | PO產品負責人 | `contacts.product_owner` | 自由文字 | 1 | Y |
| 28 | 資訊單位 | `contacts.it_unit` | 自由文字 | 1 | Y |
| 29 | 資訊單位負責人 | `contacts.it_owners[]` | 自由文字陣列 | 1..* | Y |
| 30 | 維運廠商 | `contacts.vendors[]` | 自由文字陣列 | 0..* | N |
| 31 | 複委託廠商 | `contacts.subcontractors[]` | 自由文字陣列 | 0..* | N |

### 6.2 BIAN 服務領域對應（§2）

| Excel 欄位 | JSON key | 值域 | 必填 |
|---|---|---|---|
| 資訊資產代碼(FK) | （父層 `asset_code`） | F-01 | Y |
| Service Domain | `service_domain` | §5.8（341 SD） | Y |
| Matrix-Business Area | `matrix.business_area` | §5.4（查表） | Y |
| Matrix-Business Domain | `matrix.business_domain` | §5.6（查表） | Y |
| ValueChain-Top | `value_chain.top` | §5.5（查表） | Y |
| ValueChain-Mid | `value_chain.mid` | §5.7（查表） | Y |
| 對應等級(Rank) | `rank` | E11 | Y |
| 信心程度(Confidence) | `confidence` | E11 | Y |
| 對應理由(Rationale) | `rationale` | 自由文字 | Y |
| 系統對應職責描述 | `source_responsibility` | 自由文字 | Y |
| （補齊）已驗證 | `validated` | E15 | Y（預設 `false`） |
| （補齊）待覆核 | `needs_review` | E15 | Y（預設 `false`） |

### 6.3 系統關聯 SCD（§3）

| Excel 欄位 | JSON key | 值域 | 必填 |
|---|---|---|---|
| 資訊資產代碼(FK) | （父層 `asset_code`） | F-01 | Y |
| 外部系統代碼 | `target` | F-01 或 F-02 | Y |
| （新增）對手為行外機構 | `target_is_external_party` | E15 | Y（預設 `false`） |
| 重要性(Importance) | `importance` | E12 | Y |
| 介接方向(Direction) | `interfaces[].direction` | E13 | Y |
| 介接機制(Mechanism) | `interfaces[].mechanism` | E14 | Y |
| 介接機制-其他說明 | `interfaces[].mechanism_other` | 自由文字 | 條件（R-04） |
| 介接功能說明(Function) | `interfaces[].function` | 自由文字 | Y |
| 缺失影響說明 | `interfaces[].impact_if_unavailable` | 自由文字 | Y |
| （占位）介接明細 | `interfaces[].detail` | `null` | Y（固定 `null`） |

---

## 7. 可機器驗證之約束清單

供驗證器實作，共 18 條：

| # | 約束 | 層級 |
|---|---|---|
| C-01 | `asset_code` 符合 F-01 正規表示式 | 錯誤 |
| C-02 | `asset_code` 全檔唯一 | 錯誤 |
| C-03 | 所有列舉欄位之值屬對應值域，且不為空字串 | 錯誤 |
| C-04 | `as_of` 符合 ISO 8601 date | 錯誤 |
| C-05 | 每系統至少 1 筆 `bian.service_domains[]` | 錯誤 |
| C-06 | 每筆 BIAN 之四個分類欄位與權威 taxonomy 逐欄相符 | 錯誤 |
| C-07 | `sbom.management_tool` 符合 R-04 條件必填 | 錯誤 |
| C-08 | `tech_stack.*_other` 符合 R-04 雙向約束 | 錯誤 |
| C-09 | `interfaces[].mechanism_other` 符合 R-04 雙向約束 | 錯誤 |
| C-10 | `target` 為 F-02 格式時，`target_is_external_party` 必為 `true`；反之必為 `false` | 錯誤 |
| C-11 | `target_is_external_party` 為 `false` 時，`target` 必存在於本檔 `asset_code` 集合 | 錯誤 |
| C-12 | `interfaces[].detail` 為 `null` | 錯誤 |
| C-13 | 同一 relation 內不得有兩筆 `direction` 與 `mechanism` 皆相同之 interface | 錯誤 |
| C-14 | 陣列欄位不得為 `null`（無值用 `[]`） | 錯誤 |
| C-15 | 所有值無前後空白 | 錯誤 |
| C-16 | 雙向一致性：若 A 卡記載 A↔B（B 為本行資產），B 卡亦應記載 | 警告 |
| C-17 | `confidence` 為 `low` 時，`needs_review` 宜為 `true` | 警告 |
| C-18 | 列舉欄位值為 `unknown` 者列入待調查清單 | 資訊 |

---

## 8. 待決議項目

本次未自行裁決，列出供規格主辦單位決定。

| 編號 | 項目 | 影響 |
|---|---|---|
| Q-A | `status` 缺少「建置中／待上線」狀態（E03） | 新建系統於建置期間無法登錄，只能不建卡。若需在專案期間即納管，須擴充值域 |
| Q-B | `system_category` 第一／二／三類之判斷標準未定義（E04） | 各單位自行解讀，資料不可比 |
| Q-C | `critical_category` 基數為 1 且只有兩個值，隱含「所有系統必為兩者之一」（E05） | 一般內部管理系統無法正確分類 |
| Q-D | `build_type` 無法表達混合模式（E06） | 自建核心＋委外模組之系統只能擇一填寫 |
| Q-E | 技術堆疊之 `other` 累積值是否定期回收為正式值域 | 若不回收，`other` 會愈填愈多，統計失去意義。建議每半年檢視 `*_other` 之出現頻次 |
| Q-F | 是否需要 `relations[].interfaces[].detail` 第二層 | redesign §5 已列為待辦，本次維持 `null` 占位 |

---

## 9. 決議紀錄

| 編號 | 決議 | 說明 |
|---|---|---|
| D-01 | 建立本值域字典為唯一權威來源 | 三份規格文件之值域敘述一律引用本文件 |
| D-02 | JSON 層一律英文 enum，Excel 層維持中文，不並存中英雙欄 | 變更對外版 §4 JSON 範例中 7 個直接存中文之欄位。理由：`relations[]` 與 `bian[]` 原本即為英文 enum，若 §1 存中文則同一份 JSON 有兩套風格；且 §4 自述為示意結構、可再調整 |
| D-03 | E14 介接機制以 redesign §3.2 為權威，補齊 `data_platform`、`dedicated_line` | 對外版 §3／§4 未給完整對照，實作者會自行造字 |
| D-04 | 三態擴充為五態，新增 `not_applicable`、`unknown` | 區分「確定沒有」、「本質不適用」、「尚未調查」 |
| D-05 | 技術堆疊比照介接機制，新增 `*_other` 欄位與 R-04 雙向約束 | 統一「選其他必附說明」之規則 |
| D-06 | 新增 `as_of` 現況基準日 | 使現況資料可判斷時效 |
| D-07 | 新增行外機構表示法 F-02 與 `target_is_external_party` | 使行外介接可正確登錄，並讓驗證器區分合法行外參照與資料錯誤 |
| D-08 | 補齊 `validated`、`needs_review` 至對外版欄位表與 JSON 範例 | 原僅出現於 redesign §4.2 |
| D-09 | 定義 `importance` A／B／C 之判斷標準（E12） | 原規格僅有值、無標準 |
| D-10 | 定義 `asset_code` 格式（F-01） | 原規格僅舉例、無格式 |
| D-11 | BIAN 四層分類逐字沿用權威表拼寫，含既有錯字 | 保障與 taxonomy 之 join 可用性 |
