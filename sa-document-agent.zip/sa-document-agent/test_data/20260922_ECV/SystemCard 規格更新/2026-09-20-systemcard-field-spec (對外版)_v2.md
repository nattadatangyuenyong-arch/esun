## 0. 總覽

> **版本**：v2（2026-09-20）　**取代**：`2026-09-14-systemcard-field-spec (對外版).md`（原始檔保留，僅作歷史紀錄）
>
> **v2 主要變更**：所有欄位值域集中定義於 **`2026-09-20-systemcard-value-domains.md`（值域字典）**，本文件之「值域或範例」欄一律只列 Excel 填寫用的中文值；JSON 層之英文 enum 請查值域字典。v2 並修正 v1 中同一欄位中英文值域不一致、以及三個欄位遺漏之問題。變更明細見 §5。

SystemCard 由三個區塊組成，共用同一把鑰匙——**資訊資產代碼**：

| 區塊 | 用途 | 基數 |
|---|---|---|
| ① 系統基本資料 | 每個系統的基本資訊、技術堆疊、現代化程度、聯絡窗口 | 一系統一列 |
| ② BIAN 服務領域對應 | 系統對應到哪些 BIAN Service Domain | 一系統可對多列（多個 Service Domain） |
| ③ 系統關聯（SCD） | 系統與外部系統之間的介接關係 | 一系統可對多列（多個外部系統 × 多種介接機制） |

②③ 都用「資訊資產代碼」對應回 ①，同代碼多列會組成該系統底下的一個陣列，最終轉成一份 JSON 文件（供未來 MongoDB 查詢使用）。

### 0.1 填寫前必讀的四條通用規則

| 規則 | 內容 |
|---|---|
| **多值** | 同一格內以**全形分號「；」**分隔。具名值與「其他」可併存（例：前端同時用 Vue 與 React Native，填「Vue；其他」，並在「主要前端框架-其他說明」填「React Native」） |
| **不可留空** | 有受控清單的欄位**一律不可留空**。確定沒有填「無」；本質上不適用填「不適用」；尚未調查填「未確認」。這三者意思不同，不要混用 |
| **選「其他」必附說明** | 凡受控清單選「其他」者，對應的「-其他說明」欄位必填；沒選「其他」則該欄位必須留空 |
| **現況基準日** | 每張卡都要填「現況基準日」，代表這張卡反映的是哪一天的狀況 |

---

## 1. 系統基本資料

沿用公司統一規格（`SystemCard 格式.xlsx` 01_系統基本資料工作表），v2 新增 4 個欄位（下表標「＋」）。

| 分類 | 欄位名稱 | 值域或範例（Excel 填寫值） | 基數 | 必填 | 值域字典 |
|---|---|---|---|---|---|
| 基本資料 | 資訊資產名稱 | — | 1 | Y | — |
| | 資訊資產代碼 | 唯一識別鍵。大寫英數 2–10 碼、首字為英文字母，如 `EDLS`、`FEP` | 1 | Y | F-01 |
| | 資訊資產英文全稱 | — | 1 | Y | — |
| | 資訊資產英文簡稱 | — | 1 | Y | — |
| | 資訊資產狀態 | 上線｜下線 | 1 | Y | E03 |
| | 業務系統類別 | 第一類｜第二類｜第三類 | 1 | Y | E04 |
| | 關鍵系統分類 | 核心資通系統｜關鍵業務系統 | 1 | Y | E05 |
| | 系統簡介 | — | 1 | Y | — |
| | 建置方式 | 自建｜委外 | 1 | Y | E06 |
| | 維運方式 | 自主維運｜委外人力 | 1 | Y | E07 |
| | 套裝軟體 | 是｜否｜未確認 | 1 | Y | E02 |
| | **＋現況基準日** | `YYYY-MM-DD`，如 `2026-09-20` | 1 | Y | F-03 |
| 技術堆疊 | 主要前端框架 | Vue｜其他｜不適用（可多值，以「；」分隔） | 0..* | N | E08 |
| | **＋主要前端框架-其他說明** | 僅當上欄含「其他」時填寫 | 1 | 條件 | — |
| | 主要後端語言 | Java｜.NET｜其他（可多值） | 0..* | N | E09 |
| | **＋主要後端語言-其他說明** | 僅當上欄含「其他」時填寫 | 1 | 條件 | — |
| | 主要資料庫 | Oracle｜MS SQL｜EDB｜其他｜不適用（可多值） | 0..* | N | E10 |
| | **＋主要資料庫-其他說明** | 僅當上欄含「其他」時填寫 | 1 | 條件 | — |
| SBOM | 是否有SBOM | 全資產｜部分｜無｜不適用｜未確認 | 1 | Y | E01 |
| | SBOM管理方式 | 如 SonarType Lifecycle。上欄為「全資產」或「部分」時必填 | 1 | 條件 | — |
| 現代化 | 是否已經cloudReady | 全資產｜部分｜無｜不適用｜未確認 | 1 | Y | E01 |
| | 是否已經容器化 | 同上 | 1 | Y | E01 |
| | 是否已經上雲 | 同上 | 1 | Y | E01 |
| | 是否有使用AI | 同上 | 1 | Y | E01 |
| DevOps | 是否有導入ALP | 同上 | 1 | Y | E01 |
| | 是否有導入CI/CD | 同上 | 1 | Y | E01 |
| | 是否有導入APM | 同上 | 1 | Y | E01 |
| PQC | 是否PQC ready | 同上 | 1 | Y | E01 |
| 聯絡資訊-業務 | 業管單位 | — | 1 | Y | — |
| | 業管單位系統負責人 | — | 1 | Y | — |
| | PO產品負責人 | — | 1 | Y | — |
| 聯絡資訊-資訊 | 資訊單位 | — | 1 | Y | — |
| | 資訊單位負責人 | 可多值，以「；」分隔 | 1..* | Y | — |
| 聯絡資訊-廠商 | 維運廠商 | 可多值，以「；」分隔 | 0..* | N | — |
| | 複委託廠商 | 可多值，以「；」分隔 | 0..* | N | — |

> **v1 變更說明**：v1 的三態欄位值域為「全資產｜部分｜無」，v2 擴充為五態，新增「不適用」與「未確認」。原因是「確定沒有」、「本質上不適用」（例如大型主機系統談容器化）、「尚未調查」三件事在 v1 都只能填「無」，導致無法評估資料完整度，也產不出待調查清單。詳見值域字典 D-04。

---

## 2. BIAN 服務領域對應

一個系統可以對應多個 BIAN Service Domain，一個 Service Domain 一列，用資訊資產代碼(FK)串接回系統基本資料。

### 2.1 一個 Service Domain、兩條路徑

BIAN 官方 Service Landscape v14 有**兩種視圖**，兩者的葉節點都是同一個 Service Domain，但上層分類軸完全不同（不是換個名字而已）：

| 視圖 | 第一層 | 第二層 | 葉節點 |
|---|---|---|---|
| **Matrix View** | Business Area（5 個） | Business Domain（36 個） | Service Domain |
| **Value Chain View** | Value Chain Top（8 個） | Value Chain Mid（43 個） | Service Domain（同上，共 341 個） |

因此每一列**同時記錄兩條路徑**，未來才能從同一份資料一次投影出 Matrix View 與 Value Chain View 兩張圖。

五個 Business Area、36 個 Business Domain、8 個 Value Chain Top、43 個 Value Chain Mid 之完整清單，見值域字典 §5.4～§5.7。

### 2.2 欄位

| 分類 | 欄位名稱 | 值域或範例 | 必填 | 值域字典 | 說明 |
|---|---|---|---|---|---|
| 串接 | 資訊資產代碼(FK) | 如 `EDLS` | Y | F-01 | 對應回系統基本資料 |
| 葉節點 | Service Domain | 例：Credit Card | Y | §5.8 | **兩視圖共用**，須為官方 341 個 Service Domain 之一 |
| Matrix View | Matrix-Business Area | 例：Operations and Execution | Y | §5.4 | Matrix 第一層（查表填入） |
| | Matrix-Business Domain | 例：Cards | Y | §5.6 | Matrix 第二層（查表填入） |
| Value Chain View | ValueChain-Top | 例：Products | Y | §5.5 | Value Chain 第一層（查表填入） |
| | ValueChain-Mid | 例：Cards | Y | §5.7 | Value Chain 第二層（查表填入） |
| 人工研判 | 對應等級(Rank) | primary｜supporting | Y | E11 | 這個 Service Domain 是系統的主要能力還是支援性能力 |
| | 信心程度(Confidence) | high｜medium｜low | Y | E11 | 針對**這一筆**對應的信心程度（不是整個系統一份） |
| | 對應理由(Rationale) | — | Y | — | 記錄判斷依據，供後續稽核 |
| | 系統對應職責描述(Source Responsibility) | — | Y | — | 系統在這個 Service Domain 上實際承擔什麼職責 |
| 覆核狀態 | **＋已驗證(Validated)** | 是｜否（預設：否） | Y | E15 | 四條分類路徑是否已由權威 taxonomy 驗證正確 |
| | **＋待覆核(Needs Review)** | 是｜否（預設：否） | Y | E15 | 此筆對應是否已標記需人工覆核 |

> **v1 變更說明**：`validated`／`needs_review` 兩欄位原本存在於技術設計文件（`scd-bian-domain-schema-redesign.md` §4.2 的 schema），但 v1 對外版的欄位表與 JSON 範例都遺漏了，導致依對外版實作的資料缺這兩欄。v2 補齊。詳見值域字典 D-08。

### 2.3 ⚠️ 兩條路徑不能互推

**不要用 Matrix 路徑去推算 Value Chain 路徑。** 實測官方 v14 資料，36 個 Matrix Business Domain 裡有 **31 個**，底下的 Service Domain 會散落在多個不同的 Value Chain 路徑。例如 Matrix 同屬 `Channel Specific` 的 Service Domain，在 Value Chain View 會分別落在：

- `Channels > Channel Specific`
- `Channels > Distribution`
- `Channels > Servicing`
- `Business Development > Channel Management`

所以四個分類欄位都要照該筆 Service Domain 各自填寫。

### 2.4 ⚠️ 分類值要逐字照抄，不要「順手改錯字」

四個分類欄位的值必須與權威 taxonomy **逐字相同**，包含大小寫與既有拼寫。

權威表中有一個 ValueChain-Mid 的值是 `Intelectual Property And Knowledge`（`Intelectual` 少一個 `l`）。這是來源資料本身的拼寫，**請原樣填入**，改成 `Intellectual` 會導致資料無法與 taxonomy 比對。

此類問題應由系統端的驗證程式處理（逐欄比對權威表），不需填寫者判斷。

### 2.5 填寫方式

四個分類欄位其實都由「Service Domain」唯一決定——官方 341 個 Service Domain 各自有固定的兩條路徑。需要人工研判的只有**這個系統對應到哪些 Service Domain**，以及 Rank／Confidence／Rationale／職責描述。

分類欄位由 BIAN 分類器 AI agent 問答後產出，團隊貼上即可（該 agent 本就同時輸出 Matrix 與 Value Chain 兩套路徑）。權威對照來源為 `BIAN_341_dual_view_knowledge.csv`（341 SD 雙路徑 taxonomy），與本規格欄位一一對應。

轉 JSON 後掛在對應系統文件下的 `bian.service_domains[]`。

---

## 3. 系統關聯（SCD）

一個系統可以對多個外部系統有介接關係，一對系統之間也可能同時存在多種介接機制（例如同時有 API 又有夜間批次檔案傳輸）。**每一列 = 一種介接機制**，同一對系統若有多種機制，請分多列填寫（資訊資產代碼與外部系統代碼相同，其餘欄位各自填）。

| 欄位名稱 | 值域或範例 | 必填 | 值域字典 | 說明 |
|---|---|---|---|---|
| 資訊資產代碼(FK) | 如 `FEP` | Y | F-01 | 主系統（資料記錄/查詢的主要視角） |
| 外部系統代碼 | 本行系統如 `EDLS`；行外機構如 `EXT.JCIC` | Y | F-01／F-02 | 與主系統有介接關係的系統 |
| **＋對手為行外機構** | 是｜否（預設：否） | Y | E15 | 對手若非本行資訊資產（聯徵、財金、SWIFT、電信業者等）填「是」，且代碼須用 `EXT.` 前綴 |
| 重要性(Importance) | A｜B｜C | Y | E12 | 這組系統關係的整體重要性。**判斷標準見下方 §3.1** |
| 介接方向(Direction) | 主→外｜外→主｜雙向 | Y | E13 | 資料流動方向 |
| 介接機制(Mechanism) | API｜Kafka｜MQ｜數據中台交換｜File Transfer(SFG/FTP)｜資料庫直連/共用庫(DB Link)｜專線/VPN 點對點｜排程批次/ETL｜Webhook/事件回呼｜其他 | Y | E14 | 受控清單，選「其他」時請於下一欄補充 |
| 介接機制-其他說明 | — | 條件 | — | 僅當「介接機制」選「其他」時填寫 |
| 介接功能說明(Function) | 例：帳戶扣帳、記帳等 | Y | — | 這筆介接的用途 |
| 缺失影響說明(Impact if unavailable) | 例：交易電文送不到主機、所有跨行交易皆會受影響 | Y | — | 給人類寫的備援確認備註 |
| 介接明細(Detail) | 固定留空 | — | — | 保留給「依機制展開的資料格式細節」，本版不使用，轉 JSON 時固定為 `null` |

### 3.1 重要性 A／B／C 的判斷標準

v1 只給了「A｜B｜C」三個值，沒有說明怎麼判斷，各單位各自解讀。v2 補上單一判準——**以「這條介接斷掉會怎樣」為準**，與同區塊的「缺失影響說明」互相印證：

| 值 | 判斷標準 |
|---|---|
| **A** | 斷掉會導致主系統的**核心業務功能無法提供**，且沒有替代方案，或替代方案無法在當營業日內恢復 |
| **B** | 斷掉會導致**部分功能不可用**，或必須改用人工／備援程序，但核心業務仍可持續 |
| **C** | 斷掉只影響**輔助性功能**（報表、通知、統計），不影響業務辦理 |

填完後請自我檢查：「缺失影響說明」寫的內容，是否支持你選的重要性等級。

### 3.2 行外機構怎麼填

v1 的「外部系統代碼」隱含對手一定是本行資訊資產，但實際上很多介接是打出去給行外機構的。v1 沒有規則，只能二選一：略去不填（關聯圖失真），或填一個不存在的代碼（產生找不到對應系統卡的懸空參照，也無法和 ①區塊 join）。

v2 規則：

| 項目 | 規則 |
|---|---|
| 代碼寫法 | `EXT.` ＋ 機構英文簡稱（大寫英數） |
| 範例 | `EXT.JCIC`（聯合徵信中心）、`EXT.FISC`（財金資訊公司）、`EXT.SWIFT`、`EXT.TWNCH`（票據交換所） |
| 搭配欄位 | 「對手為行外機構」必須填「是」 |

這樣系統端就能把「合法的行外參照」與「真正填錯的代碼」分開，也能直接查詢「本行系統對外部機構的依賴清單」。

轉 JSON 後掛在對應系統文件下的 `relations[].interfaces[]`（同一組「資訊資產代碼＋外部系統代碼」會合併成一筆 relation，底下的多列組成 interfaces 陣列）。

> 此區塊為本專案新增，目前公司統一 Excel 格式尚未包含，若要併入正式範本，建議新增一個工作表（如 `04_系統關聯SCD`）採用上表欄位。

---

## 4. 完整 JSON 範例（假資料）

以下用一個假想系統 `DEMO01` 示範三個區塊組出來的完整 JSON 長相。

⚠️ **v2 與 v1 範例的差異**：v1 範例中 `status`、`system_category`、`critical_category`、`build_type`、`ops_type`、`packaged_software`、SBOM／現代化／DevOps／PQC 等欄位直接存中文字串（如 `"status": "上線"`），與同一份 JSON 中 `relations[]`、`bian[]` 使用英文 enum 的風格不一致。v2 統一為**JSON 層一律英文 enum、Excel 層維持中文**，對照表見值域字典。

```json
{
  "asset_code": "DEMO01",
  "asset_name": "示範信用卡核心系統（假資料）",
  "asset_name_en_full": "Demo Credit Card Core System",
  "asset_name_en_short": "DemoCard",
  "as_of": "2026-09-20",
  "status": "online",
  "system_category": "class_1",
  "critical_category": "core_ict_system",
  "description": "處理信用卡核心帳務與交易授權的示範系統",
  "build_type": "in_house",
  "ops_type": "self_managed",
  "packaged_software": "no",
  "tech_stack": {
    "frontend": ["vue"],
    "frontend_other": "",
    "backend": ["java"],
    "backend_other": "",
    "database": ["oracle", "edb"],
    "database_other": ""
  },
  "sbom": {
    "has_sbom": "full",
    "management_tool": "SonarType Lifecycle"
  },
  "modernization": {
    "cloud_ready": "partial",
    "containerized": "partial",
    "cloud_migrated": "none",
    "ai_used": "unknown"
  },
  "devops": {
    "alp": "full",
    "cicd": "full",
    "apm": "partial"
  },
  "pqc_ready": "not_applicable",
  "contacts": {
    "business_unit": "信用卡事業處",
    "business_owner": "王小明",
    "product_owner": "陳小華",
    "it_unit": "核心系統開發部",
    "it_owners": ["李小美", "張小強"],
    "vendors": ["某系統整合商"],
    "subcontractors": []
  },

  "bian": {
    "service_domains": [
      {
        "service_domain": "Credit Card",
        "matrix": {
          "business_area": "Operations and Execution",
          "business_domain": "Cards"
        },
        "value_chain": {
          "top": "Products",
          "mid": "Cards"
        },
        "rank": "primary",
        "confidence": "high",
        "rationale": "系統核心功能即信用卡帳戶與交易管理，直接對應此 Service Domain",
        "source_responsibility": "信用卡帳戶生命週期管理",
        "validated": true,
        "needs_review": false
      },
      {
        "service_domain": "Card Authorization",
        "matrix": {
          "business_area": "Operations and Execution",
          "business_domain": "Cards"
        },
        "value_chain": {
          "top": "Products",
          "mid": "Cards"
        },
        "rank": "supporting",
        "confidence": "medium",
        "rationale": "系統有轉呼叫外部授權服務，非自行完整實作，故列為支援性能力",
        "source_responsibility": "交易授權轉發",
        "validated": true,
        "needs_review": false
      },
      {
        "service_domain": "Card Clearing",
        "matrix": {
          "business_area": "Operations and Execution",
          "business_domain": "Payments"
        },
        "value_chain": {
          "top": "Operations",
          "mid": "Clearing And Settlement"
        },
        "rank": "supporting",
        "confidence": "low",
        "rationale": "系統負責每日與收單機構的清分作業；此筆示範兩視圖路徑不同——Matrix 掛在 Payments，Value Chain 掛在 Clearing And Settlement",
        "source_responsibility": "信用卡交易清分",
        "validated": true,
        "needs_review": true
      }
    ]
  },

  "relations": [
    {
      "target": "AUTH01",
      "target_is_external_party": false,
      "importance": "A",
      "interfaces": [
        {
          "direction": "outbound",
          "mechanism": "api",
          "mechanism_other": "",
          "function": "即時交易授權查詢",
          "impact_if_unavailable": "授權服務中斷會導致所有信用卡交易無法即時核准",
          "detail": null
        },
        {
          "direction": "outbound",
          "mechanism": "batch_etl",
          "mechanism_other": "",
          "function": "夜間對帳批次，核對當日授權與入帳金額差異",
          "impact_if_unavailable": "當日對帳延遲，隔日才能發現差異，不影響即時交易",
          "detail": null
        }
      ]
    },
    {
      "target": "STMT01",
      "target_is_external_party": false,
      "importance": "B",
      "interfaces": [
        {
          "direction": "outbound",
          "mechanism": "file_transfer",
          "mechanism_other": "",
          "function": "每月帳單資料傳送給帳單產製系統",
          "impact_if_unavailable": "當月帳單無法如期產製，需人工介入補送檔案",
          "detail": null
        }
      ]
    },
    {
      "target": "EXT.FISC",
      "target_is_external_party": true,
      "importance": "A",
      "interfaces": [
        {
          "direction": "bidirectional",
          "mechanism": "dedicated_line",
          "mechanism_other": "",
          "function": "跨行交易電文收發",
          "impact_if_unavailable": "所有跨行信用卡交易中斷",
          "detail": null
        }
      ]
    },
    {
      "target": "EXT.SMSGW",
      "target_is_external_party": true,
      "importance": "C",
      "interfaces": [
        {
          "direction": "outbound",
          "mechanism": "other",
          "mechanism_other": "電信業者簡訊閘道（SMPP 協定）",
          "function": "刷卡通知簡訊發送",
          "impact_if_unavailable": "持卡人收不到刷卡通知簡訊，推播管道仍可用",
          "detail": null
        }
      ]
    }
  ]
}
```

---

## 5. v2 變更明細

| # | 變更 | 類型 | 值域字典決議 |
|---|---|---|---|
| 1 | 值域集中定義於值域字典，本文件不再自行敘述 JSON 層值 | 結構 | D-01 |
| 2 | JSON 層一律英文 enum（影響 §1 的 12 個欄位與 §4 範例） | 修正不一致 | D-02 |
| 3 | 介接機制補齊完整中英對照，含 v1 對外版缺漏的 `data_platform`、`dedicated_line` | 修正缺漏 | D-03 |
| 4 | 三態擴充為五態，新增「不適用」、「未確認」 | 新增值 | D-04 |
| 5 | 技術堆疊新增 3 個「-其他說明」欄位 | 新增欄位 | D-05 |
| 6 | 新增「現況基準日」欄位 | 新增欄位 | D-06 |
| 7 | 新增行外機構代碼規則（`EXT.` 前綴）與「對手為行外機構」欄位 | 新增欄位 | D-07 |
| 8 | §2.2 補上 v1 遺漏的「已驗證」、「待覆核」兩欄位 | 修正缺漏 | D-08 |
| 9 | §3.1 新增重要性 A／B／C 判斷標準 | 新增定義 | D-09 |
| 10 | 資訊資產代碼新增格式規則（大寫英數 2–10 碼） | 新增定義 | D-10 |
| 11 | 新增 §2.4「分類值要逐字照抄」警告（含權威表既有錯字） | 新增說明 | D-11 |
| 12 | 新增 §0.1 填寫前必讀四條通用規則 | 新增說明 | R-01～R-04 |
| 13 | §3 欄位表新增「介接明細(Detail)」占位欄位（固定留空／JSON `null`） | 修正缺漏 | Q-F |

### 5.1 尚未解決、需規格主辦單位決定者

以下 6 項 v2 未自行裁決，明細見值域字典 §8：

| 編號 | 項目 |
|---|---|
| Q-A | 缺少「建置中／待上線」狀態，新建系統於建置期間無法登錄 |
| Q-B | 業務系統類別第一／二／三類之判斷標準未定義 |
| Q-C | 關鍵系統分類只有兩個值且必填，一般內部管理系統無法分類 |
| Q-D | 建置方式無法表達「自建核心＋委外模組」之混合模式 |
| Q-E | 技術堆疊「其他」之累積值是否定期回收為正式值域 |
| Q-F | `interfaces[].detail` 第二層是否要設計 |
