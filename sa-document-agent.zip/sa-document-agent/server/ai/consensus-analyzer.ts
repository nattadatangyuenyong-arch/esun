import {
  ConsensusAnalysisSchema,
  type ConsensusAnalysis,
  type ConsensusSection
} from '../workflow/state.js'

/**
 * Contract for anything capable of analyzing parsed
 * consensus-document sections.
 *
 * The real implementation will use AWS Bedrock.
 * Tests can provide a fake implementation.
 */
export interface ConsensusAnalyzer {
  analyze(
    sections: ConsensusSection[]
  ): Promise<ConsensusAnalysis>
}

/**
 * Runtime validation for LLM output.
 *
 * TypeScript only checks our code at compile time.
 * Since LLM output arrives at runtime, Zod verifies that
 * the returned object actually follows ConsensusAnalysis.
 */
export function validateConsensusAnalysis(
  value: unknown
): ConsensusAnalysis {
  return ConsensusAnalysisSchema.parse(value)
}