import { GoogleGenAI } from '@google/genai'

import {
  ConsensusAnalysisSchema,
  type ConsensusAnalysis,
  type ConsensusSection
} from '../workflow/state.js'
import type { ConsensusAnalyzer } from './consensus-analyzer.js'

const DEFAULT_GEMINI_MODEL = 'gemini-2.5-flash'

const consensusAnalysisJsonSchema = {
  type: 'object',
  properties: {
    systems: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          systemCode: {
            type: 'string'
          },
          systemName: {
            type: 'string'
          },
          role: {
            type: 'string'
          },
          evidence: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                heading: {
                  type: 'string'
                },
                startLine: {
                  type: 'integer'
                },
                endLine: {
                  type: 'integer'
                },
                quote: {
                  type: 'string'
                }
              },
              required: [
                'heading',
                'startLine',
                'endLine',
                'quote'
              ]
            }
          }
        },
        required: [
          'systemCode',
          'role',
          'evidence'
        ]
      }
    },

    agreedChanges: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          description: {
            type: 'string'
          },
          affectedSystems: {
            type: 'array',
            items: {
              type: 'string'
            }
          },
          evidence: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                heading: {
                  type: 'string'
                },
                startLine: {
                  type: 'integer'
                },
                endLine: {
                  type: 'integer'
                },
                quote: {
                  type: 'string'
                }
              },
              required: [
                'heading',
                'startLine',
                'endLine',
                'quote'
              ]
            }
          }
        },
        required: [
          'description',
          'affectedSystems',
          'evidence'
        ]
      }
    },

    referencedSADocuments: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          saNumber: {
            type: 'string'
          },
          fullId: {
            type: 'string'
          },
          title: {
            type: 'string'
          },
          evidence: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                heading: {
                  type: 'string'
                },
                startLine: {
                  type: 'integer'
                },
                endLine: {
                  type: 'integer'
                },
                quote: {
                  type: 'string'
                }
              },
              required: [
                'heading',
                'startLine',
                'endLine',
                'quote'
              ]
            }
          }
        },
        required: [
          'saNumber',
          'evidence'
        ]
      }
    }
  },

  required: [
    'systems',
    'agreedChanges',
    'referencedSADocuments'
  ]
}

export interface GeminiConsensusAnalyzerOptions {
  apiKey: string
  model?: string
}

export class GeminiConsensusAnalyzer
  implements ConsensusAnalyzer
{
  private readonly client: GoogleGenAI
  private readonly model: string

  constructor(
    options: GeminiConsensusAnalyzerOptions
  ) {
    if (!options.apiKey.trim()) {
      throw new Error(
        'Gemini API key is required.'
      )
    }

    this.client = new GoogleGenAI({
      apiKey: options.apiKey
    })

    this.model =
      options.model ?? DEFAULT_GEMINI_MODEL
  }

  async analyze(
    sections: ConsensusSection[]
  ): Promise<ConsensusAnalysis> {
    const document = formatSections(sections)

    const response =
      await this.client.models.generateContent({
        model: this.model,

        contents: buildPrompt(document),

        config: {
          responseMimeType: 'application/json',
          responseSchema: consensusAnalysisJsonSchema
        }
      })

    if (!response.text) {
      throw new Error(
        'Gemini returned an empty response.'
      )
    }

    const parsed: unknown = JSON.parse(
      response.text
    )

    return ConsensusAnalysisSchema.parse(
      parsed
    )
  }
}

function formatSections(
  sections: ConsensusSection[]
): string {
  return sections
    .map(
      (section) => `
--- SECTION ---
Heading: ${section.heading}
Level: ${section.level}
Lines: ${section.startLine}-${section.endLine}

${section.text}
`
    )
    .join('\n')
}

function buildPrompt(
  document: string
): string {
  return `
You are analyzing a Solution Architecture consensus document.

Your task is to extract structured facts from the SELECTED and AGREED solution.

Identify:

1. systems
   Systems involved in the agreed solution and their responsibilities.

2. agreedChanges
   Changes that the consensus document says should happen.

3. referencedSADocuments
   SA documents explicitly referenced or identified as relevant to the solution.

IMPORTANT RULES:

- Use only information contained in the supplied document.
- Do not invent systems, responsibilities, changes, or SA documents.
- Distinguish the selected/agreed solution from alternatives that were discussed but not adopted.
- Do not treat rejected or unselected alternatives as agreed changes.
- Do NOT decide whether an SA document should be modified yet.
- Do NOT classify documents as 改, 不改, or 不確定.
- That decision will happen later after the existing SA document is read.
- Every extracted fact must contain supporting evidence.
- Evidence must refer to the supplied section heading and line range.
- The quote must be text supported by the supplied section.
- Preserve SA identifiers exactly when possible.
- If information is not present, return an empty array rather than guessing.

CONSENSUS DOCUMENT:

${document}
`
}