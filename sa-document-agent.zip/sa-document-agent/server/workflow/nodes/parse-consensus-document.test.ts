import { describe, expect, it } from 'vitest'

import type { SADocumentGraphStateType } from '../state.js'
import { parseConsensusDocument } from './parse-consensus-document.js'

function createState(
  documentText?: string
): SADocumentGraphStateType {
  return {
    input: {
      path: '/test/consensus.md'
    },
    documentText,
    metadata: undefined,
    sections: [],
    consensusAnalysis: undefined,
    error: undefined
  }
}

describe('parseConsensusDocument', () => {
  it('splits Markdown into sections with correct line numbers', () => {
    const documentText = [
      '# AML Consensus',
      '',
      'Introduction',
      '',
      '## 方案定位',
      '',
      'EDLS 負責 Account Review。',
      '',
      '## 影響範圍',
      '',
      'SA 00008 需要調整。'
    ].join('\n')

    const result = parseConsensusDocument(
      createState(documentText)
    )

    expect(result.error).toBeUndefined()

    expect(result.sections).toHaveLength(3)

    expect(result.sections?.[0]).toEqual({
      heading: 'AML Consensus',
      level: 1,
      startLine: 1,
      endLine: 4,
      text: [
        '# AML Consensus',
        '',
        'Introduction',
        ''
      ].join('\n')
    })

    expect(result.sections?.[1]).toEqual({
      heading: '方案定位',
      level: 2,
      startLine: 5,
      endLine: 8,
      text: [
        '## 方案定位',
        '',
        'EDLS 負責 Account Review。',
        ''
      ].join('\n')
    })

    expect(result.sections?.[2]).toEqual({
      heading: '影響範圍',
      level: 2,
      startLine: 9,
      endLine: 11,
      text: [
        '## 影響範圍',
        '',
        'SA 00008 需要調整。'
      ].join('\n')
    })
  })

  it('preserves different Markdown heading levels', () => {
    const documentText = [
      '# Main',
      'Main content',
      '## Child',
      'Child content',
      '### Grandchild',
      'Grandchild content'
    ].join('\n')

    const result = parseConsensusDocument(
      createState(documentText)
    )

    expect(result.sections?.map((section) => section.level))
      .toEqual([1, 2, 3])
  })

  it('returns PARSE_FAILED when document text is unavailable', () => {
    const result = parseConsensusDocument(
      createState(undefined)
    )

    expect(result.error?.code).toBe('PARSE_FAILED')
  })

  it('returns PARSE_FAILED when no Markdown headings exist', () => {
    const documentText = [
      'This document has text.',
      'But it has no Markdown headings.'
    ].join('\n')

    const result = parseConsensusDocument(
      createState(documentText)
    )

    expect(result.error?.code).toBe('PARSE_FAILED')
  })
})