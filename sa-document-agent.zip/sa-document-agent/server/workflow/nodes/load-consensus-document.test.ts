import { afterEach, describe, expect, it } from 'vitest'
import { mkdir, rm, writeFile } from 'node:fs/promises'
import { join } from 'node:path'
import { tmpdir } from 'node:os'

import { loadConsensusDocument } from './load-consensus-document.js'

const testDir = join(tmpdir(), 'sa-document-agent-test')

afterEach(async () => {
  await rm(testDir, {
    recursive: true,
    force: true
  })
})

describe('loadConsensusDocument', () => {
  it('loads a valid Markdown consensus document', async () => {
    await mkdir(testDir, {
      recursive: true
    })

    const filePath = join(testDir, 'consensus.md')

    const content = [
      '# AML 未完成高風險定審支出交易管控範疇調整',
      '',
      '## 方案定位',
      '',
      'EDLS 負責 Account Review 交易管控。'
    ].join('\n')

    await writeFile(filePath, content, 'utf-8')

    const result = await loadConsensusDocument({
      input: {
        path: filePath,
        systemCode: 'EDLS'
      },

      documentText: undefined,
      metadata: undefined,
      sections: [],
      consensusAnalysis: undefined,
      error: undefined
    })

    expect(result.error).toBeUndefined()

    expect(result.documentText).toBe(content)

    expect(result.metadata).toMatchObject({
      fileName: 'consensus.md',
      extension: '.md',
      title: 'AML 未完成高風險定審支出交易管控範疇調整',
      lineCount: 5,
      characterCount: content.length
    })

    expect(result.metadata?.loadedAt).toBeDefined()
  })

  it('returns FILE_NOT_FOUND when the document does not exist', async () => {
    const filePath = join(testDir, 'missing.md')

    const result = await loadConsensusDocument({
      input: {
        path: filePath
      },

      documentText: undefined,
      metadata: undefined,
      sections: [],
      consensusAnalysis: undefined,
      error: undefined
    })

    expect(result.error?.code).toBe('FILE_NOT_FOUND')
    expect(result.error?.path).toBe(filePath)
  })

  it('rejects unsupported file types', async () => {
    const filePath = join(testDir, 'consensus.pdf')

    const result = await loadConsensusDocument({
      input: {
        path: filePath
      },

      documentText: undefined,
      metadata: undefined,
      sections: [],
      consensusAnalysis: undefined,
      error: undefined
    })

    expect(result.error?.code).toBe(
      'UNSUPPORTED_FILE_TYPE'
    )
  })

  it('rejects an empty Markdown document', async () => {
    await mkdir(testDir, {
      recursive: true
    })

    const filePath = join(testDir, 'empty.md')

    await writeFile(filePath, '', 'utf-8')

    const result = await loadConsensusDocument({
      input: {
        path: filePath
      },

      documentText: undefined,
      metadata: undefined,
      sections: [],
      consensusAnalysis: undefined,
      error: undefined
    })

    expect(result.error?.code).toBe('EMPTY_DOCUMENT')
  })
})