import type {
  ConsensusSection,
  SADocumentGraphStateType
} from '../state.js'

export function parseConsensusDocument(
  state: SADocumentGraphStateType
) {
  if (!state.documentText) {
    return {
      error: {
        code: 'PARSE_FAILED' as const,
        message: 'Consensus document text is not available.'
      }
    }
  }

  const lines = state.documentText.split(/\r?\n/)
  const sections: ConsensusSection[] = []

  let currentSection:
    | {
        heading: string
        level: number
        startLine: number
        lines: string[]
      }
    | undefined

  for (let index = 0; index < lines.length; index++) {
    const line = lines[index]
    const lineNumber = index + 1

    const headingMatch = line.match(
      /^(#{1,6})\s+(.+?)\s*$/
    )

    if (headingMatch) {
      if (currentSection) {
        sections.push({
          heading: currentSection.heading,
          level: currentSection.level,
          startLine: currentSection.startLine,
          endLine: lineNumber - 1,
          text: currentSection.lines.join('\n')
        })
      }

      currentSection = {
        heading: headingMatch[2].trim(),
        level: headingMatch[1].length,
        startLine: lineNumber,
        lines: [line]
      }

      continue
    }

    if (currentSection) {
      currentSection.lines.push(line)
    }
  }

  if (currentSection) {
    sections.push({
      heading: currentSection.heading,
      level: currentSection.level,
      startLine: currentSection.startLine,
      endLine: lines.length,
      text: currentSection.lines.join('\n')
    })
  }

  if (sections.length === 0) {
    return {
      error: {
        code: 'PARSE_FAILED' as const,
        message:
          'No Markdown sections were found in the consensus document.'
      }
    }
  }

  return {
    sections,
    error: undefined
  }
}