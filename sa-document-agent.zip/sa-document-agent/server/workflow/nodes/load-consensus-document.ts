import { readFile } from 'node:fs/promises'
import { basename, extname } from 'node:path'

import type { SADocumentGraphStateType } from '../state.js'

export async function loadConsensusDocument(
  state: SADocumentGraphStateType
) {
  const filePath = state.input.path

  // 1. Validate file type
  const extension = extname(filePath).toLowerCase()

  if (extension !== '.md') {
    return {
      error: {
        code: 'UNSUPPORTED_FILE_TYPE' as const,
        message: 'Consensus document must be a Markdown (.md) file.',
        path: filePath
      }
    }
  }

  try {
    // 2. Read the original Markdown file
    const documentText = await readFile(filePath, 'utf-8')

    // 3. Make sure the document is not empty
    if (documentText.trim().length === 0) {
      return {
        error: {
          code: 'EMPTY_DOCUMENT' as const,
          message: 'Consensus document is empty.',
          path: filePath
        }
      }
    }

    // 4. Extract the Markdown title
    const title = extractMarkdownTitle(documentText)

    // 5. Build deterministic metadata
    const metadata = {
      fileName: basename(filePath),
      extension: '.md' as const,
      title,
      lineCount: documentText.split(/\r?\n/).length,
      characterCount: documentText.length,
      loadedAt: new Date().toISOString()
    }

    // 6. Update LangGraph state
    return {
      documentText,
      metadata,
      error: undefined
    }
  } catch (error) {
    const nodeError = error as NodeJS.ErrnoException

    // File does not exist
    if (nodeError.code === 'ENOENT') {
      return {
        error: {
          code: 'FILE_NOT_FOUND' as const,
          message: 'Consensus document could not be found.',
          path: filePath,
          cause: nodeError.message
        }
      }
    }

    // Other read error
    return {
      error: {
        code: 'FILE_READ_FAILED' as const,
        message: 'Failed to read consensus document.',
        path: filePath,
        cause:
          error instanceof Error
            ? error.message
            : String(error)
      }
    }
  }
}

/**
 * Extract the first H1 heading from the Markdown document.
 *
 * Example:
 *
 * # AML 未完成高風險定審支出交易管控範疇調整
 *
 * becomes:
 *
 * AML 未完成高風險定審支出交易管控範疇調整
 */
function extractMarkdownTitle(
  documentText: string
): string | undefined {
  const lines = documentText.split(/\r?\n/)

  for (const line of lines) {
    const match = line.match(/^#\s+(.+?)\s*$/)

    if (match) {
      return match[1].trim()
    }
  }

  return undefined
}