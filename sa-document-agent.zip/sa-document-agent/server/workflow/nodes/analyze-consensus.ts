import type { ConsensusAnalyzer } from '../../ai/consensus-analyzer.js'
import type { SADocumentGraphStateType } from '../state.js'

export async function analyzeConsensus(
  state: SADocumentGraphStateType,
  analyzer: ConsensusAnalyzer
) {
  if (state.sections.length === 0) {
    return {
      error: {
        code: 'ANALYSIS_FAILED' as const,
        message: 'Consensus sections are not available for analysis.'
      }
    }
  }

  try {
    const consensusAnalysis = await analyzer.analyze(
      state.sections
    )

    return {
      consensusAnalysis,
      error: undefined
    }
  } catch (error) {
    return {
      error: {
        code: 'ANALYSIS_FAILED' as const,
        message: 'Failed to analyze the consensus document.',
        cause:
          error instanceof Error
            ? error.message
            : String(error)
      }
    }
  }
}