import { describe, expect, it } from 'vitest'

import type { ConsensusAnalyzer } from '../../ai/consensus-analyzer.js'
import { analyzeConsensus } from './analyze-consensus.js'
import type { SADocumentGraphStateType } from '../state.js'

const fakeAnalyzer: ConsensusAnalyzer = {
  async analyze() {
    return {
      systems: [
        {
          systemCode: 'AMLS',
          systemName: 'AML System',
          role: 'Performs transaction control checks.',
          evidence: [
            {
              heading: '系統分工摘要',
              startLine: 91,
              endLine: 101,
              quote: 'AMLS performs transaction control checks.'
            }
          ]
        }
      ],

      agreedChanges: [
        {
          description: 'Adjust the transaction control scope.',
          affectedSystems: ['AMLS'],
          evidence: [
            {
              heading: '本次選擇的方案',
              startLine: 55,
              endLine: 62,
              quote: 'Adjust the transaction control scope.'
            }
          ]
        }
      ],

      referencedSADocuments: [
        {
          saNumber: '00008',
          fullId: 'TS0714-SA-070201-00008',
          title: '交易與顧客資料接收及監控情境執行',
          evidence: [
            {
              heading: '配合測試系統清單',
              startLine: 187,
              endLine: 202,
              quote: 'TS0714-SA-070201-00008'
            }
          ]
        }
      ]
    }
  }
}

function createState(): SADocumentGraphStateType {
  return {
    input: {
      path: '/tmp/consensus.md'
    },

    documentText: '# Test',

    metadata: undefined,

    sections: [
      {
        heading: 'Test',
        level: 1,
        startLine: 1,
        endLine: 1,
        text: '# Test'
      }
    ],

    consensusAnalysis: undefined,
    error: undefined
  }
}

describe('analyzeConsensus', () => {
  it('stores the analyzer result as consensusAnalysis', async () => {
    const result = await analyzeConsensus(
      createState(),
      fakeAnalyzer
    )

    expect(result.error).toBeUndefined()
    expect(result.consensusAnalysis).toBeDefined()

    expect(
      result.consensusAnalysis?.systems
    ).toHaveLength(1)

    expect(
      result.consensusAnalysis?.systems[0]?.systemCode
    ).toBe('AMLS')

    expect(
      result.consensusAnalysis
        ?.referencedSADocuments[0]
        ?.saNumber
    ).toBe('00008')
  })

  it('returns ANALYSIS_FAILED when there are no sections', async () => {
    const state = createState()

    state.sections = []

    const result = await analyzeConsensus(
      state,
      fakeAnalyzer
    )

    expect(result.error?.code).toBe(
      'ANALYSIS_FAILED'
    )

    expect(
      result.consensusAnalysis
    ).toBeUndefined()
  })

  it('returns ANALYSIS_FAILED when the analyzer throws', async () => {
    const failingAnalyzer: ConsensusAnalyzer = {
      async analyze() {
        throw new Error('Bedrock failed')
      }
    }

    const result = await analyzeConsensus(
      createState(),
      failingAnalyzer
    )

    expect(result.error?.code).toBe(
      'ANALYSIS_FAILED'
    )

    expect(result.error?.cause).toBe(
      'Bedrock failed'
    )
  })
})