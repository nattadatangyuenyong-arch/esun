import { Annotation } from '@langchain/langgraph'
import { z } from 'zod'

/**
 * Input supplied when starting the SA Document Agent.
 */
export const ConsensusDocumentInputSchema = z
  .object({
    path: z.string().trim().min(1),
    requirementId: z.string().trim().min(1).optional(),
    mvp: z.string().trim().min(1).optional(),
    systemCode: z.string().trim().min(1).optional()
  })
  .strict()

export type ConsensusDocumentInput = z.infer<
  typeof ConsensusDocumentInputSchema
>

/**
 * Basic metadata extracted from the consensus document.
 */
export const ConsensusDocumentMetadataSchema = z
  .object({
    fileName: z.string().min(1),
    extension: z.literal('.md'),
    title: z.string().min(1).optional(),
    lineCount: z.number().int().nonnegative(),
    characterCount: z.number().int().nonnegative(),
    loadedAt: z.string().datetime()
  })
  .strict()

export type ConsensusDocumentMetadata = z.infer<
  typeof ConsensusDocumentMetadataSchema
>

/**
 * One Markdown section extracted from the consensus document.
 */
export const ConsensusSectionSchema = z
  .object({
    heading: z.string().min(1),
    level: z.number().int().min(1).max(6),
    startLine: z.number().int().positive(),
    endLine: z.number().int().positive(),
    text: z.string()
  })
  .strict()

export type ConsensusSection = z.infer<
  typeof ConsensusSectionSchema
>

/**
 * Evidence from the original consensus document supporting
 * an extracted fact.
 */
export const ConsensusEvidenceSchema = z
  .object({
    heading: z.string().min(1),
    startLine: z.number().int().positive(),
    endLine: z.number().int().positive(),
    quote: z.string().min(1)
  })
  .strict()

export type ConsensusEvidence = z.infer<
  typeof ConsensusEvidenceSchema
>

/**
 * A system identified as being involved in the agreed solution.
 */
export const InvolvedSystemSchema = z
  .object({
    systemCode: z.string().min(1),
    systemName: z.string().min(1).optional(),
    role: z.string().min(1),
    evidence: z.array(ConsensusEvidenceSchema).min(1)
  })
  .strict()

export type InvolvedSystem = z.infer<
  typeof InvolvedSystemSchema
>

/**
 * A change agreed upon in the consensus document.
 */
export const AgreedChangeSchema = z
  .object({
    description: z.string().min(1),
    affectedSystems: z.array(z.string().min(1)),
    evidence: z.array(ConsensusEvidenceSchema).min(1)
  })
  .strict()

export type AgreedChange = z.infer<
  typeof AgreedChangeSchema
>

/**
 * An SA document referenced by the consensus document.
 */
export const ReferencedSADocumentSchema = z
  .object({
    saNumber: z.string().min(1),
    fullId: z.string().min(1).optional(),
    title: z.string().min(1).optional(),
    evidence: z.array(ConsensusEvidenceSchema).min(1)
  })
  .strict()

export type ReferencedSADocument = z.infer<
  typeof ReferencedSADocumentSchema
>

/**
 * Structured semantic analysis of the consensus document.
 */
export const ConsensusAnalysisSchema = z
  .object({
    systems: z.array(InvolvedSystemSchema),
    agreedChanges: z.array(AgreedChangeSchema),
    referencedSADocuments: z.array(
      ReferencedSADocumentSchema
    )
  })
  .strict()

export type ConsensusAnalysis = z.infer<
  typeof ConsensusAnalysisSchema
>


/**
 * Errors produced while loading/parsing the consensus document.
 */

export const ConsensusDocumentErrorSchema = z
  .object({
    code: z.enum([
      'FILE_NOT_FOUND',
      'UNSUPPORTED_FILE_TYPE',
      'FILE_READ_FAILED',
      'EMPTY_DOCUMENT',
      'PARSE_FAILED',
      'ANALYSIS_FAILED'
    ]),
    message: z.string().min(1),
    path: z.string().optional(),
    cause: z.string().optional()
  })
  .strict()

export type ConsensusDocumentError = z.infer<
  typeof ConsensusDocumentErrorSchema
>

/**
 * Zod representation of the current agent state.
 */
export const SADocumentAgentStateSchema = z
  .object({
    input: ConsensusDocumentInputSchema,
    documentText: z.string().optional(),
    metadata: ConsensusDocumentMetadataSchema.optional(),
    sections: z.array(ConsensusSectionSchema).optional(),
    consensusAnalysis: ConsensusAnalysisSchema.optional(),
    error: ConsensusDocumentErrorSchema.optional()
  })
  .strict()

export type SADocumentAgentState = z.infer<
  typeof SADocumentAgentStateSchema
>

/**
 * LangGraph state shared between workflow nodes.
 */
export const SADocumentGraphState = Annotation.Root({
  input: Annotation<ConsensusDocumentInput>,

  documentText: Annotation<string | undefined>({
    default: () => undefined,
    reducer: (_current, update) => update
  }),

  metadata: Annotation<ConsensusDocumentMetadata | undefined>({
    default: () => undefined,
    reducer: (_current, update) => update
  }),

  sections: Annotation<ConsensusSection[]>({
    default: () => [],
    reducer: (_current, update) => update
  }),

  consensusAnalysis: Annotation<ConsensusAnalysis | undefined>({
    default: () => undefined,
    reducer: (_current, update) => update
  }),

  error: Annotation<ConsensusDocumentError | undefined>({
    default: () => undefined,
    reducer: (_current, update) => update
  })
})

export type SADocumentGraphStateType =
  typeof SADocumentGraphState.State