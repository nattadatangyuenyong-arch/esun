import { resolve } from 'node:path'

import { loadConsensusDocument } from '../server/workflow/nodes/load-consensus-document.js'
import { parseConsensusDocument } from '../server/workflow/nodes/parse-consensus-document.js'
import type { SADocumentGraphStateType } from '../server/workflow/state.js'

const inputPath = process.argv[2]

if (!inputPath) {
  console.error(
    'Usage: pnpm inspect:consensus <path-to-consensus.md>'
  )

  process.exit(1)
}

const filePath = resolve(inputPath)

const initialState: SADocumentGraphStateType = {
  input: {
    path: filePath
  },

  documentText: undefined,
  metadata: undefined,
  sections: [],
  error: undefined
}

const loaded = await loadConsensusDocument(initialState)

if (loaded.error) {
  console.error('Failed to load consensus:')
  console.error(loaded.error)

  process.exit(1)
}

const loadedState: SADocumentGraphStateType = {
  ...initialState,
  ...loaded
}

const parsed = parseConsensusDocument(loadedState)

if (parsed.error) {
  console.error('Failed to parse consensus:')
  console.error(parsed.error)

  process.exit(1)
}

console.log('\n=== Document ===')
console.log(loaded.metadata)

console.log('\n=== Sections ===')

for (const section of parsed.sections ?? []) {
  console.log(
    `[${section.startLine}-${section.endLine}] ` +
      `${'#'.repeat(section.level)} ${section.heading}`
  )
}

console.log(
  `\nTotal sections: ${parsed.sections?.length ?? 0}`
)