import { resolve } from 'node:path'

import { GeminiConsensusAnalyzer } from '../server/ai/gemini-consensus-analyzer.js'
import { loadConsensusDocument } from '../server/workflow/nodes/load-consensus-document.js'
import { parseConsensusDocument } from '../server/workflow/nodes/parse-consensus-document.js'
import type { SADocumentGraphStateType } from '../server/workflow/state.js'

const inputPath = process.argv[2]

if (!inputPath) {
  console.error(
    'Usage: pnpm inspect:analysis <path-to-consensus.md>'
  )
  process.exit(1)
}

const apiKey = process.env.GEMINI_API_KEY

if (!apiKey) {
  console.error(
    'GEMINI_API_KEY environment variable is not set.'
  )
  process.exit(1)
}

const filePath = resolve(inputPath)

const initialState: SADocumentGraphStateType = {
  input: {
    path: filePath
  },
  documentText: undefined,
  metadata: undefined,
  sections: [],
  consensusAnalysis: undefined,
  error: undefined
}

const loaded = await loadConsensusDocument(
  initialState
)

if (loaded.error) {
  console.error('Load failed:')
  console.error(loaded.error)
  process.exit(1)
}

const parsed = parseConsensusDocument({
  ...initialState,
  ...loaded
})

if (parsed.error) {
  console.error('Parse failed:')
  console.error(parsed.error)
  process.exit(1)
}

const analyzer = new GeminiConsensusAnalyzer({
  apiKey
})

console.log(
  `Analyzing ${parsed.sections?.length ?? 0} sections with Gemini...`
)

const analysis = await analyzer.analyze(
  parsed.sections ?? []
)

console.log(
  JSON.stringify(analysis, null, 2)
)